#ifndef _LINKEDLIST_H
#define _LINKEDLIST_H

/**
 * Header file defining all the operations offered to the linked list data structure.
 * The linked list will be used as a memory allocator determining if a segment of memory has been
 * allocated, the size of the allocation, and whether or not it has been freed.
 */

#include <stdio.h>
#include <stddef.h>
#include <assert.h>

// Represents a block of data that has been allocated on the heap
typedef struct block {
  size_t size;        // How many bytes beyond this block have been allocated in the heap
  struct block *next; // Where is the next block in your linked list
  int free;           // Is this memory free, i.e., available to give away?
} block_t;

block_t *init_block(void *block_ptr, size_t size);

#endif //_LINKEDLIST_H
