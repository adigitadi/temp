#include "linkedlist.h"

// Initialize a new block of memory with default values and size s 
block_t *init_block(void *block_ptr, size_t s) {
    block_t *block = (block_t *) block_ptr;
    block->size = s;
    block->next = NULL;
    block->free = 0;
    return block;
}

