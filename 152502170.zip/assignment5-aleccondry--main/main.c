#include <linkedlist.h>
#include <malloc.h>

int main(int argc, char *argv[]) {
    printf("hello world!\n");
    
    void *ptr1 = (void *) malloc(sizeof(char) * 10);
    void *ptr2 = (void *) malloc(sizeof(char) * 10); 
    
    myfree(ptr1);
    myfree(ptr2);
    return 0;
}
