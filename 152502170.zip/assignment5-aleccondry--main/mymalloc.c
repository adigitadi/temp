#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h> 
#include <stdio.h> 

// Include any other headers we need here
#include <linkedlist.h>
#include <string.h>
#include <unistd.h>
#include <debug.h> // definition of debug_printf

// the size (in bytes) of a header block
#define BLOCK_SIZE sizeof(block_t)

/* GLOBAL VARIABLES */
//The first element of the linked list of blocks
block_t *HEAD = NULL;

//The last element of the linked list of blocks
block_t *TAIL = NULL;

//Debug string for printing
char *DEBUG = "Malloc";

// Replacement for malloc using sbrk
// Allocate a new block of memory that is of size s bytes
void *mymalloc(size_t s) {
    //Search for a free block with enough space
    block_t *temp = HEAD;
    while (temp != NULL) {
	if (temp->free && temp->size >= s) {
	    //Unfree the block and return the ptr
	    temp->free = 0;
	    temp->size = s;
	    void *ptr = temp + 1;
	    debug_printf("%s %zu bytes\n", DEBUG, s);
	    return ptr;
	}
	temp = temp->next;
    }

    //Allocate memory for a new block and the desired memory
    void *block_ptr = sbrk(BLOCK_SIZE);
    void *alloc_mem = sbrk(s);

    //Return null if the program has run out of memory
    if (block_ptr == (void *) -1 || alloc_mem == (void *) -1) {
	printf("Error: ran out of memory");
	return NULL;
    }

    //Initialize a new block
    block_t *block = init_block(block_ptr, s);

    //Update the global HEAD and TAIL 
    if (HEAD == NULL) {
        HEAD = block;
	TAIL = block;
    }
    else {
	TAIL->next = block;
	TAIL = TAIL->next;
    }

    //Print debug info and return the allocated memory
    debug_printf("%s %zu bytes\n", DEBUG, block->size);
    return alloc_mem;
}

// Replacement function for calloc using sbrk
// Allocate a new block of memory with nmemb elements each of size s
// Initialize all data to 0
void *mycalloc(size_t nmemb, size_t s) {
    //Set debug string
    DEBUG = "Calloc";

    //Use mymalloc to allocate a new block of memory
    void *ptr = mymalloc(nmemb * s);

    //Reset debug string
    DEBUG = "Malloc";

    //Return NULL if the program ran out of memory
    if (ptr == NULL) {
	printf("Error: ran out of memory");
	return NULL;
    }

    //Set all the data within ptr equal to 0
    memset(ptr, 0, nmemb * s);

    return ptr;
}

// Replace function for free
// Deallocate a pointer to allow new memory to occupy the memory block
void myfree(void *ptr) {
    //Get the block pointer that ptr is using
    block_t *block_ptr = (block_t*) (ptr - BLOCK_SIZE);
    
    //Set the ptr to NULL so it can no longer be used
    ptr = NULL;
    
    //Set the free flag to true to indicate the block has been freed
    block_ptr->free = 1;
    debug_printf("Freed %ld bytes\n", block_ptr->size);
}
