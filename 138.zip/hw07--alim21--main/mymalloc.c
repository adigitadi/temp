#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h>
#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <unistd.h>
#include <debug.h>
#include <pthread.h>
#include <sys/mman.h>
#include <math.h>


//Struct of a block. Includes size, next, free, and debug
//Debug isn't used but was required in the assignment
typedef struct block {
  size_t size;
  struct block *next;
  int free;
  int debug;
} block_t;

pthread_mutex_t myfunc_mtx = PTHREAD_MUTEX_INITIALIZER;

#define BLOCK_SIZE sizeof(block_t)
block_t *init;

int roundup(float val){
  int n = (int)val; //(val < 0 ? (val-0.5) : (val + 0.5));
  return n;
}

//Searches for an empty position that a block + header can be placed into
block_t *first_empty_search(size_t s) {

  block_t *head = init;
  block_t *after = NULL;

  int block_size;
  int free_status;
  int fittable;

  //finds space
  while(head != NULL) {
    block_size = head->size;
    free_status = head->free;
    fittable = block_size > s;

    if(fittable && free_status) {
      after = head;
    }
    head = head->next;
  }
  //if we can't find space, return head in order to be used later
  if(after == NULL) {
    return head;
  } else {
    after->free = 0;
    return after;
  }

}

//Creates a new block with the requested amount of size
block_t *create_new_block(size_t s) {
  
  
  
  if (s + BLOCK_SIZE < getpagesize()){
    block_t *ptr = (block_t *) mmap(NULL, s + BLOCK_SIZE, PROT_READ | PROT_WRITE, MAP_ANON | MAP_PRIVATE, - 1, 0);

    //checking if there is enough space to split
    if(getpagesize() < s + BLOCK_SIZE + 1){

      block_t* leftover;
      leftover= (block_t *) ptr+s+(BLOCK_SIZE);
      block_t* fresh = (block_t *) ptr;
      fresh->size=s;
      fresh->next=(block_t *) leftover;
      fresh->free=0;
      leftover->size=getpagesize()-s-(BLOCK_SIZE*2);
      leftover->next = NULL;
      leftover->free = 1;

    } else {

      block_t* fresh = (block_t *) ptr;
      fresh->size = getpagesize()-BLOCK_SIZE;
      fresh->next = NULL;
      fresh->free = 0;
    }
  }
  //calculate the no of pages
  float pages = 0.0;
  pages = ((s+BLOCK_SIZE)/getpagesize());
  int page = roundup(pages);
  
  size_t size = (size_t)(page * getpagesize());
  block_t *ptr = (block_t *)mmap(NULL, s + BLOCK_SIZE, PROT_READ | PROT_WRITE, MAP_ANON | MAP_PRIVATE, -1, 0);
  if(ptr == (void *) -1) {
    printf("%s","null pointer");
    return NULL;
  }
  
  block_t* fresh = (block_t *) ptr;
  fresh->size = size;
  fresh->next = NULL;
  fresh->free = 0;
  return(fresh);
}

//My implementation of Malloc. Fills in a space with specificed amount of size.
void *mymalloc(size_t s) {
  pthread_mutex_lock(&myfunc_mtx);
  
  if (s <= 0) {
    return NULL;
    debug_printf("Cannot free 0 or negative space");
  }

  block_t *block = first_empty_search(s);
  void *pointer;

  if(block == NULL) {
    block = create_new_block(s);
  }

  pointer = (void*)(block + 1);

  if(pointer == NULL) {
    return NULL;
  }

  debug_printf("malloc %zu bytes\n", s);
  return pointer;
  pthread_mutex_unlock(&myfunc_mtx);
}


//My implementation of calloc. Fills in a requested space with specified amount of size with zeros.
void *mycalloc(size_t nmemb, size_t s) {
  pthread_mutex_lock(&myfunc_mtx);
  if(nmemb <= 0 || s <= 0) {
    debug_printf("can't allocate 0/negative elements and/or can't allocate 0/negative sized elements");
  }

  //uses mymalloc to create new pointer  
  void* pointer = mymalloc(s * nmemb);
  // Zeroes out the entire array
  memset(pointer, 0, s * nmemb);

  debug_printf("calloc %zu bytes\n", s * nmemb);
  return pointer;
  pthread_mutex_unlock(&myfunc_mtx);
}

//My implementation of free. Frees up the space indicated by the pointer.
void myfree(void *ptr) {
  
  pthread_mutex_lock(&myfunc_mtx);
  if(ptr == NULL) {
    //does nothing if the pointer is null.
    return;
    debug_printf("Cannot free a null pointer");

  } else {

    block_t* pt = (block_t *) ptr-1;
    //mark the block as free if it is smaller than the page size
    if (pt->size < getpagesize()){
      pt->free=1;

    } else { //otherwise unmap all the pages from memory (release from linked list)

      block_t *free_block = (block_t *) ptr - 1;
      munmap(free_block, free_block->size + BLOCK_SIZE);
    }
    debug_printf("Freed some memory\n");
  }
  pthread_mutex_unlock(&myfunc_mtx);
}
