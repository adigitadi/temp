#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#include <malloc.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf

typedef struct block
{
  size_t size;        // How many bytes beyond this block have been allocated in the heap
  struct block *next; // Where is the next block in your linked list
  int free;           // Is this memory free, i.e., available to give away?
  int debug;          // (optional) Perhaps you can embed other information--remember,
                      // you are the boss!
} block_t;
#define BLOCK_SIZE sizeof(block_t)

block_t *head = NULL;
block_t *tail = NULL;

block_t *getfreeblock(size_t size)
{
  block_t *curr = head;
  while (curr)
  {
    if (curr->free && curr->size >= size)
    {
      return curr;
    }
    curr = curr->next;
  }
  return NULL;
}

void *mymalloc(size_t s)
{

  int totalSize = BLOCK_SIZE + s;

  // First search free list
  block_t *curr = NULL;
  curr = getfreeblock(s);
  if (curr)
  {
    curr->free = 0;
    return (void *)(curr + 1);
  }
  // creat from heap by sbrk
  curr = sbrk(totalSize);
  if (curr == (void *)-1)
  {
    return NULL;
  }
  curr->size = s;
  curr->next = NULL;
  curr->free = 0; // 0 mallocted   1 is free
                  //  void *p = (void *) malloc(s); // In your solution no calls to malloc should be
                  //                               // made! Determine how you will request memory :)
  if (head == NULL && tail == NULL)
  {
    head = curr;
  }
  else
  {
    tail->next = curr;
  }
  tail = curr;

  void *p = curr + 1;
  debug_printf("malloc %zu bytes\n", s);

  return p;
}

void *mycalloc(size_t nmemb, size_t s)
{

  size_t size;
  void *p = NULL;

  if (!nmemb || !s)
  {
    return NULL;
  }
  size = nmemb * s;

  p = (void *)mymalloc(size);
  if (!p)
  {
    return NULL;
    // We are out of memory
    // if we get NULL back from malloc
  }
  debug_printf("calloc %zu bytes\n", s);

  memset(p, 0, size);
  return p;
}

void myfree(void *ptr)
{
  debug_printf("Freed some memory\n");

  block_t *p1 = head;
  block_t *curr = (block_t *)ptr - 1;

  while (p1)
  {
    if (p1 == curr)
    {
      curr->free = 1;
      return;
    }
    p1 = p1->next;
  }
  // Replace the free below with your own free implementation
}
