// based on cs3650 starter code
#include <assert.h>
#include <bsd/string.h>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>


#define FUSE_USE_VERSION 26

#include <fuse.h>

//Include helpers: bitmap struct, inode struct, slist struct
#include "helpers/bitmap.h"
#include "helpers/blocks.h"
#include "helpers/slist.h"

//Include helpers: directories, inodes, storage
#include "hints/directory.h"
#include "hints/inode.h"
#include "hints/storage.h"

// Macro to return the inode of the root directory
#define root_inode get_inode(0)

// Returns the deepest directory in the given path
dir_t *get_dir_from_path(const char *path) {
    //Find the last '/' in the path
    int last_pos = 0;
    int cnt = 0;
    while (path[cnt] != 0) {
        if (path[cnt] == '/') {
            last_pos = cnt;
        }
        cnt++;
    }

    // If path is '/' return the root directory
    if (last_pos == 0) {
        return blocks_get_block(2);
    }

    // Otherwise, format the name to only include the deepest directory
    char *dir_path = strdup(path);
    dir_path[last_pos] = '\0';

    // Find the directory and return it
    int inum = directory_lookup(root_inode, dir_path);
    inode_t *inode = get_inode(inum);
    return blocks_get_block(inode->block);
}

// Gets an object's attributes (type, permissions, size, etc).
// Implementation for: man 2 stat
// This is a crucial function.
int nufs_getattr(const char *path, struct stat *st) {
    int rv = 0;

    int inode_num = directory_lookup(root_inode, path);
    if (inode_num >= -1) {
        inode_t *inode = get_inode(inode_num);
        st->st_mode = inode->mode;
        st->st_size = inode->size;
        st->st_nlink = inode->refs;
        st->st_ino = inode_num;
        st->st_uid = getuid();
    } else {
        rv = -ENOENT;
    }

    printf("getattr(%s) -> (%d) {mode: %04o, size: %ld}\n", path, rv, st->st_mode,
           st->st_size);
    return rv;
}

// implementation for: man 2 access
// Checks if a file exists.
int nufs_access(const char *path, int mask) {
    int rv;

    int inum = directory_lookup(root_inode, path);
    if (inum >= -1 || strcmp(path, "/") == 0) {
        rv = 0;
    } else {
        rv = -ENOENT;
    }

    printf("access(%s, %04o) -> %d\n", path, mask, rv);
    return rv;
}

// implementation for: man 2 readdir
// lists the contents of a directory
int nufs_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
                 off_t offset, struct fuse_file_info *fi) {
    struct stat st;
    int rv;

    // Get the directory to read
    int inum = directory_lookup(root_inode, path);
    inode_t *inode = get_inode(inum);
    dir_t *read_dir = blocks_get_block(inode->block);

    // Read through the entries of the directory
    slist_t *tmp = directory_list(read_dir);
    while (tmp != NULL) {	
	rv = nufs_getattr(tmp->data, &st);
        assert(rv == 0);
        if (tmp->data[0] == '/') {
            char *data = s_tail(s_explode(tmp->data, '/'));
            filler(buf, data, &st, 0);
        } else {
            filler(buf, tmp->data, &st, 0);
        }
        tmp = tmp->next;
    }
    s_free(tmp);

    printf("readdir(%s) -> %d\n", path, rv);
    return rv;
}

// mknod makes a filesystem object like a file or directory
// called for: man 2 open, man 2 link
// Note, for this assignment, you can alternatively implement the create
// function.
int nufs_mknod(const char *path, mode_t mode, dev_t rdev) {
    int inum;
    int rv = -1;

    if ((mode & S_IFDIR) == S_IFDIR) {
        inum = directory_init(path);
    } else {
        int block_num = alloc_block();
        inum = alloc_inode();
        inode_t *inode = get_inode(inum);
        inode->mode = mode;
        inode->block = block_num;
    }

    dir_t *curr = get_dir_from_path(path);
    
    directory_put(curr, path, inum);
    //curr->entries = s_cons(path, inum, curr->entries);

    rv = nufs_access(path, 0);
    printf("mknod(%s, %04o) -> %d\n", path, mode, rv);
    return rv;
}

// most of the following callbacks implement
// another system call; see section 2 of the manual
int nufs_mkdir(const char *path, mode_t mode) {
    int rv = nufs_mknod(path, mode | 040000, 0);
    printf("mkdir(%s) -> %d\n", path, rv);
    return rv;
}

int nufs_unlink(const char *path) {
    int rv;

    //free inode if ref == 0
    int inode_num = directory_lookup(root_inode, path);
    inode_t *inode = get_inode(inode_num);

    //if there are no other references free the inode and block
    if (--inode->refs == 0) {
        free_block(inode->block);
        free_inode(inode_num);
    }

    //free from dir list
    dir_t *curr = get_dir_from_path(path);
    directory_remove(curr, path);

    assert(nufs_access(path, 0) != 0);
    rv = 0;

    printf("unlink(%s) -> %d\n", path, rv);
    return rv;
}

// Not required for the assignment
// Links two files together with a hard link (unimplemented)
int nufs_link(const char *from, const char *to) {
    int rv = 0;
    printf("link(%s => %s) -> %d\n", from, to, rv);
    return rv;
}


// Remove a directory
// Return error if the directory is not empty
int nufs_rmdir(const char *path) {
    int rv = -1;

    int inum = directory_lookup(root_inode, path);
    inode_t *inode = get_inode(inum);
    dir_t *rem_dir = blocks_get_block(inode->block);

    slist_t *tmp = directory_list(rem_dir); 
    while (tmp != NULL) {
        if (strcmp(tmp->data, ".") != 0 && strcmp(tmp->data, "..") != 0) {
            rv = -ENOTEMPTY;
            break;
        } else {
            rv = 0;
        }
        tmp = tmp->next;
    }
    s_free(tmp);

    if (rv == 0) {
        nufs_unlink(path);
    }

    printf("rmdir(%s) -> %d\n", path, rv);
    return rv;
}

// implements: man 2 rename
// called to move a file within the same filesystem
int nufs_rename(const char *from, const char *to) {
    int rv = -1;

    dir_t *curr = get_dir_from_path(from);
    int inum = directory_lookup(root_inode, from);
    
    directory_remove(curr, from);
    directory_put(curr, to, inum);

    rv = 0;
    printf("rename(%s => %s) -> %d\n", from, to, rv);
    return rv;
}

// Change the permissions of a directory or file
int nufs_chmod(const char *path, mode_t mode) {
    int rv = -1;

    int inode_num = directory_lookup(root_inode, path);
    assert(inode_num != -2);
    inode_t *inode = get_inode(inode_num);
    inode->mode = mode;
    rv = 0;

    printf("chmod(%s, %04o) -> %d\n", path, mode, rv);
    return rv;
}

// Reduce or increase the size of a file
int nufs_truncate(const char *path, off_t size) {
    int rv = -1;
    if (size > 4096) {
        return rv;
    }

    int inode_num = directory_lookup(root_inode, path);
    assert(inode_num != -2);
    inode_t *inode = get_inode(inode_num);
    inode->size = size;
    rv = 0;

    printf("truncate(%s, %ld bytes) -> %d\n", path, size, rv);
    return rv;
}

// This is called on open, but doesn't need to do much
// since FUSE doesn't assume you maintain state for
// open files.
// You can just check whether the file is accessible.
int nufs_open(const char *path, struct fuse_file_info *fi) {
    int rv = nufs_access(path, 0);
    printf("open(%s) -> %d\n", path, rv);
    return rv;
}

// Actually read data
int nufs_read(const char *path, char *buf, size_t size, off_t offset,
              struct fuse_file_info *fi) {
    int inode_num = directory_lookup(root_inode, path);
    assert(inode_num != -2);
    inode_t *inode = get_inode(inode_num);

    void *block = blocks_get_block(inode->block) + offset;
    int rv = size;
    memcpy(buf, block, size);

    printf("read(%s, %ld bytes, @+%ld) -> %d\n", path, size, offset, rv);
    return rv;
}

// Actually write data
int nufs_write(const char *path, const char *buf, size_t size, off_t offset,
               struct fuse_file_info *fi) {
    int inode_num = directory_lookup(root_inode, path);
    assert(inode_num != -2);
    inode_t *inode = get_inode(inode_num);
    inode->size = offset + size;

    void *block = blocks_get_block(inode->block) + offset;
    memcpy(block, buf, size);
    int rv = size;
    printf("write(%s, %ld bytes, @+%ld) -> %d\n", path, size, offset, rv);
    return rv;
}

// Update the timestamps on a file or directory.
int nufs_utimens(const char *path, const struct timespec ts[2]) {
    int rv = 0;
    printf("utimens(%s, [%ld, %ld; %ld %ld]) -> %d\n", path, ts[0].tv_sec,
           ts[0].tv_nsec, ts[1].tv_sec, ts[1].tv_nsec, rv);
    return rv;
}

// Extended operations
int nufs_ioctl(const char *path, int cmd, void *arg, struct fuse_file_info *fi,
               unsigned int flags, void *data) {
    int rv = -1;
    printf("ioctl(%s, %d, ...) -> %d\n", path, cmd, rv);
    return rv;
}

void nufs_init_ops(struct fuse_operations *ops) {
    memset(ops, 0, sizeof(struct fuse_operations));
    ops->access = nufs_access;
    ops->getattr = nufs_getattr;
    ops->readdir = nufs_readdir;
    ops->mknod = nufs_mknod;
    // ops->create   = nufs_create; // alternative to mknod
    ops->mkdir = nufs_mkdir;
    ops->link = nufs_link;
    ops->unlink = nufs_unlink;
    ops->rmdir = nufs_rmdir;
    ops->rename = nufs_rename;
    ops->chmod = nufs_chmod;
    ops->truncate = nufs_truncate;
    ops->open = nufs_open;
    ops->read = nufs_read;
    ops->write = nufs_write;
    ops->utimens = nufs_utimens;
    ops->ioctl = nufs_ioctl;
}

struct fuse_operations nufs_ops;

int main(int argc, char *argv[]) {
    assert(argc > 2 && argc < 6);

    //Mount data.nufs as data file
    storage_init(argv[--argc]); 

    //Initialize operations
    nufs_init_ops(&nufs_ops);
    return fuse_main(argc, argv, &nufs_ops, NULL);
}
