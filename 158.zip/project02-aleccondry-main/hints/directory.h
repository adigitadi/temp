#ifndef DIRECTORY_H
#define DIRECTORY_H

#define DIR_NAME_LENGTH 48

#include <string.h>
#include "../helpers/blocks.h"
#include "inode.h"
#include "../helpers/slist.h"

// Struct for a directory
typedef struct dir {
    char name[DIR_NAME_LENGTH];
    int inum;
    int num_entries;
} dir_t;

// Initialize a new directory with the given name
// Returns the inode number of the new directory
int directory_init(const char *dirname);

// Return the inode number associated with the given name or -2 if not found
int directory_lookup(inode_t *dd, const char *name);

// Print information about a directory referenced by its inode
void print_directory(inode_t *dd);

// Put a new entry into a given directory with the given name and inum
void directory_put(dir_t *dir, const char *name, int inum);

// Returns a list of all entries in the given directory
slist_t *directory_list(dir_t *dir);

// Remove an entry from the given directory
void directory_remove(dir_t *dir, const char *path);
#endif

