#include "storage.h"

// Initialize the data.nufs file and the root directory
void storage_init(const char *path) {
    if (access(path, F_OK) == 0) {
        blocks_init(path);
        return;
    }

    // Initialize blocks
    blocks_init(path);

    // Initialize enough blocks for 256 inodes
    int num_blocks = bytes_to_blocks(sizeof(inode_t) * 256);
    printf("sizeof(inode_t)=%ld, num_blocks=%d\n", sizeof(inode_t), num_blocks);
    while (num_blocks) {
        alloc_block();
        num_blocks--;
    }

    // Initialize root directory
    directory_init("/");
}
