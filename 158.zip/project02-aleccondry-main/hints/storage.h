// Disk storage manipulation.
//
// Feel free to use as inspiration.

// based on cs3650 starter code

#ifndef NUFS_STORAGE_H
#define NUFS_STORAGE_H

#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "inode.h"
#include "directory.h"
#include "../helpers/slist.h"
#include "../helpers/blocks.h"
#include <string.h>
#include <fcntl.h>

// Initialize the data.nufs file and the root directory
void storage_init(const char *path);

#endif
