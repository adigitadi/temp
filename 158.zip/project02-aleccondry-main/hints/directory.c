#include "directory.h"
#include <stdlib.h>

#define STR_LEN 48
#define INT_LEN 4
#define OFFSET 100

// Convert a given integer into an array of characters
char *int_to_char(int num) {
    char *str = (char *)malloc(INT_LEN);
    sprintf(str, "%d", num);
    printf("num = %s\n", str);
    return str;
}


// Initialize a new directory with the given name
// Returns the inum of the new directory
int directory_init(const char *dirname) {
    // Allocate a new inode and block for the directory
    int dir_inum = alloc_inode();
    int dir_block = alloc_block();

    // Get the directory and set the fields
    dir_t *dir = blocks_get_block(dir_block);
    strcpy(dir->name, dirname);
    dir->inum = dir_inum;

    // Add the directory references
    dir->num_entries = 0;
    directory_put(dir, ".", dir_inum);
    directory_put(dir, "..", -1);

    // Get the directory inode and set the fields
    inode_t *dir_inode = get_inode(dir_inum);
    dir_inode->refs = 1;
    dir_inode->mode = 040755;
    dir_inode->size = 4096;
    dir_inode->block = dir_block;
    return dir_inum;
}

// Return the inode number associated with the given name or -2 if not found
int directory_lookup(inode_t *dd, const char *name) {
    dir_t *dir = blocks_get_block(dd->block);
    if (strcmp(dir->name, name) == 0) {
        return dir->inum;
    }

    // Iterate through the given directory
    slist_t *tmp = directory_list(dir);
    while (tmp != NULL) {
        // If the name is equal to the current entry, return its inum
        if (strcmp(name, tmp->data) == 0) {
            return tmp->inum;
        }

        // If the current entry is a directory, search through it
        inode_t *inode = get_inode(tmp->inum);
        if ((inode->mode & 040000) == 040000 && strcmp(tmp->data, ".") != 0 && strcmp(tmp->data, "..") != 0) {
            int val = directory_lookup(inode, name);
            // Continue if the name was not found
            if (val != -2) {
                return val;
            }
        }
        tmp = tmp->next;
    }

    s_free(tmp);
    return -2;
}

// Put a new entry into a given directory with the given name and inum
void directory_put(dir_t *dir, const char *name, int inum) {
    // Find the position for the next name entry in the directory and copy in the name
    void *ptr = (void *)dir + OFFSET + (STR_LEN + INT_LEN) * dir->num_entries;
    memcpy(ptr, name, STR_LEN);

    // Find the position for the next inum entry in the directory and copy in the inum
    char *str_inum = int_to_char(inum);
    memcpy((void *) (ptr + STR_LEN), str_inum, INT_LEN);

    //Increment the number of entries
    dir->num_entries++;
}

// Returns a list of all entries in the given directory
slist_t *directory_list(dir_t *dir) {
    // Get a pointer to the first entry
    void *ptr = (void *)dir + OFFSET;

    // Extract the data from the pointer
    char *data = (char *)ptr;
    ptr = (void *)(ptr + 48);
    int inum = atoi((char *)ptr);
    slist_t *rest = s_cons(data, inum, NULL);

    // Add the remaining entries to the list
    for (int i = 1; i < dir->num_entries; i++) {
        ptr = (void *)dir + OFFSET + (STR_LEN + INT_LEN) * i;
        data = (char *)ptr;
        ptr = (void *)(ptr + STR_LEN);
        inum = atoi((char *)ptr);

        slist_t *list = s_cons(data, inum, rest);
        rest = list;
    }
    return rest;
}

// Remove an entry from the given directory
void directory_remove(dir_t *dir, const char *path) {
    int cnt = dir->num_entries - 1;
    slist_t *tmp = directory_list(dir);
    while (tmp != NULL) {	
        if (strcmp(tmp->data, path) == 0) {
            void *to_rem = (void *)dir + OFFSET + (STR_LEN + INT_LEN) * cnt;
            void *next = (void *)dir + OFFSET + (STR_LEN + INT_LEN) * (cnt + 1);

            //
            memmove(to_rem, next, (dir->num_entries - cnt) * (48 + 4));
            dir->num_entries--;
            s_free(tmp);
            return;
	    }
        cnt--;
        tmp = tmp->next;
    }
    s_free(tmp);
}

// Print information about a directory referenced by its inode
void print_directory(inode_t *dd) {
    dir_t *dir = blocks_get_block(dd->block);

    printf("Printing info about a directory:\n");
    print_inode(dd);
    printf("address of dir = %p\n", (void *) dir);
    printf("dirname = %s, inum = %d, bnum = %d\n", dir->name, dir->inum, dd->block);

    slist_t *entries = directory_list(dir);
    while (entries != NULL) {
        printf("%s\n", entries->data);
        entries = entries->next;
    }
}
