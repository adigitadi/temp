#include "inode.h"

// Print the information contained in a given inode
void print_inode(inode_t *node) {
    printf("refs=%d, mode=%d, size=%d, block=%d\n", node->refs, node->mode, node->size, node->block);
}

// Return the inode with the given number
inode_t *get_inode(int inum) {
     if (inum == -1) {
	inode_t *inode = blocks_get_block(1);
	return inode;
     }

     void *inode_table = blocks_get_block(1);
     inode_t *inode = inode_table + sizeof(inode_t) * inum;
     return inode;
}

// Allocate a new inode and return its index
int alloc_inode() {
    void *bm = get_inode_bitmap();
    int inode_index = 0;
    for (int i = 0; i < 256; i++) {
	if (!bitmap_get(bm, i)) {
	    printf("+ alloc_inode(%d)\n", i);
	    bitmap_put(bm, i, 1);
	    inode_index = i;
	    break;
	}
    }
    void *inode_table = blocks_get_block(1);
    inode_t *inode_alloc = inode_table + inode_index * sizeof(inode_t);
    inode_alloc->refs = 1;
    inode_alloc->mode = 0;
    inode_alloc->size = 0;
    inode_alloc->block = -1;
    return inode_index;
}


// Free an inode using its inode number
// Sets the given inum in the bitmap to zero
void free_inode(int inum) {
   printf("+ free inode(%d)\n", inum);
   void *bm = get_inode_bitmap();
   bitmap_put(bm, inum, 0);
}
