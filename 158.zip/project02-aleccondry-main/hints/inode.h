// Inode manipulation routines.
//
// Feel free to use as inspiration.

// based on cs3650 starter code

#ifndef INODE_H
#define INODE_H

#include <assert.h>
#include "../helpers/blocks.h"
#include "../helpers/bitmap.h"

typedef struct inode {
    int refs;  // reference count
    int mode;  // permission & type
    int size;  // bytes
    int block; // single block pointer (if max file size <= 4K)
} inode_t;

// Print the information contained in a given inode
void print_inode(inode_t *node);

// Return the inode with the given number
inode_t *get_inode(int inum);

// Allocate a new inode and return its index
int alloc_inode();

// Free an inode using its inode number
// Sets the given inum in the bitmap to zero
void free_inode(int inum);

#endif
