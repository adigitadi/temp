// based on cs3650 starter code

#include <alloca.h>
#include <stdlib.h>
#include <string.h>

#include "slist.h"
#include <math.h>

// Cons a string to a string list.
slist_t *s_cons(const char *text, int inum, slist_t *rest) {
    slist_t *xs;
    xs = malloc(sizeof(slist_t));

    xs->data = strdup(text);
    xs->inum = inum;
    xs->next = rest;
    return xs;
}

// Free the given string list.
void s_free(slist_t *xs) {
    if (xs == 0) {
        return;
    }

    s_free(xs->next);
    free(xs->data);
    free(xs);
}

// Split the given on the given delimiter into a list of strings.
slist_t *s_explode(const char *text, char delim) {
    if (*text == 0) {
        return 0;
    }

    int plen = 0;
    while (text[plen] != 0 && text[plen] != delim) {
        plen += 1;
    }

    int skip = 0;
    if (text[plen] == delim) {
        skip = 1;
    }

    slist_t *rest = s_explode(text + plen + skip, delim);
    char *part = alloca(plen + 2);
    memcpy(part, text, plen);
    part[plen] = 0;

    return s_cons(part, -1, rest);
}

// Return the data contained in the tail of the given list
char *s_tail(slist_t *list) {
    slist_t *tmp = list;
    while (tmp->next != NULL) {
        tmp = tmp->next;
    }
    return tmp->data;
}
