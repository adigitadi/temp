#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h> 
#include <stdio.h> 

// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <debug.h> // definition of debug_printf
#define BLOCK_SIZE sizeof(block_t)
typedef struct block block_t;
block_t *head_block = NULL;
block_t *block_search(size_t s, block_t **tail);
block_t *block_alloc(size_t s, block_t *tail);

// List structure
// size - size of the block
// next - pointer to the next block in a list
// free - if this block is free
struct block {
  size_t size;
  struct block *next;
  int free;
};

// First fit search
// s - size
// **tail - pointer to head_block
// return NULL or right block
block_t *block_search(size_t s, block_t **tail) {
  block_t *iter = head_block; // init iterator
  while (iter && !(iter->free && iter->size >= s)) { // check conditions
    *tail = iter; // move list pointer
    iter = iter->next; // iterate
  }
  return iter;
}

// Allocate block
// s - size
// tail - tail block
// return - block or NULL
block_t *block_alloc(size_t s, block_t *tail) {
  block_t *block; // init block
  block = sbrk(0); // get current heap end
  void *block_size = sbrk(BLOCK_SIZE + s); // request more memory
  assert((void *) block == block_size); // check memory
  if (block_size == (void *) -1) { // if failed
    return NULL;
  }
  if (tail) { // if not first block
    tail->next = block;
  }
  block->size = s;
  block->next = NULL;
  block->free = 0;
  return block;
}

// Custom malloc
void *mymalloc(size_t s) {
  block_t *p;
  if (s <= 0) { // check size
    return NULL;
  }
  if (!head_block) { // if first block
    p = block_alloc(s, NULL); // alloc
    if (!p) { // if failed
      return NULL;
    }
    head_block = p; // init head_block
  }
  else {
    block_t * tail = head_block; // track the tail block
    p = block_search(s, &tail); // first fit search
    if (!p) { // if failed
      p = block_alloc(s, tail); // new alloc
      if (!p) { // if failed
        return NULL;
      }
    }
    else { // if worked use the memory
      p->free = 0;
    }
  }
  debug_printf("Malloc %zu bytes\n", s);
  return (p+1); // points to the start of data
}

// Custom calloc
void *mycalloc(size_t nmemb, size_t s) {
  size_t size = nmemb * s; // get full size
  void * p = mymalloc(size); // malloc needed size
  memset(p, 0, size); // fill with 0
  debug_printf("Calloc %zu bytes\n", s);
  return p;
}

// Custom free
void myfree(void *ptr) {
  if (!ptr) { // if no ptr
    return;
  }
  block_t * block_ptr = (block_t *)ptr - 1; // get block ptr
  block_ptr->free = 1; // free it
  debug_printf("Freed %zu bytes\n", block_ptr->size);
}
