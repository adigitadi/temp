#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h> 
#include <stdio.h> 
#include <string.h>
#include <unistd.h>

// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf

typedef struct block {
	size_t size;
	struct block *next;
	int free;
} block_t;

#define BLOCK_SIZE sizeof(block_t)
block_t *top;

/*
 * Allocates memory of size s bytes and returns a pointer to the start of the allocated memory
 * Parameters
 * 	size_t s - unsigned long of the number of bytes to allocate
 * Returns
 * 	void pointer to the start of the allocated memory, NULL if memory could not be allocated
 */
void *mymalloc(size_t s) {
	block_t *head = top;
	if (!top) {
		// Heap is empty
    		top = (block_t*)sbrk(BLOCK_SIZE + s);
		if (top == (block_t*)-1) return NULL;
		top->size = s;
		top->next = NULL;
		top->free = 0;
		head = top;
  	} else {
		block_t *prev = head;
		while(head != NULL && !(head->free && (head->size > BLOCK_SIZE + s || head->size == s))) {
			prev = head;
			head = head->next;
		}

		if(head == NULL) {
			// Large enough block not found, expand program break
			block_t *last = (block_t*) sbrk(BLOCK_SIZE + s);
			prev->next = last;
			last->size = s;
			last->next = NULL;
			last->free = 0;
			head = last;
		} else if(head->size == s) {
                	// Block of exact specifed size found
			head->free = 0;
                } else {
			// Big enough block found, need to split into allocated block and free block
                	block_t *next = head->next;
                       	int remainder_size = head->size - BLOCK_SIZE - s;
                       	head->size = s;
			head->free = 0;

                       	block_t *new_next = (block_t*)((void*)head + BLOCK_SIZE + s);
			head->next = new_next;
                       	new_next->size = remainder_size;
                       	new_next->next = next;
                       	new_next->free = 1;		
		}
 	
	}
	
	head += 1;
  	debug_printf("malloc %zu bytes\n", s);
  	return (void*)head;
}

/*
 *	Allocates nmemb * s bytes of memory, clears the region and returns pointer to the allocated memory
 *	Parameters
 *		size_t nmemb - unsigned long of number of units to allocate
 *		size_t s - unsigned long of size of each unit in bytes
 *	Returns
 *		pointer to the start of the allocated memory, NULL if memory could not be allocated	
 */
void *mycalloc(size_t nmemb, size_t s) {
	void *pointer = mymalloc(nmemb * s);
	
	if(pointer == NULL) return NULL;

	memset(pointer, 0, nmemb * s);
	debug_printf("calloc %zu bytes\n", s);
	return pointer;
}

/*
 * 	Frees the memory region specified by the given pointer, assumes pointer is valid
 * 	Parameters
 * 		void *ptr - Pointer to the region of memory to be freed
 * 	Returns
 * 		nothing
 */
void myfree(void *ptr) {
        block_t *block = (block_t*)ptr - 1;
	int s = block->size;
	block->free = 1;

	block_t *head = top;
	while(head->next != NULL) {
		block_t *after = head->next;
		if(head->free && after->free) {
			head->size += BLOCK_SIZE + after->size;
			head->next = after->next;
		}
		head = after;
	}
	debug_printf("freed %zu bytes\n", s);
}
