#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h> 
#include <stdio.h> 
#include <unistd.h>
#include <assert.h>
// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf
#define BLOCK_SIZE sizeof(block_t)

// A represenatation of a block in memory. It will be where we allocate data
typedef struct block {
       	size_t size; // the size of the block, in bytes
	struct block *next; //a pointer to the next block in memory
	int free; // A flag that details whether this block is free or used at the moment
	int debug; // A flag that can be used to imbed certain information
} block_t;

//The head block that we use to store memory
block_t *head;

// A custom version of Malloc, it allocates as much memory as the user requests
// size_t s: the amount of memory requested
// returns a pointer to the memory that is requested, if that memory can be obtained, otherwise it returns a NULL
void *mymalloc(size_t s) {
	// Checks whether the head of the list has been initialized
	// If it isn't then we know that this is the first time that memory has been requested 
	 if (head == NULL) {
		head = (block_t *) sbrk(s + BLOCK_SIZE);
		if(!head) {//checks whether we could obtain the amount of memory requested
			debug_printf("could not malloc %zu bytes\n", s);
			return NULL;
		}
		else {
			head->size = s;
			head->free = 0;	
			head->next = NULL;
			debug_printf("malloc %zu bytes\n", s);
			return (void *) head + BLOCK_SIZE;
		}
	}
	else {//in this else, we know that this isnt the first time memory has been requested by the program
	      //therefore, we can parse through the list of memory blocks, trying to find a block we can provide to
	      //the requester

		block_t* current = head;
		int foundSpace = 0;
		block_t* result = NULL;	
		while (!foundSpace) {
			//ensure there aren't any scenarios where the size of the block is -1
			assert(current->size != -1);

			//basically checks whether or not we are at the end of the list of blocks and
			//if the size of the block can't support the user's requests. In such a scenario,
			//we just create a new block at the end of the list and allocate memory there
			if ((current->free == 0 && current->next == NULL) ||
					(current->free == 1 && current->size < s && current->next == NULL)) {	
				block_t *newBlock = (block_t *) sbrk(s + BLOCK_SIZE);
				if(!newBlock) {
					break;
				}

				newBlock->size = s;
				newBlock->next = NULL;
				current->next = newBlock;
				newBlock->free = 0;
				foundSpace = 1;
				result = (void *) newBlock + BLOCK_SIZE;
			}
			//checks if we cant allocate memory here or if the block is already used
			else if (current->size < s || current->free == 0) {
				current = current->next;
			}
			//checks if the size of the block is also the size of the memory requsted
			else if(current->size == s ){
				
				current->free = 0;
				foundSpace = 1;
				result = (void *) current + BLOCK_SIZE;
			}
			//checks if there is more space available that what is requested. In such a situation we 
			//split the blocks into two. I know we're not required but I thought it would be neater and that
			//it would be a good exercise for  me
			else if(current->size > s ){
				block_t *newBlock = (block_t *) sbrk(s + BLOCK_SIZE);
				if(!newBlock) {
					break;
				}
				newBlock->size = s;
				newBlock->next = current->next;
				current->size = current->size - s;
				newBlock->free = 0;
				current->next = newBlock;
				foundSpace = 1;
				result =(void *) newBlock + BLOCK_SIZE;
			}
				}
		//If space was found, we know that malloc was succesful
		if(foundSpace) {
			debug_printf("malloc %zu bytes\n", s);
			return result;
		}
		//Otherwise, we know that space could not be allocated, therefore malloc failed
		else {
			debug_printf("could not malloc %zu bytes\n", s);
			return NULL;
		}
	}
}


//A custom version of calloc, it allocates memory for the user but also zeroes everything out
//size_t nmeb: The blocks of memory requested
//s: The size of the blocks of memory
//Returns a pointer to a block of memory if successful, otherwise NULL 
void *mycalloc(size_t nmemb, size_t s) {

	//Mallocs the memory requested
      	int *p =  (int *) mymalloc(nmemb * s);

	//If malloc returns null, we know that space couldnt be allocated
      	if(!p) {
      		return NULL;
      	}

	//Zeroes out all the values
      	for(int i = 0; i < nmemb; i++) {
      		p[i] = 0;
	}
       	debug_printf("calloc %zu bytes\n", s);
      	return p;
}


//A custom implementation of free, it frees up allocated memory on the list of blocks 
//ptr: the pointer to the block in memory that needs to be freed
//Does not return anything
void myfree(void *ptr) {
	assert(ptr != NULL);

	//we must ensure that we are freeing up data that has been allocated
	assert(head != NULL);

	// the current block we are parsing
	block_t* current = head;
	int found = 0;
	//Parses the list of blocks to find the block that needs to be freed
	while(current != NULL) {

		//checks whether the current block doesnt hold the data, so we skip it
		if((void *)current + BLOCK_SIZE  != ptr || current->free == 1) {
			current = current->next;
		}
		//if it does, just to make sure, we run a check to see if this is the first time we are freeing data
		//I know this is unneccessary but hey it works
		else if (found == 0) {
			current->free = 1;
			found = 1; 
			debug_printf("Freed some memory\n");
			break;	
		}
		//in case something goes wrong
		else {
			current = current->next;
		}
	}
	//This is only true when the pointer could not be found
	if (found == 0) {
		debug_printf("pointer not found\n");
		}
}
