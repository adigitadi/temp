#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#include <malloc.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <debug.h> // definition of debug_print
#include <sys/mman.h>
#include <pthread.h>

typedef struct block
{
  size_t size;           // How many bytes beyond this block have been allocated in the heap
  struct block *next;    // Pointer to the next block in the heap
  int free;              // Is this block free?
  pthread_mutex_t mutex; // Mutex lock
} block_t;

static block_t *head = NULL; // Pointer to the first block in the heap

#define BLOCK_SIZE sizeof(block_t) // Size of a block in the heap
#define PAGE_SIZE 4096             // Size of a page in the heap

// Allocates s bytes and returns a pointer to the allocated memory
void *mymalloc(size_t s)
{
  assert(s > 0);

  pthread_mutex_lock(&head->mutex);

  // If the request is larger than a page, allocate a page for it
  if (s > PAGE_SIZE - BLOCK_SIZE)
  {

    int pages_needed = (s + BLOCK_SIZE) / PAGE_SIZE + 1;

    block_t *block = mmap(NULL, pages_needed * PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    if (block == MAP_FAILED)
    {
      pthread_mutex_unlock(&head->mutex);
      return NULL;
    }

    block->size = pages_needed * PAGE_SIZE - BLOCK_SIZE;
    block->next = NULL;
    block->free = 0;

    pthread_mutex_unlock(&head->mutex);

    debug_printf("malloc %zu bytes\n", s);
    return (void *)(block + 1);
  }
  else
  {
    // If the request is smaller than a page, allocate a block from the heap
    block_t *current = head;
    block_t *prev = NULL;

    // Find a free block that is large enough

    while (current != NULL && !(current->free && current->size >= s))
    {
      prev = current;
      current = current->next;
    }

    // If no free block is large enough, allocate a new block
    if (current == NULL)
    {

      // Allocate a new block
      block_t *block = mmap(NULL, PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

      if (block == MAP_FAILED)
      {
        pthread_mutex_unlock(&head->mutex);
        return NULL;
      }

      block->size = PAGE_SIZE - BLOCK_SIZE;
      block->next = NULL;
      block->free = 0;

      // If this is the first block, set it as the head
      if (prev == NULL)
      {
        head = block;
      }
      else
      {
        prev->next = block;
      }

      current = block;
    }

    // If the block is larger than the requested size, split it
    if (current->size > s + BLOCK_SIZE)
    {
      block_t *new_block = (block_t *)((char *)current + BLOCK_SIZE + s);
      new_block->size = current->size - s - BLOCK_SIZE;
      new_block->next = current->next;
      new_block->free = 1;

      current->size = s;
      current->next = new_block;
    }

    current->free = 0;

    pthread_mutex_unlock(&head->mutex);
    debug_printf("malloc %zu bytes\n", s);
    return (void *)(current + 1);
  }
}

// Allocates memory for an array of nmemb elements of size s each and returns a pointer to the allocated memory
void *mycalloc(size_t nmemb, size_t s)
{
  assert(nmemb > 0);
  assert(s > 0);
  size_t size = nmemb * s;

  void *ptr = mymalloc(size);
  memset(ptr, 0, size);
  debug_printf("calloc %zu bytes\n", s);

  return ptr;
}

// Frees the memory space pointed to by ptr
void myfree(void *ptr)
{
  assert(ptr != NULL);

  pthread_mutex_lock(&head->mutex);

  block_t *block = (block_t *)ptr - 1; 

  // if block size is greater than page size, use munmap
  if (block->size + BLOCK_SIZE >= PAGE_SIZE)
  {
    munmap(block, block->size + BLOCK_SIZE);
  }
  else
  {
    block->free = 1;

    mycoalesce();
  }

  pthread_mutex_unlock(&head->mutex);
  debug_printf("Freed some memory\n");
}

// Coalesces adjacent free blocks
void mycoalesce()
{
  block_t *current = head;

  while (current->next != NULL)
  {
    if (current->free && current->next->free)
    {
      if (((void *)current) + BLOCK_SIZE + current->size == (void *)current->next)
      {
        if (current->size + current->next->size + BLOCK_SIZE <= PAGE_SIZE)
        {

          current->size += BLOCK_SIZE + current->next->size;
          current->next = current->next->next;
          break;
        }
      }
    }
    current = current->next;
  }
}
