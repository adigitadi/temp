(This is a template. Delete this line and fill in the sections below)
# Threaded Merge Sort Experiments


## Host 1: Khoury VM

- CPU: Intel(R) Xeon(R) Silver 4214R CPU @ 2.40GHz
- Cores: 12
- Cache size (if known):
- RAM: 384 GB??
- Storage (if known): 
- OS: Linux

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*


### Experiments

*Replace X, Y, Z with the number of threads used in each experiment set.*

#### 4 Threads

Command used to run experiment: ``

Sorting portion timings:

1. 0.014041 seconds
2. 0.010387 seconds
3. 0.008824 seconds
4. 0.005223 seconds

#### 8 Threads

Command used to run experiment: ``

Sorting portion timings:

1. 0.007791 seconds
2. 0.000395 seconds
3. 0.008472 seconds
4. 0.003489 seconds

#### 16 Threads

Command used to run experiment: ``

Sorting portion timings:

1. 0.016929 seconds
2. 0.000433 seconds
3. 0.022201 seconds
4. 0.003328 seconds

*repeat sections as needed*


## Host 1: Khoury VM

- CPU: Apple M1
- Cores: 8
- Cache size (if known):
- RAM: 16 GB
- Storage (if known): 
- OS: Mac OS

DOES NOT COMPILE

## Observations and Conclusions

*Reflect on the experiment results and the optimal number of threads for your concurrent merge sort implementation on different hosts or platforms. Try to explain why the performance stops improving or even starts deteriorating at certain thread counts.*


