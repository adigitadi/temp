#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#include <malloc.h>
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <sys/mman.h>
#include <pthread.h>
#include <stdint.h>

// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf


// block_t behaves and used as linked list
typedef struct block {
  size_t size;        // How many bytes beyond this block have been allocated in the heap
  size_t current_used_size; // How many bytes beyond this block is used, for keeping track of reused blocks
  struct block *next; // Where is the next block in your linked list
  struct block *free_next; // Where is the next block in your free lsit if it is free
  int free;           // Is this memory free, i.e., available to give away? 0 is freed
} block_t;

#define BLOCK_SIZE sizeof(block_t)

// beginning of linked list
block_t *head = NULL;

// beginning of free list
block_t *free_head = NULL;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

#define PAGE_SIZE sysconf(_SC_PAGESIZE)
#define CEIL(X) ((X - (int)(X)) > 0 ? (int)(X + 1) : (int)(X))

/**
 * Sets a block and allocates given size of btyes after it
 * Returns the pointer to the start of block memory
*/
block_t *allocate(size_t size) {
  void *mem = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
  assert(mem != (void*)-1);
  block_t *block = (block_t *) mem;
  
  block->free = 1;
  block->size = size;
  block->current_used_size = size;
  block->next = NULL;
  block->free_next = NULL;
  return block;
}

/**
 * Find previously made block that is now free at least the given size to reuse
 * Follows first-fit strategy
*/
block_t *findSpaceToStore(size_t size) {
  block_t *prevFreedBlock = free_head;
  
  // traverse linked list
  while (prevFreedBlock) {
  
    if (prevFreedBlock->free == 0 && prevFreedBlock->size >= size) {
      // usable block found
      return prevFreedBlock;
    }

    prevFreedBlock = prevFreedBlock->free_next;
  }
  // no space found, return NULL
  return prevFreedBlock;
}

/**
 * Allocate block of given size and add it to very end of linked list
*/
block_t *addToEnd(size_t size) {

  // allocate new block
  block_t *newBlock;
  newBlock = allocate(size);
  assert(newBlock);

  if (!head) {
    head = newBlock;
    return newBlock;
  }
  block_t *last = head;

  // get last block in linked list
  while (last->next) {
    last = last->next;
  }
  
  // set current last block's next to new block
  last->next = newBlock;

  return newBlock;
}


/**
 * Retrieve the prev block to the given block in the free list
*/
block_t *get_free_prev(block_t *block) {

  block_t *prev = NULL;
  block_t *curr = free_head;

  while (curr->free_next && curr != block) {
    prev = curr;
    curr = curr->free_next;
  }
  return prev;
}

/**
 * Remove the given block from the free list and connect its prev and next blocks
*/
void remove_block_from_free_list(block_t *block) {

  // given block is first
  if (block == free_head) {
    // given block is only block in list
    if (!block->free_next) {
      free_head = NULL;
    }
    else {
      free_head = block->free_next;

    }
  }
  else {
    // given block is not first
    block_t *prev = get_free_prev(block);
    // should not be NULL since we already check if given block is head
    assert(prev != NULL);
    if (!block->free_next) {
      // block is last
      prev->free_next = NULL;
    }
    else {
      // block is somewhere in middle
      prev->free_next = block->free_next;
    }
  }
  block->free_next = NULL;
}

/**
 * Retrieve the prev block to the given block in the linked list
*/
block_t *get_prev(block_t *block) {

  block_t *prev = NULL;
  block_t *curr = head;
  
  while (curr->next && curr != block) {
    prev = curr;
    curr = curr->next;
  }

  return prev;
}

/**
 * Remove the given block from the linked list and connect its prev and next blocks
*/
void remove_block_from_list(block_t *block) {

  // given block is first
  if (block == head) {
    // given block is only block in list
    if (!block->next) {
      head = NULL;
    }
    else {
      head = block->next;

    }
  }
  else {
    // given block is not first
    block_t *prev = get_prev(block);
    // should not be NULL since we already check if given block is head
    assert(prev != NULL);
    if (!block->next) {
      // block is last
      prev->next = NULL;
    }
    else {
      // block is somewhere in middle
       prev->next = block->next;
    }
  }
  block->next = NULL;
 }

/**
 * Combine the memory of the given block to its neighbors if they are next to each other in memory
*/
void coalesce(block_t *block) {

  block_t *prev = get_free_prev(block);
  if (prev && prev->free == 0 && prev->next == block) {
    // Merge with previous block.
    remove_block_from_free_list(block);
    assert(block->free_next == NULL);
    remove_block_from_list(block);
    assert(block->next == NULL);
    // Add size of current block to the size of prev block
    prev->size += block->size + BLOCK_SIZE;
  }

  block_t *next = block->free_next;
  if (next && next->free == 0 && block->next == next) {
    // merge with next block.
    remove_block_from_free_list(next);
    assert(next->free_next == NULL);
    remove_block_from_list(next);
    assert(next->next == NULL);
    // Add size of next block to the size of current block.
    block->size += next->size + BLOCK_SIZE;
  }

}

/**
 * Add the given block to the free list so that free list is in order of memory
*/
void append_to_free_list(block_t *block) {
  assert(block->free == 0);

    if (!free_head) {
        // no freed block yet
        free_head = block;
    } else {
      // get addresses where given block's address in between
        block_t *f_prev = NULL;
        block_t *f_next = free_head;
        while (f_next && f_next < block) {
          f_prev = f_next;
          f_next = f_next->free_next;
        }

        if (f_prev) {
          // set prev
          f_prev->free_next = block;
        }
        else {
          // if given block comes before head
          free_head = block;
        }
        // set next
        block->free_next = f_next;
    }
}

/**
 * Spilt the memory of the the given block to ift the given size to allocate and make a new block with the rest of the orginial block's memory
*/
void split(block_t *start_block, int size_to_allocate) {

    void *new_block_pointer = (void *)start_block + size_to_allocate + BLOCK_SIZE;
    size_t new_block_size = start_block->size - size_to_allocate;
    block_t *block = (block_t *) new_block_pointer;
    
    
    if (new_block_size < BLOCK_SIZE) {
        return;
    }

    start_block->free = 1;
    start_block->size = size_to_allocate;
    start_block->current_used_size = size_to_allocate;
    start_block->free_next = NULL;
    block->next = NULL;
    start_block->next = block;

    block->free = 0;
    block->size = new_block_size;
    block->current_used_size = 0;
    block->free_next = start_block->free_next;

    append_to_free_list(block);
}

/**
 * Implement malloc
 * Allocate given size of btyes and returns pointer to memory
*/
void *mymalloc(size_t s) {
  pthread_mutex_lock(&mutex);

  // pointer represents start of memory
  void *p;

  // allocates first block, the head of linked list
  if ((s + BLOCK_SIZE) < PAGE_SIZE) {
    // get block freed block of at least size
    block_t *newBlock = findSpaceToStore(s);

    // if exist
    if (newBlock) {
      assert(newBlock->free == 0);
      newBlock->free = 1;
      newBlock->current_used_size = s;

      if (newBlock->size > s) {
         split(newBlock, s);
      }
      remove_block_from_free_list(newBlock);
    }
    // if does not exist
    else {
      newBlock = addToEnd(PAGE_SIZE);
      newBlock->current_used_size = s;
      if (!newBlock) {
        pthread_mutex_unlock(&mutex);
        return NULL;
      }
    }

    // assigns pointer to start of memory gotten from addToEnd or findSpaceToStore
    p = newBlock;
  }
  else {
    // number of pages * PAGE_SIZE
    // get number of pages needed
    int size = CEIL((s + BLOCK_SIZE)/ (double)PAGE_SIZE) * PAGE_SIZE;
    block_t *newBlock = addToEnd(size);
    newBlock->current_used_size = s;
    if (!newBlock) {
     pthread_mutex_unlock(&mutex);
      return NULL;
    }
    p = newBlock;
  }

  if (!p) {
    // We are out of memory
    // if we get NULL back from malloc
    pthread_mutex_unlock(&mutex);
    return NULL;
  }

  debug_printf("Malloc %zu bytes\n", s);

  pthread_mutex_unlock(&mutex);

  // returns starting btye of allocation plus BLOCK_SIZE to account for the header
  // if BLOCK_SIZE was not added, header vriable will be reassigned when data is adding to byte
  return p + BLOCK_SIZE;
}

/**
 * Implements calloc
 * Allocates number of elements of size and initializes memory to 0
*/
void *mycalloc(size_t nmemb, size_t s) {

    pthread_mutex_lock(&mutex);

    assert(nmemb != 0);
    assert(s != 0);

    // call malloc of needed size
    void *p = mymalloc(nmemb * s);
    // initalizes all memory to 0
    memset(p, 0, nmemb * s);

  if (!p) {
    // We are out of memory
    // if we get NULL back from malloc
    pthread_mutex_unlock(&mutex);
    return NULL;
  }
  debug_printf("Calloc %zu bytes\n", s);

  pthread_mutex_unlock(&mutex);

  // pointer is already shift by BLOCK_SIZE in mymalloc so not need to do again
  return p;
}

/**
 * Implements free
 * Free memory at pointer
*/
void myfree(void *ptr) {

    pthread_mutex_lock(&mutex);

    if (ptr == NULL) {
        pthread_mutex_unlock(&mutex);
        return;
    }

  // get header of memory
  block_t *freeBlock = ptr - BLOCK_SIZE;
  
  // check if this block is already free
  assert(freeBlock->free == 1);
  freeBlock->free = 0;

  // assigns block as free
  debug_printf("Freed %zu bytes\n", freeBlock->current_used_size);

  if (freeBlock->size < PAGE_SIZE) {
    append_to_free_list(freeBlock);
    coalesce(freeBlock);
  }
  else {
    remove_block_from_list(freeBlock);
    int unmap = munmap(freeBlock, freeBlock->size);
    assert(unmap == 0);
  }

  pthread_mutex_unlock(&mutex);
}
