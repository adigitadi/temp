#include <string.h>
#include <errno.h>
// Helper inclusions
#include "slist.h"
#include "blocks.h"
// Hint inclusions
#include "inode.h"
#include "directory.h"

/**
 * Void method to initialize the directory.
 */
void directory_init() {
    inode_t* root = get_inode(alloc_inode());
    // owner has write, everyone else has read/execute
    root->mode = 040755;
}

/**
 * Look for a given directory.
 *
 * @param dd the desired directory
 * @param name the desired path
 * @return int representing status or directory id
 */
int directory_lookup(inode_t* dd, const char* name) {
    if (!strcmp(name, "")) {
        return 0;
    }
    dirent_t* sub_directories = blocks_get_block(dd->mblock[0]);
    for (int ii = 0; ii < 48; ++ii) {
        if (strcmp(name, sub_directories[ii].name) == 0 && sub_directories[ii].active) {
            return sub_directories[ii].inum;
        }
    }
    // Return fail on no match
    return -1;
}

/**
 * Searches for a given item in the tree.
 * @param path the item being searched for
 * @return int representing status or node id
 */
int tree_lookup(const char* path) {
    int nd = 0;
    slist_t* list_of_files = s_explode(path, '/');
    slist_t* current_directory = list_of_files;
    while (current_directory != NULL) {
        nd = directory_lookup(get_inode(nd), current_directory->data);
        // unsuccessful search - return -1
        if (nd == -1) {
            s_free(list_of_files);
            return -1;
        }
        current_directory = current_directory->next;
    }
    s_free(list_of_files);
    return nd;
}

/**
 * Places a new directory entry pointing to the given inode from the given location
 *
 * @param dd desired directory
 * @param name path
 * @param inum inum for new directory
 * @return
 */
int directory_put(inode_t* dd, const char* name, int inum) {
    int entry_count = dd->size / sizeof(dirent_t);
    dirent_t* entry_blocks = blocks_get_block(dd->mblock[0]);
    dirent_t desired_node;
    strncpy(desired_node.name, name, DIR_NAME_LENGTH);
    desired_node.inum = inum;
    desired_node.active = 1;
    int alloc_status = 0;
    // Assign blocks when directory's space is not taken (i.e. not active)
    for (int ii = 1; ii < dd->size / sizeof(dirent_t); ++ii) {
        if (entry_blocks[ii].active == 0) {
            entry_blocks[ii] = desired_node;
            alloc_status = 1;
        }
    }
    if (alloc_status == 0) {
        entry_blocks[entry_count] = desired_node;
        dd->size = dd->size + sizeof(dirent_t);
    }
    return 0;
}

// Dereferences the directory from the node structure, effectively deleting it
int directory_delete(inode_t* dd, const char* name) {
    dirent_t* entry_blocks = blocks_get_block(dd->mblock[0]);
    for (int ii = 0; ii < dd->size / sizeof(dirent_t); ++ii) {
        if (strcmp(entry_blocks[ii].name, name) == 0) {
            inode_modify_refs(entry_blocks[ii].inum);
            entry_blocks[ii].active = 0;
            return 0;
        }
    }
    // in case we can't delete the directory
    return -ENOENT;
}

// Returns the list of directories connected to the given directory
struct slist* directory_list(const char* path) {
    // get current node
    inode_t* nd = get_inode(tree_lookup(path));
    // get current directory entries
    dirent_t* directory_blocks = blocks_get_block(nd->mblock[0]);
    // get number of directories
    int directory_count = nd->size / sizeof(dirent_t);
    slist_t * directory_names = NULL;
    for (int ii = 0; ii < directory_count; ++ii) {
        if (directory_blocks[ii].active) {
            directory_names = s_cons(directory_blocks[ii].name, directory_names);
        }
    }
    return directory_names;
}

// print_directory() is commented out because it doesn't seem to do
// anything related to the tests and/or functionality of the file system.

/*
// Prints the given directory
void print_directory(inode_t* dd) {
    int directory_count = dd->size / sizeof(dirent_t);
    dirent_t* directory_blocks = blocks_get_block(dd->mblock[0]);
    for (int ii = 0; ii < directory_count; ++ii) {
        //printf("%s\n", directory_blocks[ii].name);
    }
}
*/
