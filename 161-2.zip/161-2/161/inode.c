/* inode.c */
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "inode.h"
#include "bitmap.h"
#include "blocks.h"

const int INODE_COUNT = 128;
const int INODE_SIZE = 256;

void print_inode(inode_t *node) {
  struct tm * timeinfo;
  char path[229];
  time_t time[4] = {node->time, node->ctime, node->mtime, node->dtime };

  printf("Ref\t%d\n", node->refs);
  printf("mode\t%07o\n", node->mode);
  printf("uid\t%d\n", node->uid);
  printf("size\t%d\n", node->size);
  // timeinfo = localtime ( (time_t*)&node->time );
  printf("time\t%s", ctime(&time[0]));
  // timeinfo = localtime ( (time_t*)&node->ctime );
  printf("ctime\t%s", ctime(&time[1]));
  // timeinfo = localtime ( (time_t*)&node->mtime );
  printf("mtime\t%s", ctime(&time[2]));
  // timeinfo = localtime ( (time_t*)&node->dtime );
  printf("dtime\t%s", ctime(&time[3]));
  printf("gid\t%d\n", node->gid);
  printf("block\t0x%02X\n", node->block);
  strncpy(path, node->path, 224);
  printf("File\t%s\n", path);
}

// Get the imode with the given index, returning a pointer to its start.
inode_t *get_inode(int inum) {
	return (inode_t*)blocks_get_block(1 + inum);
}

// Allocate a new inode and return its index.
int alloc_inode() {
  void *ibm = get_inode_bitmap();

  for (int ii = 0; ii < INODE_COUNT; ii++) {
    if (!bitmap_get(ibm, ii)) {
      bitmap_put(ibm, ii, 1);
      printf("+ alloc_inode() -> %d\n", ii);
      return ii;
    }
  }

  return -1;
}

// Deallocate the inode with the given number.
void free_inode(int inum) {
  printf("+ free_inode(%d)\n", inum);
  void *ibm = get_inode_bitmap();
  bitmap_put(ibm, inum, 0);
}
