// Inode manipulation routines.
//
// Feel free to use as inspiration.

// based on cs3650 starter code

#ifndef INODE_H
#define INODE_H
#include <stdint.h>

extern const int INODE_COUNT; // default 128
extern const int INODE_SIZE;  // default = 256 Bytes

// #include "blocks.h"

typedef struct __attribute__((__packed__)) inode { // __attribute__((__packed__)) force the compiler to keep the size of struct
  uint8_t refs;   // inode number
  uint16_t mode;  // permission & type
  uint32_t uid;   // uid who owns this file?
  uint32_t size;  // Size how many bytes are in this file?
  uint32_t time;  // Time what time was this file last accessed?
  uint32_t ctime; // Ctime what time was this file created?
  uint32_t mtime; // Mtime what time was this file last modified?
  uint32_t dtime; // Dtime what time was this inode deleted?
  uint32_t gid;   // Gid which group does this file belong to?
  uint8_t block;  // Data block number if size <= 4k, Data block of array of block if size > 4k
  char path[224]; // Absolute file name (Path + Filename)
} inode_t;

void print_inode(inode_t *node);
inode_t *get_inode(int inum);
int alloc_inode();
void free_inode(int inum);
// int grow_inode(inode_t *node, int size);
// int shrink_inode(inode_t *node, int size);
// int inode_get_bnum(inode_t *node, int fbnum);

#endif
