#ifndef UTILS_H
#define UTILS_H

#include "mymalloc.h"


/**
 * Iterates through the linked_list and finds if there is a free
 * block with size greater than equal to given size.
*/
int find_first_fit(block_t* linked_list, size_t size);


/**
 * splits the page into new block if you can fit extra shit in this page.
*/
block_t* shrinkify(block_t* curr_block);


/**
 * Adds the given block to the end of the linked_list.
*/
void link_block(block_t* end, block_t* linked_list);


#endif