#include "mymalloc.h"
#include "utils.h"


/**
 * Iterates through the linked_list and finds if there is a free
 * block with size greater than equal to given size.
*/
int find_first_fit(block_t* linked_list, size_t size) {
    block_t* iter = linked_list;

    while (iter != NULL) {
        if (iter->size >= size && iter->free == 1) {
            return 1;
        }
        else {
            iter = iter->next;
        }
    }
    return 0;
}

block_t* shrinkify(block_t* curr_block) {
    block_t * to_Ret = ((void *)(curr_block + 1)) + curr_block->size;
    to_Ret->next = NULL;
    to_Ret->debug = 69426942;
    to_Ret->free = 1;
    to_Ret->size = 4096 - ((2 * BLOCK_SIZE) + curr_block->size);
    return to_Ret;
}

/**
 * Adds the given block to the end of the linked_list.
*/
void link_block(block_t* end, block_t* linked_list) {
    block_t* iter = linked_list;

    while (iter->next != NULL) {
        iter = iter->next;
    }
    iter->next = end;
}
