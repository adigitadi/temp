#define _DEFAULT_SOURCE
#define _BSD_SOURCE

#include "mymalloc.h"
#include "utils.h"

// The starting block 
block_t *starting_block = NULL;

// Global locking variable for thread-safe allocation
pthread_mutex_t mutex;

int page_size;

/**
 * Allocates memory for s number of bytes.
 */
void *mymalloc(size_t s) {
  page_size = sysconf(_SC_PAGE_SIZE);
  assert(s >= 0);
  void *toRet;

  // Initialize the starting block the first time mymalloc is called.
  pthread_mutex_init(&mutex, NULL);
  // Initialize lock to prevent simultaneous memory allocating.
  pthread_mutex_lock(&mutex);

  if (starting_block == NULL) {
    if (s < page_size) {
      starting_block = mmap(NULL, page_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
      starting_block->size = s;
      starting_block->free = 0;
      starting_block->next = NULL;
      starting_block->debug = 69426942;

      if ((page_size - (BLOCK_SIZE + s)) >= (BLOCK_SIZE + 1)) {
        block_t *overflow_block = shrinkify(starting_block);
        starting_block->next = overflow_block;
      }
    }
    else {
      int num_pages = (BLOCK_SIZE + s + page_size - 1) / page_size;
      starting_block = mmap(NULL, num_pages * page_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
      starting_block->size = s;
      starting_block->free = 0;
      starting_block->next = NULL;
      starting_block->debug = 69426942;
    }

    debug_printf("malloc %zu bytes\n", s);
    pthread_mutex_unlock(&mutex);
    return (void *)(starting_block + 1);
  }

  // Unlock critical section for waiting threads.
  pthread_mutex_unlock(&mutex);
  pthread_mutex_lock(&mutex);

  // Check for a previously freed block that can fit the size.
  int i = find_first_fit(starting_block, s);

  if (i) {
    // Iterate over linked list and return pointer to previously allocated memory.
    block_t *iter = starting_block;

    while (iter != NULL) {
      if (iter->size >= s && iter->free == 1) {
        iter->free = 0;
        debug_printf("malloc %zu bytes\n", s);
        pthread_mutex_unlock(&mutex);
        return (void *)(iter + 1);
      }
      iter = iter->next;
    }
  }
  else {
    // If no available memory blocks, allocate a new block and add linked list.
    block_t *new_block;

    if (s < page_size) {
      new_block = mmap(NULL, page_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
      new_block->size = s;
      new_block->free = 0;
      new_block->next = NULL;
      new_block->debug = 69426942;

      if ((page_size - (BLOCK_SIZE + s)) >= (BLOCK_SIZE + 1)) {
        block_t *overflow_block = shrinkify(new_block);
        new_block->next = overflow_block;
      }
    }
    else {
      int num_pages = (BLOCK_SIZE + s + page_size - 1) / page_size;
      new_block = mmap(NULL, num_pages * page_size, PROT_READ | PROT_WRITE, 
      MAP_PRIVATE | MAP_ANON, -1, 0);
      new_block->size = s;
      new_block->free = 0;
      new_block->next = NULL;
      new_block->debug = 69426942;
    }

    link_block(new_block, starting_block);
    debug_printf("malloc %zu bytes\n", s);
    pthread_mutex_unlock(&mutex);
    return (void *)(new_block + 1);
  }
}

/**
 * Allocates memory for nmemb number of 'things' worth s bytes each
 * and sets their values to 0.
 */
void *mycalloc(size_t nmemb, size_t s) {
  assert(nmemb > 0);
  assert(s > 0);

  pthread_mutex_lock(&mutex);
  void *ptr = mymalloc(nmemb * s);
  memset(ptr, 0, nmemb * s);
  pthread_mutex_unlock(&mutex);

  debug_printf("calloc %zu bytes\n", s);
  return ptr;
}

/**
 * Frees the memory at the given pointer so that it can be
 * reused again and to prevent loss of memory.
 */
void myfree(void *ptr) {
  pthread_mutex_lock(&mutex);
  
  block_t *hptr = ((block_t *)ptr) - 1;

  if (hptr == NULL) {
    pthread_mutex_unlock(&mutex);
    return;
  }

  assert(hptr->debug = 69426942);
  // Coalesce blocks if possible
  if (hptr->size < page_size) {
    debug_printf("Freed some memory\n");
    hptr->free = 1;

    // Check if the next block is free
    if (hptr->next != NULL && hptr->next->free == 1 && ((hptr->size + hptr->next->size) < page_size)) {
      hptr->size = hptr->size + hptr->next->size;
      hptr->next = hptr->next->next;
    }

    // Check if the previous block is free
    if (hptr != starting_block) {
      block_t *prev = starting_block;
      while (prev->next != hptr) {
        prev = prev->next;
      }
      assert(prev->next == hptr);

      if (prev->free == 1 && ((prev->size + hptr->size) < page_size)) {
        prev->size = prev->size + hptr->size;
        prev->next = hptr->next;
      }
    }
    pthread_mutex_unlock(&mutex);
  }
  else {
    // If coalescing cannot be done, free the memory
    debug_printf("Freed some memory\n");
    int num_pages = (BLOCK_SIZE + hptr->size + page_size - 1) / page_size;
    if (hptr == starting_block) {
      starting_block = starting_block->next;
    }
    else {
      block_t *prev = starting_block;
      while (prev->next != hptr) {
        prev = prev->next;
      }
      prev->next = hptr->next;
    }

    munmap(hptr, (num_pages * page_size));
    hptr = NULL;
    pthread_mutex_unlock(&mutex);
  }
}
