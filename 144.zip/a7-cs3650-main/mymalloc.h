#ifndef MYMALLOC_H
#define MYMALLOC_H

#include <malloc.h> 
#include <stdio.h> 
#include <sys/types.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>
#include <debug.h>
#include <sys/mman.h>
#include <pthread.h>


#define BLOCK_SIZE sizeof(block_t)


typedef struct block {
  size_t size;        // How many bytes beyond this block have been allocated in the heap
  struct block *next; // Where is the next block in your linked list
  int free;           // Is this memory free, i.e., available to give away?
  int debug;
    
} block_t;


#endif