#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#include "malloc.h"
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>

#include<stddef.h>
// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include "debug.h" // definition of debug_printf
#define BLOCK_SIZE sizeof(block_t)

//defines a block
typedef struct block{
   size_t size;
   int free;
   struct block *next;
   int debug;
} block_t;

//create an empty head
block_t head = {0, 0, NULL, 0};

block_t *splitter(block_t *block, int size) {
  //check size
  if(size >= (block->size - BLOCK_SIZE)) {
    block->free = 0;
    return block;
  }

  //create a temporaty block to store
  block_t * temp = (block_t *)((char*)block);
  temp->size = (block->size - BLOCK_SIZE);
  temp->next = block->next;
  temp->free = 1;
  temp->debug = 0;

  //reassign originial block
  block->next = temp;
  block->size = size;
  block->free = 0;
  return block;
}

//chose the best spot
block_t *chooser(size_t size) {

  block_t *current = head.next;
  size_t min = ~0;
  block_t *option = NULL;
  while(current != NULL) {
    if(current->free && (current->size) >=size && (current->size) - size < min) {
      option = current;
      min = (current->size)-size;
    }
    current = current->next;
  }
  return option;
}


//merges freed data
void merger() {
  block_t *current = head.next;
  while(current != NULL) {
    if(current->free && (current->next) != NULL
      && (current->next) -> free) {
        current->size = (current->size) + (current->next->size);
        current->next = current->next->next;
      }
      else {
        current = current->next;
      }
    }
}


//find the next block of free memory
block_t *next_spot(int size) {
  size = size + BLOCK_SIZE;
  block_t *current = head.next;
  current = chooser(size);
  if(current != NULL) {
    return splitter(current,size);
  }
  current = head.next;
  int next_null = 0;
  if(current == NULL) {
    current = &head;
    next_null = 1;
  }

  while(!next_null) {
    if(current -> next == NULL) {
      next_null = 1;
    }
    else {
      current = current->next;
    }
  }
  block_t *new_memory = (block_t*)sbrk(size);
  if(new_memory == (block_t*)-1){
    return NULL;
  }
  current->next = new_memory;
  new_memory->size = size;
  new_memory->free = 0;
  new_memory->debug = 0;
  new_memory->next = NULL;
  return new_memory;
}

void *mymalloc(size_t s) {
  merger();
  block_t *p = next_spot(s);
  if(!p) {
    debug_printf("unable to allocate memory\n");
    return NULL;
  }
  debug_printf("Malloc %zu bytes\n", s);
  p++;
  return (void*)(p);
}





// struct block *find_free_block(struct block **last, size_t size)
// {
//     struct block *current = first_block;
//     while (current && !(current->free && current->size >= size))
//     {
//         *last = current;
//         current = current->next;
//     }
//     return current;
// }
//
// struct block *request_block(size_t size)
// {
//     struct block *last = NULL;
//     struct block *block = find_free_block(&last, size);
//     if (block)
//     {
//         block->free = 0;
//         return block;
//     }
//     // Append new block to list
//     block = memory + endpos;
//     endpos += BLOCK_SIZE + size;
//     if (last)
//     {
//         last->next = block;
//     }
//     else
//     {
//         first_block = block;
//     }
//     block->free = 0;
//     block->next = NULL;
//     block->size = size;
//     return block;
// }
//
// void *mymalloc(size_t size)
// {
//     struct block * block = request_block(size);
//     return block + 1;
// }
//



// #if 0
// typedef struct block {
//   size_t size;        // How many bytes beyond this block have been allocated in the heap
//   void* mem_addr ;
//   struct block *next; // Where is the next block in your linked list
//   bool is_free;           // Is this memory free, i.e., available to give away?
//   //int debug;          // (optional) Perhaps you can embed other information--remember,
//                       // you are the boss!
// } block_t;
//
// block_t* allocate_memory_block(size_t size){
//
//     void* mem_addr =sbrk(0);
//     block_t* block ;
//     void* allocate_memory = sbrk(sizeof(block) + size);
//     if(allocate_memory != (void *)-1){
//         block->is_free = false ;
//         block->size = size ;
//         block->mem_addr = mem_addr ;
//         block->next = NULL ;
//         return block ;
//     }
//     else
//     return NULL ;
// }
//
// //takes two parameters, size of need and head of the linked list.
// //If the head is NULL , a new block is initialized with the help of allocate_memory block and set it to current.
// //If head is not empty, we go on iterate till the end of the list,
// //create a new block and set current->next equal to new block that is created.
// void *mymalloc(size_t size){
//     //block* current = * head ;
//     void* mem_addr = (void *)sbrk(0);
//     block_t* current = allocate_memory_block(size);
//
//     while(current->next != NULL){
//         current = current->next ;
//     }
//     block_t* block ;
//     void* allocate_memory = sbrk(sizeof(block) + size);
//     if(allocate_memory != (void *)-1){
//       block->is_free = false;
//       block->mem_addr = mem_addr ;
//       block->size = size;
//       block->next = NULL ;
//       current->next = block  ;
//     }
//
//     debug_printf("Malloc %zu bytes\n", size);
//     return current;
// }
// #endif


// void *mymalloc(size_t s) {
//
//   void *p = (void *) malloc(s); // In your solution no calls to malloc should be
//                                // made! Determine how you will request memory :)
//
//   if (!p) {
//     // We are out of memory
//     // if we get NULL back from malloc
//   }
//   debug_printf("malloc %zu bytes\n", s);
//
//   return p;
// }

void *mycalloc(size_t nmemb, size_t s) {

  void *p = (char *) mymalloc(s * nmemb); // In your solution no calls to calloc should be
                                       // made! Determine how you will request memory :)

  if (!p) {
    // We are out of memory
    // if we get NULL back from malloc
    return NULL;
  }
  int i = 0;
  for (i=0; i< (nmemb *s); i++) {
    *(char*)(p + i) = '\0';
  }
  debug_printf("calloc %zu bytes\n", s);

  return (void*)p;
}

void myfree(void *ptr) {
  int s = sizeof(ptr);
  debug_printf("Freed some memory\n");
  merger();
  debug_printf("Freed %zu bytes\n", s);
  block_t *block = (block_t*)ptr;
  block--;
  block->free = 1;
}

