#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h>
#include <stdio.h>
#include <unistd.h>
#include <stddef.h>
#include <string.h>
#include <sys/mman.h>
#include <assert.h>


// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf


typedef struct block {
  size_t size;        // How many bytes beyond this block have been allocated in the heap
  struct block *next; // Where is the next block in your linked list
  int free;           // Is this memory free, i.e., available to give away?
  //int debug;          // (optional) Perhaps you can embed other information--remember,
                      // you are the boss!
} block_t;


// globals 
#define BLOCK_SIZE sizeof(block_t) //constant BLOCK_SIZE at size of block
block_t *header = NULL; //initialize header



//Our version of malloc
//Uses the struct block
// size_t -> null*
void *mymalloc(size_t s) {
  //assert(header->free == 0);
// size needs to account for the size of whatever we need to allocate and the size of the header
block_t *iterator = header;
s = s + BLOCK_SIZE;
 
 //goes through iterations for freeing space
  while(iterator) { //while the iterator is active 
    //assert(iterator != NULL);
    if(iterator->size >= s) {

        // if the iterator has a size big enough for s and its free set it not to be free and return the pointer of it.
      if(iterator->free == 0) {
      iterator->free = 1;
       debug_printf("malloc %zu bytes\n", s);

      return (void *) (iterator + 1);
          }
    }
   
    iterator = iterator->next;
    
  }

// we got here if we found no block in our linked list that has a big enough size AND is free.
  iterator = sbrk(s);
  iterator->size = s;
  iterator->free = 1;
  iterator->next = NULL;


// if the iterator we are at is not the header then make it the header, else find the last block in our linked list and set its next block to be the block we just created
  if(!header) {
  //assert(header = iterator);
  header = iterator;
  }
  else {
    
    block_t *temp = header;
    while(temp->next!=NULL) {

      temp = temp->next;
    }
    temp->next = iterator;
  }
   debug_printf("malloc %zu bytes\n", s);

 debug_printf("malloc address: %p", iterator);
 return (void *)(iterator + 1);

}

//our calloc function -> allocated block of memory for array
// size_t size_t -> * (to first block of mem)
void *mycalloc(size_t nmemb, size_t s) {

 debug_printf("calloc %zu bytes\n", s); //debug message
return memset(mymalloc(nmemb * s),0,s * nmemb); //use memset & our malloc 

}

//free function -> frees the memoery at the given pointer to heap
// * -> 
void myfree( void *ptr) {

   block_t *iterator = header;
   block_t *block = (block_t *) ptr -1;

// checks to see if any block in our linked list has the same memory address as the pointer to the memory address that we want to free. if it does then we set its flag equal to free.
  while(iterator != NULL) {
  
    if(iterator == block) {
      iterator->free = 0;
      debug_printf("Freed some memory\n");
     return;
    }
     iterator = iterator->next;
  }
  

}
