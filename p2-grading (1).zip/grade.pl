#!/usr/bin/perl
use 5.16.0;
use strict;
use warnings FATAL => 'all';

use Test::More; # tests => 17;
use IO::Handle;

my $table = grep {$_ eq '--table'} @ARGV;

sub mount {
    system("(make mount 2>&1) >> test.log &");
    sleep 1;
}

sub unmount {
    system("(make unmount 2>&1) >> test.log");
}

sub write_text {
    my ($name, $data) = @_;
    open my $fh, ">", "mnt/$name" or return;
    $fh->say($data);
    close $fh;
}

sub read_text {
    my ($name) = @_;
    open my $fh, "<", "mnt/$name" or return "";
    local $/ = undef;
    my $data = <$fh> || "";
    close $fh;
    $data =~ s/\s*$//;
    return $data;
}

sub read_text_slice {
    my ($name, $count, $offset) = @_;
    open my $fh, "<", "mnt/$name" or return "";
    my $data;
    seek $fh, $offset, 0;
    read $fh, $data, $count;
    close $fh;
    return $data;
}

# https://stackoverflow.com/a/8335606
sub array_eq {
    my ($xref, $yref) = @_;
    return 0 unless  @$xref == @$yref;

    my $i;
    for my $e (@$xref) {
        return 0 unless $e eq $yref->[$i++];
    }
    return 1;
}

#my $score = 0;
#my $total = 0;

my @results;

# wok : Number Boolean String -> Void
# weighted graded test
sub wok {
  my ($weight, $test, $name) = @_;
  #print(join(",", map { defined ? $_ : 'UNDEFINED' } @_)."\n");
  #print("$weight, $test, $name\n");
  my $res = ok($test, $name);
  my $score = 0;
  if ($res) {
    $score = $weight;
  }
  push @results, {name => $name, score => $score, max => $weight};

}

# print_results : -> Void
# Print formatted test results to stdout
sub print_results {
  my $score = 0;
  my $total = 0;


  print("\n\nResults\n=======\n\n");
  if ($table) {
    print("| Test | Score |\n",
          "|------|------:|\n");
    foreach my $test (@results) {
      $score += $test->{score} or 0;
      $total += $test->{max};
      printf("| %50s | %9.2f/%.2f |\n", 
        $test->{name}, 
        ($test->{score} or 0), 
        $test->{max});
    }
    printf("| **Overall** | **%.2f/%.2f** |\n", $score, $total);
  }
  else {
    foreach my $test (@results) {
      $score += $test->{score} or 0;
      $total += $test->{max};
      printf("%50s%9.2f/%.2f\n", 
        $test->{name}, 
        ($test->{score} or 0), 
        $test->{max});
    }
    printf("%s %s\n", "-" x 50, "-" x 13);
    printf("%50s%8.2f/%.2f\n", "Overall", $score, $total);
  }
}

system("rm -f data.nufs test.log");

say "#           == Basic Tests ==";
mount();


my $msg0 = "hello, one";
my $file1 = "one.txt";
write_text($file1, $msg0);
wok(1, -e "mnt/$file1", "$file1 exists after creation");
wok(1, -f "mnt/$file1", "$file1 is a regular file");
my $msg1 = read_text($file1);
say "# '$msg0' eq '$msg1'?";
wok(2, $msg0 eq $msg1, "Read back data from $file1 correctly");

my $msg2 = "hello, two";
my $file2 = "two.txt";
write_text($file2, $msg2);
wok(1, -e "mnt/$file2", "$file2 exists after creation");
wok(1, -f "mnt/$file2", "$file2 is a regular file");
my $msg3 = read_text($file2);
say "# '$msg0' eq '$msg1'?";
wok(2, $msg2 eq $msg3, "Read back data from $file2 correctly");

my $files = `ls mnt`;
wok(2, scalar ($files =~ /one\.txt/), "$file1 is in the directory");
wok(2, scalar ($files =~ /two\.txt/), "$file2 is in the directory");

my $long0 = "=This string is fourty characters long.=" x 50;
write_text("2k.txt", $long0);
my $long1 = read_text("2k.txt");
wok(2, $long0 eq $long1, "Read back long text from 2k.txt correctly");

my $long2 = read_text_slice("2k.txt", 10, 50);
my $right = "ng is four";
wok(2, $long2 eq $right, "Read with offset & length");

unmount();

(!-e "mnt/one.txt") or die "one.txt exists after umount; FS never mounted?";

say "# Testing persistence...";

$files = `ls mnt`;
wok(2, scalar ($files !~ /one\.txt/), "one.txt is not in the directory after unmount");
wok(2, scalar ($files !~ /two\.txt/), "two.txt is not in the directory after unmount");

mount();

$files = `ls mnt`;
wok(2, scalar ($files =~ /one\.txt/), "one.txt exists after re-mount");
wok(2, scalar ($files =~ /two\.txt/), "two.txt exists after re-mount");

$msg1 = read_text("one.txt");
say "# '$msg0' eq '$msg1'?";
wok(2, $msg0 eq $msg1, "Read data from one.txt correctly after re-mount");

$msg3 = read_text("two.txt");
say "# '$msg2' eq '$msg3'?";
wok(2, $msg2 eq $msg3, "Read data from two.txt correctly after re-mount");

#system("rm -f mnt/one.txt");
#$files = `ls mnt`;
#wok(1, $files !~ /one\.txt/, "deleted one.txt");

unmount();

say "# Testing unlink...";

-f "mnt/two.txt" or write_text("two.txt", "this is a file");

-f "mnt/two.txt" or die "Failed to create a file for unlinking.";

system("rm -f mnt/two.txt");
wok(0.5, ! (-e "mnt/two.txt"), "Delete - file does not exist");
$files = `ls mnt`;
wok(0.5, scalar ($files !~ /two\.txt/), "Delete - file not listed");

unmount();

system("rm -f data.nufs test.log");

say "# Many files";

sub try_n_files {
  my ($n, $score) = @_;
  mount();

  my @written;
  for my $i (1..$n) {
    my $text = "This is file no. $i";
    write_text("file$i.txt", $text);
    push(@written, $text);
  }

  my $exist = 1;
  for my $i (1..$n) {
    if (! -e "mnt/file$i.txt") {
      $exist = 0;
      last;
    }
  }

  wok($score, $exist, "Created $n files");

  my @read;
  for my $i (1..$n) {
    my $text = read_text("file$i.txt");
    push(@read, $text)
  }

  wok($score, array_eq(\@written, \@read), "$n files read back correctly");
  unmount();

  system("rm -f data.nufs test.log");
}

try_n_files(10, 0.5);
try_n_files(20, 0.5);
try_n_files(50, 1);
try_n_files(100, 1);

#say "#         == Testing Advanced Functionality ==";

mount();

say "# Nested directories";

wok(1, mkdir("mnt/foo"), "Create a new directory");
wok(1, mkdir("mnt/tmp"), "Create another directory");
wok(2, (-d "mnt/foo" and -d "mnt/foo"), "Directories exist");
$files = `ls mnt`;
wok(2, ($files =~ /foo/ and $files =~ /tmp/), "Directories listed");

wok(1, (mkdir("mnt/foo/bar") and -d "mnt/foo/bar"), "Create a nested directory");
wok(1, (mkdir("mnt/foo/bork") and -d "mnt/foo/bork"), "Create another nested directory");
wok(1, (mkdir("mnt/foo/bar/baz") and -d "mnt/foo/bar/baz"), "Create a nested-nested directory");
wok(1, (mkdir("mnt/foo/bar/secret") and -d "mnt/foo/bar/secret"), "Create another nested-nested directory");

my $msg4 = "This is a file";
write_text("tmp/file.txt", $msg4);
wok(1.25, -f "mnt/tmp/file.txt", "Create a file in a directory");
my $msg5 = read_text("tmp/file.txt");
wok(1.25, $msg4 eq $msg5, "Read data back correctly");
system("mv mnt/tmp/file.txt mnt/foo");
wok(1.25, -e "mnt/foo/file.txt", "Move a file to another directory");
my $msg6 = read_text("foo/file.txt");
wok(1.25, $msg4 eq $msg6, "Read data back correctly");

unmount();

system("rm -f data.nufs test.log");


# mount();
# 
# say "# Large files";
# 
# say "# -> 2 blocks";
# 
# my $chunks = 256 + 128;
# my $content = "1_2_3_4_5_6_7_8_" x $chunks; # $chunks * 16 bytes of data
# write_text("large.txt", $content);
# $files = `ls mnt`;
# my $listed = $files =~ /large\.txt/;
# my $exists = -f "mnt/large.txt";
# my $size = -s "mnt/large.txt";
# $size or $size = 0;
# say "# Actual size: $size";
# my $has_size = $size eq 16 * $chunks + 1;
# wok(1, ($listed and $exists and $has_size), "Large file exists and has the correct size");
# my $back = read_text("large.txt");
# wok(1, $content eq $back, "Read back data from large file correctly");
# 
# say "# -> 4 blocks";
# $chunks = 3 * 256 + 128;
# $content = "1_2_3_4_5_6_7_8_" x $chunks; # $chunks * 16 bytes of data
# write_text("larger.txt", $content);
# $files = `ls mnt`;
# $listed = $files =~ /larger\.txt/;
# $exists = -f "mnt/larger.txt";
# $size = -s "mnt/larger.txt";
# $size or $size = 0;
# say "# Actual size: $size";
# $has_size = $size eq 16 * $chunks + 1;
# wok(1, ($listed and $exists and $has_size), "Larger file exists and has the correct size");
# $back = read_text("larger.txt");
# wok(1, $content eq $back, "Read back data from larger file correctly");
# 
# say "# -> 10 blocks";
# $chunks = 9 * 256 + 128;
# $content = "1_2_3_4_5_6_7_8_" x $chunks; # $chunks * 16 bytes of data
# write_text("larger.txt", $content);
# $files = `ls mnt`;
# $listed = $files =~ /larger\.txt/;
# $exists = -f "mnt/larger.txt";
# $size = -s "mnt/larger.txt";
# $size or $size = 0;
# say "# Actual size: $size";
# $has_size = $size eq 16 * $chunks + 1;
# wok(1, ($listed and $exists and $has_size), "Larger file exists and has the correct size");
# $back = read_text("larger.txt");
# wok(2, $content eq $back, "Read back data from larger file correctly");

#write_text("larger.txt", $content);
#wok(0.25, -e "mnt/larger.txt", "Larger file exists after creation");
#wok(0.25, -f "mnt/larger.txt", "Larger file is a regular file");
#$size = -s "mnt/larger.txt";
#say "# Actual size: $size";
#wok(0.25, $size eq 16 * $chunks + 1, "Larger file has the correct size");
#$back = read_text("larger.txt");
#wok(0.5, $content eq $back, "Read back data from larger file correctly");
#
#$files = `ls mnt`;
#wok(0.25, $files =~ /larger\.txt/, "Larger file is in the directory");

# unmount();
done_testing();

print_results();
