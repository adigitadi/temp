#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#include <malloc.h>
#include <assert.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

// Include any other headers we need here

typedef struct block
{
    size_t size;        // How many bytes beyond this block have been allocated in the heap
    struct block *next; // Where is the next block in your linked list
    int free;           // Is this memory free, i.e., available to give away?
                        // (optional) Perhaps you can embed other information--remember,
                        // you are the boss!

} block_t;

// setting size after block struct is initialized
#define BLOCK_SIZE sizeof(block_t)
// function headers
block_t *searchAvailable(block_t *block, size_t s);
block_t *create_space(block_t *block, size_t s);
static block_t *startBlock(size_t s);

// global variables to be referenced later
block_t *GLOBAL_START = NULL;
static block_t *start = 0;
block_t *create = 0;

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf


// allocates the requested memory to be used
void *mymalloc(size_t s)
{
    block_t *p;

    // check to make sure they are actually requesting memory greater than 0
    // cannot allocate negative memory!
    assert(s > 0);

    // if this is the first call we do not need to create more space just call our already created start function
    if (start == 0)
    {
        // updating pointer to the end of our new data
        return (startBlock(s) + 1);
    }
    // if not first call search to see if any block in our list can handle our request
    else
    {
        p = searchAvailable(start, s);
    }

    // if searchAvailable returns NULL, no available space is found, so request more memory
    if (p == GLOBAL_START)
    {
        p = create_space(start, s);
        // if fail / unable to create anymore space 
        if (!p)
        {
            return NULL;
        }
    }
    // update pointer to be set to the begining of new block
    debug_printf("malloc %zu bytes\n", s);
    return (p + 1);
}

// initializing a list we can build off of during our fist call
static block_t *startBlock(size_t s)
{
    // allowing for the size of the block itself and the requested memory
    start = sbrk(s + BLOCK_SIZE);
    start->size = s;
    start->next = NULL;
    // not free as we used it
    start->free = 0;

    // storing our init in a global variable to be referenced later
    create = start;
    return start;
}

// sees if the current list of blocks can handle our size request
block_t *searchAvailable(block_t *block, size_t s)
{
    while (block != GLOBAL_START)
    {
        // see if our current block can handle our request
        // if it can we set it to not be free (as it has been used)
        if (block->size >= s && block->free == 1)
        {
            block->free = 0;
            return block;
        }
        // if current block cannot handle request
        else
        {
            // move onto next block in list and itterate while
            block = block->next;
        }
    }
    // if no block in list can handle our request we return NULL;
    return GLOBAL_START;
}

// allocates more space in our malloc if requested/needed
block_t *create_space(block_t *block, size_t s)
{
    block_t *current;
    // get current pointer
    block = sbrk(0);
    // get pointer based on inputted size
    current = sbrk(s + BLOCK_SIZE);

    // makes sure create was created to be at our current pointer
    assert((void *)block == current);

    // checks to see if sbrk failed
    if (current == (void *)-1)
    {
        return NULL;
    }
    // not free as its been used
    current->free = 0;
    // adds our new block to the end of our linked list
    current->size = s;
    current->next = NULL;

    create->next = current;
    create = current;
    // return our updated block with correct size
    return current;
}

// allocates requested memory to be used but all new memory is initialized at 0
void *mycalloc(size_t nmemb, size_t s)
{
    size_t size = nmemb * s;
    void *p = mymalloc(size);

    // initializes new blocks to 0
    memset(p, 0, size);
    if (!p)
    {
        // We are out of memory
        // if we get NULL back from malloc
        return;
    }
    debug_printf("calloc %zu bytes\n", s);

    return p;
}

// frees the memory of the requested block
void myfree(void *ptr)
{
    // acessing block failed / nothing to be freed
    if (!ptr)
    {
        return;
    }

    // move to the begining of our block (current pointer should point to end)
    block_t *block_ptr = (block_t *)ptr - 1;

    // check to make sure the given block is not already free
    assert(block_ptr->free == 0);

    // dictates the block as now free
    block_ptr->free = 1;
    debug_printf("Freed some memory\n");
}

