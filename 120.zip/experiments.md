(This is a template. Delete this line and fill in the sections below)

# Threaded Merge Sort Experiments

## Host 1: [NAME]

- CPU: Ryzen 7 3700X
- Cores: 8
- Cache size (if known): 32MB
- RAM: 32GB
- Storage (if known): 512GB NVME PCIE Gen 4
- OS: Windows 11 using WSL 2 Ubuntu 20.04

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*

I went with 99802131 and it took 16 seconds for msort. Using the diff make command as it generate the numbers automatically and makes this test much easier to do.

### Experiments

*Replace X, Y, Z with the number of threads used in each experiment set.*

#### 1 Threads

Command used to run experiment: `export MSORT_THREADS=1 && make diff-99802131`

Sorting portion timings:

1. 20.063788 seconds
2. 18.983284 seconds
3. 19.124373 seconds
4. 19.129491 seconds

#### 2 Threads

Command used to run experiment: `export MSORT_THREADS=2 && make diff-99802131`

Sorting portion timings:

1. 10.620746 seconds
2. 10.595119 seconds
3. 10.536329 seconds
4. 10.507833 seconds

#### 8 Threads

Command used to run experiment: `export MSORT_THREADS=8 && make diff-99802131`

Sorting portion timings:

1. 6.909901 seconds
2. 5.975325 seconds
3. 6.027219 seconds
4. 5.991263 seconds

#### 20 Threads

Command used to run experiment: `export MSORT_THREADS=20 && make diff-99802131`

Sorting portion timings:

1. 8.483745 seconds
2. 8.699662 seconds
3. 8.478682 seconds
4. 9.295096 seconds

## Observations and Conclusions

*Reflect on the experiment results and the optimal number of threads for your concurrent merge sort implementation on different hosts or platforms. Try to explain why the performance stops improving or even starts deteriorating at certain thread counts.*

With the cpu having 8 cores (16 threads), as we increase the number of threads past 16 the execution time increase. I assume this will be because as we ask PThread to start threads past 16 it has to wait for a previous to complete first, causing the increased execution time.
