
#ifndef DIRECTORY_H
#define DIRECTORY_H

#define DIR_NAME 48

#include "slist.h"
#include "blocks.h"
#include "inode.h"

typedef struct dirent {
    char name[DIR_NAME];
    int  inum;
    char _reserved[12];
} dirent;

void directory_init();
int rec_lookup(const char* path);
int directory_lookup(inode* dir, const char* name);
int directory_delete(inode* dir, const char* name);
int directory_put(inode* dir, const char* name, int inum);
int get_parent_dir_inum(const char* path);
char *get_dir_filename(const char* path);
slist_t* directory_list(const char* path);

#endif

