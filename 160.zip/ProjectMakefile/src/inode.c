
#include "inode.h"
#include "blocks.h"
#include "bitmap.h"

size_t INODE_SIZE = sizeof(inode);

inode* get_inode(int inum){
	inode* inode_start = (inode *) (((uint8_t *) blocks_get_block(0)) + 64);
	if (inum == 0){
		return inode_start;		
	}
	
	return inode_start + (inum * INODE_SIZE );
}

int alloc_inode()
{
	void* ibm = get_inode_bitmap();
	for (int ii = 0; ii < BLOCKS_COUNT; ++ii) 
	{
		if (!bitmap_get(ibm, ii)) {
			bitmap_put(ibm, ii, 1);
			printf("+ alloc_inode() -> %d\n", ii);
			return ii;
		}
	}
	
	puts("CANT ALLOCATE INODE");
	return -1;
	
}

void free_inode(int inum){
	inode* n = get_inode(inum);
	
	if (n->refs >1)
	{
		--n->refs;
	}
	else{
		uint8_t* ibm = get_inode_bitmap();
		bitmap_put(ibm, inum,0);
		n->refs = 0;
		n->mode = 0;
		n->size = 0;
		free_block(n->block);
	}
	
}
