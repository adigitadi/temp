#define _GNU_SOURCE
#include <string.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <assert.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <stdint.h>

#include "blocks.h"
#include "bitmap.h"
#include "directory.h"

const int BLOCKS_COUNT      = 256; // we split the "disk" into 256 blocks
const int BLOCK_SIZE        = 4096; // = 4K
const int INODE_BLOCK_SIZE  = sizeof(inode);
const int BLOCK_BITMAP_SIZE = BLOCKS_COUNT / 8; // default = 256 / 8 = 32
const int INODE_BITMAP_SIZE = BLOCKS_COUNT / 8; // default = 256 / 8 = 32
const int NUFS_SIZE         = BLOCK_SIZE * BLOCKS_COUNT + BLOCK_BITMAP_SIZE + INODE_BITMAP_SIZE + INODE_BLOCK_SIZE * BLOCKS_COUNT; // = HEADER + 1MB

static int   blocks_fd   = -1;
static void  *blocks_base =  0;

void blocks_init(const char* path)
{
    blocks_fd = open(path, O_CREAT | O_RDWR, 0644);
    assert(blocks_fd != -1);

    int rv = ftruncate(blocks_fd, NUFS_SIZE);
    assert(rv == 0);

    blocks_base = mmap(0, NUFS_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, blocks_fd, 0);
    assert(blocks_base != MAP_FAILED);

    void* bbm = get_blocks_bitmap();
    bitmap_put(bbm, 0, 1);
    directory_init();
}

void blocks_free(void)
{
    int rv = munmap(blocks_base, NUFS_SIZE);
    assert(rv == 0);
}

void *blocks_get_block(int pnum)
{
    return blocks_base + BLOCK_BITMAP_SIZE + INODE_BITMAP_SIZE + INODE_BLOCK_SIZE * BLOCKS_COUNT + BLOCK_SIZE * pnum;
}

void *get_blocks_bitmap(void)
{
    return blocks_base;
}

void *get_inode_bitmap(void)
{
    uint8_t* block = get_blocks_bitmap();

    return (void *)(block + BLOCK_BITMAP_SIZE);
}

int alloc_block(void)
{
    void* bbm = get_blocks_bitmap();
	
	for (int ii = 1; ii < BLOCKS_COUNT; ++ii) {
        if (!bitmap_get(bbm, ii)) {
            bitmap_put(bbm, ii, 1);
	
            printf("+ alloc_block() -> %d\n", ii);
            return ii;
        }
    }
    return -1;
}

void free_block(int bnum)
{
    printf("+ free_block(%d)\n", bnum);
    void* bbm = get_blocks_bitmap();
    bitmap_put(bbm, bnum, 0);
}

