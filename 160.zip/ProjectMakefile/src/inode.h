#ifndef INODE_H
#define INODE_H

#include <stdint.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "blocks.h"

typedef struct inode 
{
    int refs;     /* count ref */
	uint16_t uid; /* user ID of file owner */
	uint16_t gid; /* group ID of file owner */
	uint32_t mode; /* permissions | type: file, directory, ... */
	uint32_t ctime; /* creation time */
	uint32_t atime; /* access time */
	uint32_t mtime; /* last modification time */
  	int32_t size; /* size in bytes */
  	uint32_t block; /* direct block pointer */
} inode;

inode *get_inode(int inum);
int alloc_inode();
void free_inode(int inum);
#endif
