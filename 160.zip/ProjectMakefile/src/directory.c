#include <errno.h>
#include <time.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "directory.h"
#include "slist.h"
#include "blocks.h"
#include "inode.h"
#include "bitmap.h"

#define ROOT_INODE 				(0)
#define DIRENT_SIZE 			(sizeof(dirent))
#define DIR_ENTRIES_PER_BLOCK	(BLOCK_SIZE / DIRENT_SIZE)

#define is_same(str1, str2)		(strcmp((str1), str2) == 0)

void directory_init()
{
	void *ibm =  get_inode_bitmap();	
	int root_inum = alloc_inode();
	inode *root = get_inode(root_inum);
	root->refs  = 1;
	root->mode  = S_IFDIR;
	root->size  = 0;
	root->block = alloc_block();
	root->uid 	= getuid();
	root->gid 	= getgid();
	root->atime = time(0);
	root->mtime = time(0);
	root->ctime = time(0);
	bitmap_put(ibm, 0, 1);
	directory_put(root, ".", root_inum);
}

int directory_lookup(inode* dir, const char* name)
{
	dirent *files = (dirent *) blocks_get_block(dir->block);
	for (int i  = 0 ; i < DIR_ENTRIES_PER_BLOCK; i++)
	{
		if(is_same(files->name, name))
			return files->inum;
		files = (void *)files + DIRENT_SIZE;
	}
	return -ENOENT;
}

int rec_lookup(const char* path)
{
	inode* root = get_inode(ROOT_INODE);
	int dir_num = 0;
	slist_t* p = s_explode(path, '/');
	int pnum = 0;
	p = p->next;
	if (is_same(path, "/"))
	{
		s_free(p);
		return dir_num;
	}
	pnum = get_parent_dir_inum(path);
	inode* parent_inode = get_inode(pnum);
	char* filename = get_dir_filename(path);
	dir_num = directory_lookup(parent_inode, filename );
	s_free(p);
	return dir_num;
}

int directory_put(inode* dir, const char* name, int inum)
{
	dirent* files = (dirent*) blocks_get_block(dir->block);	
	for (int i = 0 ; i < DIR_ENTRIES_PER_BLOCK; i++)
	{
		if(is_same(files[i].name, ""))
		{
			strcpy(files[i].name, name);
			files[i].inum = inum;
			return 0;
		}
	}
	return -ENOENT;
	
}

int directory_delete(inode* dir, const char* name)
{	
	dirent* files = (dirent*) blocks_get_block(dir->block);	
	for (int i  = 0 ; i < DIR_ENTRIES_PER_BLOCK; i++)
	{
		if(is_same(files[i].name, name))
		{
			strcpy(files[i].name, "");
			files[i].inum = -1;
			return 0;
		}
	}
	return -ENOENT;
}

slist_t* directory_list(const char* path)
{
	int inum = rec_lookup(path);
	inode* node = get_inode(inum);	
	dirent* files = (dirent*) blocks_get_block(node->block);
	slist_t* dir_cont = NULL;

	for (int i  = 0 ; i < DIR_ENTRIES_PER_BLOCK; i++)
	{
		if(is_same(files[i].name, ""))
			break;
		dir_cont = s_cons(files[i].name, dir_cont);
	}
	return dir_cont;
}

int get_parent_dir_inum(const char* path) 
{
	int pnum = 0;
	slist_t* list = s_explode(path, '/');
	slist_t* org_ptr = list;
	list = list->next;
	
	if (list->next == NULL)
	{
		return pnum;
	}
	
	inode* pnode = get_inode(0);
	while (list->next != NULL && list->next->next != NULL && pnum >= 0)
	{
		pnum = directory_lookup(pnode, list->data);
		pnode = get_inode(pnum);
		list = list->next;
	}
	
	pnum = directory_lookup(pnode, list->data);
	pnode = get_inode(pnum);
	s_free(org_ptr);
	return pnum;
}

char *get_dir_filename(const char* path) 
{
	slist_t* list = s_explode(path, '/');
	slist_t* org_list = list;
	list = list->next;
	while (list->next != NULL )
		list = list->next;
	char *dir_name = (char *) malloc(strlen(list->data) + 1);
	memset(dir_name, 0, strlen(list->data) + 1);
	memcpy(dir_name, list->data, strlen(list->data));
	s_free(org_list);
	return dir_name;
}
