#define FUSE_USE_VERSION 26
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <bsd/string.h>
#include <assert.h>
#include <fuse.h>
#include <stdlib.h>
#include "src/blocks.h"
#include "src/inode.h"
#include "src/directory.h"

int nufs_access(const char *path, int mask)
{
	printf("checking access of %s\n", path);
    int rv = 0;
	if (rec_lookup(path) < 0){	
		rv = -ENOENT;
	}
    printf("access(%s, %04o) -> %d\n", path, mask, rv);
    return rv;
}

int nufs_getattr(const char *path, struct stat *st)
{
	int inum  = rec_lookup(path);

	if (inum < 0)
		return -ENOENT;

	inode* node = get_inode(inum);
	st->st_mode = node->mode;
	st->st_size = node->size;
	st->st_uid = getuid();
	st->st_gid = getgid();
	st->st_nlink = node->refs;
    printf("getattr(%s) -> (%d) {mode: %04o, size: %ld}\n", path, 0, st->st_mode, st->st_size);
	return 0;
}

int nufs_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
             off_t offset, struct fuse_file_info *fi)
{
    struct stat st;
	slist_t *contents = directory_list(path);
	slist_t *org_list = contents;
	while(contents != NULL)
	{
		filler(buf, contents->data, &st, 0);
		contents = contents->next;
	}
    printf("readdir(%s) -> %d\n", path, 0);
	s_free(org_list);
    return 0;
}

// mknod makes a filesystem object like a file or directory
// called for: man 2 open, man 2 link
int
nufs_mknod(const char *path, mode_t mode, dev_t rdev)
{
    int rv = -1;
	char* fname = get_dir_filename(path);
	int inum = alloc_inode();
	inode* node = get_inode(inum);
	node->refs 	= 1;
	node->mode 	= mode;
	node->block	= alloc_block();
	node->atime = time(0);
	node->mtime = time(0);
	node->ctime = time(0);
	node->uid = getuid();
	node->gid = getgid();
	node->size = 0;
	int pnum = get_parent_dir_inum(path);
	inode* p_node = get_inode(pnum);
	rv = directory_put(p_node, fname, inum);
    return rv;
}

// most of the following callbacks implement
// another system call; see section 2 of the manual
int
nufs_mkdir(const char *path, mode_t mode)
{
    int rv = nufs_mknod(path, mode | S_IFDIR, 0);
    printf("mkdir(%s) -> %d\n", path, rv);
    return rv;
}

int
nufs_unlink(const char *path)
{
	printf("unlinking %s", path);
	int inum = rec_lookup(path);
	free_inode(inum);
	
	char* file_name = get_dir_filename(path);
	
	int pnum = get_parent_dir_inum(path);
	inode* p = get_inode(pnum);
	
	directory_delete(p, file_name);
	
    printf("unlink(%s) -> %d\n", path, 0);
    return 0;
}

int
nufs_link(const char *from, const char *to)
{
    int rv = 0;
	int oinum = rec_lookup(from);
	inode* old = get_inode(oinum );
	
	int pnum = get_parent_dir_inum(to);
	
	old->refs += 1;
	
	char* n_filename = get_dir_filename(to);
	
	rv = directory_put(get_inode(pnum),n_filename, oinum); 
	
	old->atime = time(0);
	old->mtime = time(0);
	
    printf("link(%s => %s) -> %d\n", from, to, rv);
	return rv;
}

int
nufs_rmdir(const char *path)
{	
	int rv = nufs_unlink(path);
	
    printf("rmdir(%s) -> %d\n", path, rv);
    return rv;
}

int nufs_rename(const char *from, const char *to)
{
	int rv = 0;
	int oinum = rec_lookup(from);
	inode* old = get_inode(oinum);
	char* o_filename = get_dir_filename(from);
	char* n_filename = get_dir_filename(to);
	int pnum = get_parent_dir_inum(to);
	int onum = get_parent_dir_inum(from);
	if (pnum < 0)
	{
		rv = -ENOENT;
	}
	else 
	{
		inode* p = get_inode(pnum);
		inode* o = get_inode(onum);
		directory_delete(o, o_filename);
		directory_put(p, n_filename, oinum);
	}
	
	old->atime = time(0);
	old->mtime = time(0);
    return rv;
}

int nufs_chmod(const char *path, mode_t mode)
{
    int rv = 0;
	int inum = rec_lookup(path);
	if (inum < 0)
	{
		rv = -ENOENT;
	}
	else 
	{
		inode* node  = get_inode(inum);
		node->mode = mode;
		node->atime = time(0);
		node->mtime = time(0);
		
	}
    return rv;
}

int nufs_truncate(const char *path, off_t size)
{
	int inum = rec_lookup(path);
	inode* node = get_inode(inum);
	
	node->size = size;
	
	node->atime = time(0);
	node->mtime = time(0);
	return 0;
}

int nufs_open(const char *path, struct fuse_file_info *fi)
{
    int rv = 0;
    return rv;
}

int nufs_read(const char *path, char *buf, size_t size, off_t offset, struct fuse_file_info *fi)
{
	int inum = rec_lookup(path);
	inode* node  = get_inode(inum);
	
	
	if (offset >= BLOCK_SIZE) 
		offset = 0;
	
	if (size > BLOCK_SIZE)
		size = BLOCK_SIZE;
	
	if (size + offset > BLOCK_SIZE)
		size = BLOCK_SIZE - offset;
	
	char *node_data = (char *) blocks_get_block(node->block);	
	memcpy(buf, &node_data[offset], size);
	node->atime = time(0);
	return (int) size;
}

int nufs_write(const char *path, const char *buf, size_t size, off_t offset, struct fuse_file_info *fi)
{
	int inum = rec_lookup(path);
	inode* node = get_inode(inum);	
	
	if (offset >= BLOCK_SIZE) 
		offset = 0;
	
	if (size > BLOCK_SIZE)
		size = BLOCK_SIZE;
	
	if (size + offset > BLOCK_SIZE)
		size = BLOCK_SIZE - offset;

	char *node_data = (char *) blocks_get_block(node->block);
	strncpy(&node_data[offset], buf, size);	
	node->size = size + offset;
	int rv = size;
	node->atime = time(0);
	node->mtime = time(0);
    return rv;
}

int nufs_utimens(const char* path, const struct timespec ts[2])
{
    int rv = 0;
	int inum = rec_lookup(path);
	if (inum == -1)
	{
		return -ENOENT;
	}
	
	inode* node = get_inode(inum);
	node->atime = time(0);
    return rv;
}

int nufs_ioctl(const char* path, int cmd, void* arg, struct fuse_file_info* fi,
           unsigned int flags, void* data)
{
    int rv = -1;
    return rv;
}

void nufs_destroy(void *arg)
{
	blocks_free();
}

void nufs_init_ops(struct fuse_operations* ops)
{
    memset(ops, 0, sizeof(struct fuse_operations));
    ops->access   = nufs_access;
    ops->getattr  = nufs_getattr;
    ops->readdir  = nufs_readdir;
    ops->mknod    = nufs_mknod;
    ops->mkdir    = nufs_mkdir;
    ops->link     = nufs_link;
    ops->unlink   = nufs_unlink;
    ops->rmdir    = nufs_rmdir;
    ops->rename   = nufs_rename;
    ops->chmod    = nufs_chmod;
    ops->truncate = nufs_truncate;
    ops->open	  = nufs_open;
    ops->read     = nufs_read;
    ops->write    = nufs_write;
    ops->utimens  = nufs_utimens;
    ops->ioctl    = nufs_ioctl;
	ops->destroy  = nufs_destroy;
};

struct fuse_operations nufs_ops;

int
main(int argc, char *argv[])
{
    assert(argc > 2 && argc < 6);
    printf("TODO: mount %s as data file\n", argv[(argc -1)]);
    blocks_init(argv[--argc]);
    nufs_init_ops(&nufs_ops);
    return fuse_main(argc, argv, &nufs_ops, NULL);
}

