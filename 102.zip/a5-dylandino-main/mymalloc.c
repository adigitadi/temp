#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h> 
#include <stdio.h> 
#include <debug.h>
#include <unistd.h>

// Include any other headers we need here
// NOTE: You should NOT include <stdlib.h> in your final implementation

// the first allocated pointer in out linked list. Our linked list adds to the front of the list
void* first = NULL;

typedef struct block{
  	size_t size;        // How many bytes beyond this block have been allocated in the heap
  	struct block *next; // Where is the next block in your linked list
	int free;           // Is this memory free, i.e., available to give away?
	int debug;          // (optional) Perhaps you can embed other information--remember,
                      // you are the boss!
}block_t;

#define BLOCK_SIZE sizeof(block_t)

// allocates the given size space (the size does not include the header)
void *mymalloc(size_t s) {
	
	// the current head of the linked list
	block_t* current = (block_t*) first;

	//begin by checking if we have memory available, use first fit for now
	while(current != NULL){
		//is this block free?
		if(current->free == 1) {
			//does this block have enough space?
			if(current->size >= s) {
				//return this block, set is as not free
				current->free = 0;

				//add 1 to current because 1 is actually incrementing it by BLOCK_SIZE since its a block_t pointer
				return (current + 1);
			}	
		}
		//move on to the next block
		current = current->next;
	}
	//if we got here, then there was no available block. So make a new one
	
	//ask system for some memory casting as a void as a block_t pointer
	current = (block_t*)  sbrk(s + BLOCK_SIZE);

	//if system gave error, we are out of memory
  	if (!current) {
   	 	// We are out of memory
   	 	// if we get NULL back from malloc
		perror("ran out of memory to assign");
  	}

	//create a new block of the specified size
	current->size = s;
	current->next = first;
	current->free = 0;
	
	//set the first of the list to the current pointer being made
	first = current;
	
	// print the address of the entire block
	fprintf(stderr, "allocating block at: %p\n", current);

	//print the address of the actual space (discluding the header)
	fprintf(stderr, "giving the pointer: %p\n", (current + 1));

	//return the new block
  	return (void* ) (current + 1);
}

// allocates the amount of space needed to hold nmemb number of elements
void *mycalloc(size_t nmemb, size_t s) {
	void* current =  mymalloc(nmemb * s);
   	if (!current) {
    		// We are out of memory
    		// if we get NULL back from malloc
		perror("ran out of memory in calloc");
  	}
  	//debug_printf("calloc %zu bytes\n", s);

  	return current;
}

// frees the given pointer of memory
void myfree(void *ptr) { 
	//casts to a block_pt to access fields, then move up to where the 
	//header data is stored	
	block_t* head;
       	head = (block_t *)  (ptr - BLOCK_SIZE);
	head->free = 1;
}
