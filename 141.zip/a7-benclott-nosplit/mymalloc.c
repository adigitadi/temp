#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h>
#include <stdio.h>
#include <unistd.h>
#include <stddef.h>
#include <string.h>
#include <sys/mman.h>
#include <assert.h>
#include <pthread.h>

// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf

#define PAGE_SIZE 4096



typedef struct block {
  size_t size;        // How many bytes beyond this block have been allocated in the heap
  struct block *next; // Where is the next block in your linked list
  int free;           // Is this memory free, i.e., available to give away?
  //int debug;          // (optional) Perhaps you can embed other information--remember,
                      // you are the boss!
} block_t;


// globals 
#define BLOCK_SIZE sizeof(block_t) //constant BLOCK_SIZE at size of block
block_t *header = NULL; //initialize header

//create a free list
block_t *free_list = NULL;



// iterate through free list to coalesce if possible
void coalesce_free_list() {

  block_t *current = free_list;
  while (current != NULL) {
    if ((current->next != NULL && current->next->free == 1) && (current->size + current->next->size <= PAGE_SIZE)) {
      current->size += PAGE_SIZE;
      current->next = current->next->next;
    }
    current = current->next;
  }
  debug_printf("coalesced free list");
}


void sort_free_list() {
  block_t *iterator = free_list;
  block_t *temp = NULL;
  // if the free list is not empty then sort it
  if(free_list != NULL) {
    while(iterator->next != NULL) {
      if(iterator > iterator->next) {
        temp = iterator->next;
        iterator->next = temp->next;
        temp->next = iterator;
        iterator = temp;
      }
      iterator = iterator->next;
    }
  }
}  




//Our version of malloc
//Uses the struct block
// size_t -> null*
void *mymalloc(size_t s) {

pthread_mutex_t lock;
pthread_mutex_init(&lock, NULL);
pthread_mutex_lock(&lock);



  //assert(header->free == 0);
// size needs to account for the size of whatever we need to allocate and the size of the header
block_t *iterator = header;
s = s + BLOCK_SIZE;



// if size is less than PAGE_SIZE, check free list for a large enough block to allocate
if (s < PAGE_SIZE) {
  //check free list for a large enough block to allocate
  block_t *free_iterator = free_list;

 if (iterator == NULL) {
    iterator = mmap(NULL, s, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    debug_printf("allocated %zu bytes at %p \n", s, iterator);
    iterator->size = s;
    iterator->next = NULL;
    iterator->free = 0;
    header = iterator;
    pthread_mutex_unlock(&lock);
    return (void*)(iterator + 1);
  }


  while (free_iterator != NULL) {
    if (free_iterator->size >= s) {
      //if the block is large enough, allocate it

      // if the block is larger than the size we need, split it
      
      //if the block is just the right size, allocate it
      if(free_iterator->size == s) {
        free_iterator->free = 0;
        debug_printf("allocated %zu bytes at %p \n", s, free_iterator);
       // remove the block from the free list
        block_t *free_iterator2 = free_list;
        if (free_iterator2 == free_iterator) {
          free_list = free_iterator->next;
        }
        else {
          while (free_iterator2->next != free_iterator) {
            free_iterator2 = free_iterator2->next;
          }
          free_iterator2->next = free_iterator->next;
        }
        pthread_mutex_unlock(&lock);
        return (void*)(free_iterator + 1);
      }
    } 
    else {
        //create a new block
        block_t *new_block = (block_t*)((void*)free_iterator + s);
        new_block->size = free_iterator->size - s;
        new_block->next = free_iterator->next;
        new_block->free = 1;
        //update the size of the block we are allocating
        free_iterator->size = s;
        free_iterator->next = new_block;
        free_iterator->free = 0;
        debug_printf("allocated %zu bytes at %p \n", s, free_iterator);
        // remove the block from the free list
        block_t *free_iterator2 = free_list;
        if (free_iterator2 == free_iterator) {
          free_list = free_iterator->next;
        }
        else {
          while (free_iterator2->next != free_iterator) {
            free_iterator2 = free_iterator2->next;
          }
          free_iterator2->next = free_iterator->next;
        }
        pthread_mutex_unlock(&lock);
        return (void*)(free_iterator + 1);
      } 
    free_iterator = free_iterator->next;
  }

  // if we get here, there is no block large enough in the free list, so we need to allocate a new block and add it to the header list
  iterator = header;
  while (iterator->next != NULL) {
    iterator = iterator->next;
  }
  iterator->next = mmap(NULL, s, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  debug_printf("allocated %zu bytes at %p \n", s, iterator->next);
  iterator->next->size = s;
  iterator->next->next = NULL;
  iterator->next->free = 0;
  pthread_mutex_unlock(&lock);
  return (void*)(iterator->next + 1);

}

// if s is greater than or equal to page size, compute the number of pages needed
// and allocate that many pages
else {
  int num_pages = s / PAGE_SIZE;
  if (s % PAGE_SIZE != 0) {
    num_pages++;
  }
  iterator = mmap(NULL, num_pages * PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
  debug_printf("allocated %d bytes at %p \n", num_pages * PAGE_SIZE, iterator);
  iterator->size = num_pages * PAGE_SIZE;
  iterator->next = NULL;
  iterator->free = 0;
  pthread_mutex_unlock(&lock);
  return (void*)(iterator + 1);
}



}

//our calloc function -> allocated block of memory for array
// size_t size_t -> * (to first block of mem)
void *mycalloc(size_t nmemb, size_t s) {

 size_t overFlow = nmemb * s;

// overflow condition
 if(s != overFlow / nmemb) {
  return NULL;
 }

// call malloc to allocate memory
  void *ptr = mymalloc(overFlow);
  //assert(ptr != NULL);
  if(ptr == NULL) {
    return NULL;
  }

  // for each character in the allocated memory, set it to 0
  for(int i = 0; i < overFlow; i++) {
    ((char *) ptr)[i] = 0;
  }
  
 
//create a lock
pthread_mutex_t lock;
pthread_mutex_init(&lock, NULL);
pthread_mutex_lock(&lock);

 debug_printf("calloc %zu bytes \n", s); //debug message

 //unlock the lock
  pthread_mutex_unlock(&lock);
  return ptr;
//return memset(mymalloc(nmemb * s),0,s * nmemb); //use memset & our malloc 

}

//free function -> frees the memory at the given pointer to heap
// * -> 
void myfree(void *ptr) {

pthread_mutex_t lock;
pthread_mutex_init(&lock, NULL);
pthread_mutex_lock(&lock);

   block_t *iterator = header;
   block_t *block = (block_t *) ptr - 1;
    
   // if size of pointer is less than page size then free it
    if(block->size < PAGE_SIZE) {
      block->free = 1;
      // if free list is empty then set free list to block
      if(free_list == NULL) {
        free_list = block;
          debug_printf("free memory address with size %zu at %p \n", block->size, block);
          // call coalesce to combine free blocks
          sort_free_list();
          coalesce_free_list();


          // if free list is not empty then set the next block to be the block
      } else {
        block_t *temp = free_list;
        while(temp->next != NULL) {
          temp = temp->next;
        }
        temp->next = block;
        // set the next block to be null
        block->next = NULL;
        block->free = 1;
      }
      sort_free_list();
      coalesce_free_list();

      debug_printf("free memory address with size %zu at %p \n", block->size, block);
     
      }
 
      
     
      
    
  
   
    // else unmap the block
    else {
      debug_printf("free %zu bytes at %p, unmapped \n", block->size, block);
      pthread_mutex_unlock(&lock);
      munmap(block, block->size);
      // call coalesce to combine free blocks
      sort_free_list();
      coalesce_free_list();
    }

}

