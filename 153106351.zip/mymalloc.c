#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h> 
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <debug.h>

block_t * gen_block(size_t size);
block_t * find_request(size_t size);

block_t *start = NULL;



void *mymalloc(size_t size) {

  block_t* temp;

  //Edge Case: Size = 0
  if(size <= 0) {
    return NULL;
  }

  //Try Find Request Size
  temp = find_request(size);

  debug_printf("malloc %zu bytes\n", size);
  return temp;
}

void *mycalloc(size_t nmemb, size_t size) {

  //Edge Case: nmemb and size = 0
  if(nmemb == 0 || size == 0) {
     return NULL;
  }

  //Use our mymalloc to define a temp pointer
  void* temp_ptr = mymalloc(nmemb * size);

  memset(temp_ptr, 0, nmemb * size);
  debug_printf("calloc %zu bytes\n", size);

  return temp_ptr;
}

void myfree(void *ptr) {
  debug_printf("Freed %zu bytes of memory(ies)\n", (((block_t*)ptr) - 1)->size);
  (((block_t*)ptr) - 1)->free = 1;
}

//HELPER:
//Helper for Generate block Struct
//block_t * gen_block(size_t size)

//Helper For Find Block Fits Requirement
//block_t * find_request(size_t size)

block_t * gen_block(size_t size) {
  block_t* temp;
  temp = sbrk(size + BLOCK_SIZE);
  temp->size = size;
  temp->next_block = NULL;
  temp->free = 0;
  return temp;
}

block_t * find_request(size_t size) {
  //If the First Block is not NULL
  if(!start) {
    start = gen_block(size);
    return start + 1;
  }
  block_t* temp = start;

  //Iteration To Find Space
  while (1) {

    //If There Is Free Memory And Size Fits Requirement
    if (temp->free && temp->size >= size) {
      temp->free = 0;
      temp->size = size;
      return temp + 1;
    }

    //If Next Block Exist
    if (!temp->next_block) {
      temp->next_block = gen_block(size);
      return temp->next_block + 1;
    }
    temp = temp->next_block;
  }
  return NULL;
}