#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#include <malloc.h>
#include <stdio.h>

// Include any other headers we need here
#include <string.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <unistd.h>
#include <pthread.h>

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf

#define BLOCK_SIZE sizeof(block_t)
#define PAGE_SIZE sysconf(_SC_PAGE_SIZE)
#define KEY 54321
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct block
{
  size_t size;        // the size of the memory allocation
  struct block *next; // the next block header
  int free;           // whether this block is free or not
  int key;            // key to verify we are looking at a block header
  int num_pages;      // the number of pages of the memory allocation
} block_t;

block_t *head_block = NULL; // the first block header

// gets the first fit block that is free and has size of at least s
// size_t s   -   the minimum size of the free block to be retrieved
static block_t *get_first_free_block(size_t s)
{
  if (head_block != NULL)
  { // if there's no first block, then there can't be any free blocks
    block_t *iterator;
    iterator = head_block;

    while (iterator != NULL)
    { // loop through block headers
      if (iterator->free == 1 && iterator->size >= s)
      {
        assert(iterator->key == KEY);
        iterator->free = 0; // unfree it to indicate that we're using it
        return iterator;
      }
      iterator = iterator->next;
    }
  }
  else
  {
    return NULL;
  }
}

// adds the last block header to the list of previously allocated blocks in order
// block_t *insert   -   pointer to the block header to be inserted in the free list
static void *add_to_blocks_sorted(block_t *insert)
{
  // check if the block to be added should be first
  if (head_block != NULL)
  {
    if (head_block > insert) // insert as the first memory address
    {
      insert->next = head_block;
      head_block = insert;
    }
    else
    {
      // loop through and insert in order
      block_t *iterator;
      iterator = head_block;

      while (iterator != NULL)
      {
        if (iterator->next > insert)
        { // check if the pointer address is greater
          insert->next = iterator->next;
          iterator->next = insert;
          break;
        }
        iterator = iterator->next;
      }
    }
  }
  else
  {
    head_block = insert; // no head block was previously initialized
  }
}

// removes the block header from the list of previously allocated blocks
// block_t *remove   -   pointer to the block header to be removed from the free list
static void *remove_from_blocks(block_t *remove)
{
  if (head_block != NULL)
  { // if there's no first block we can't remove a block
    block_t *iterator;
    iterator = head_block;

    if (head_block == remove)
    { // the first one is to be removed
      head_block = head_block->next;
    }
    else
    {
      while (iterator->next != NULL)  // to be removed is somewhere in the middle of the list
      {
        if (iterator->next == remove) // if the next header is to be removed...
        {
          iterator->next = remove->next;
          break;
        }
        // iterator will terminate when it reaches the last header, so
        // check for the next block of the last block
        if (iterator->next->next == remove) // if the last header is to be removed...
        {
          iterator->next = NULL;            // remove it and set the new last as NULL
        }
        else
        {
          iterator = iterator->next;
        }
      }
    }
  }
}

// splits a memory allocation into two if there is enough space for at least a block header
// plus 1 byte of space and returns the first block header pointer
// void *ptr   -   the pointer to the memory allocation
// size_t s    -   the size of the current memory allocation
static block_t *split(void *ptr, size_t s)
{
  block_t *bptr1;
  block_t *bptr2;

  bptr1 = (block_t *)ptr;
  bptr2 = (block_t *)(ptr + BLOCK_SIZE + s);    // the location of the second block header

  bptr1->key = KEY;
  bptr1->next = bptr2;
  bptr1->size = s;

  bptr2->key = KEY;
  bptr2->next = NULL;
  bptr2->size = PAGE_SIZE - s - BLOCK_SIZE;

  if (head_block == NULL)
  {
    head_block = bptr1;
  }
  else
  {
    add_to_blocks_sorted(bptr1);
  }

  return bptr1;
}

// combines two memory allocation block headers if they have both been freed
static void coalesce()
{
  if (head_block != NULL)
  { // if there's no first block, then there can't be any free blocks
    block_t *iterator;
    iterator = head_block;

    while (iterator != NULL && iterator->next != NULL)
    { // loop through block headers
      if (iterator->free == 1 && iterator->next->free == 1)
      {
        assert(iterator->key == KEY);
        assert(iterator->next->key == KEY);

        iterator->size = iterator->size + BLOCK_SIZE + iterator->next->size;
        remove_from_blocks(iterator->next);
      }
      iterator = iterator->next;
    }
  }
}

// allocates a block of memory with enough space for the block header
// size_t s   -   the size of the memory to be allocated
void *mymalloc(size_t s)
{
  pthread_mutex_lock(&mutex);
  
  block_t *bptr;
  int size = s + BLOCK_SIZE;
  if (size < PAGE_SIZE)
  {
    bptr = get_first_free_block(s); // check if there are any first-fit free blocks
    if (bptr == NULL)
    { // no free block of size s in list, mmap instead
      void *ptr = mmap(NULL, PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
      if (ptr == MAP_FAILED)
      {
        return NULL;
      }

      bptr = (block_t *)ptr;
      bptr->key = KEY;
      bptr->next = NULL;
      bptr->size = s;
      bptr->num_pages = 1;

      add_to_blocks_sorted(bptr);
    }
  }
  else if (size >= PAGE_SIZE) // need to mmap multiple pages
  {
    size_t num_pages = (size + (PAGE_SIZE - 1)) / PAGE_SIZE;

    void *ptr = mmap(NULL, num_pages * PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, -1, 0);
    if (ptr == MAP_FAILED)
    {
      return NULL;
    }

    bptr = (block_t *)ptr;
    bptr->key = KEY;
    bptr->next = NULL;
    bptr->size = s;
    bptr->num_pages = num_pages;
  }
  debug_printf("malloc %zu bytes\n", s);

  assert(bptr->key == KEY); // before returning confirm we have a block header
  bptr->free = 0;
  void *p = (void *)bptr + BLOCK_SIZE; // return pointer to memory, not block header

  pthread_mutex_unlock(&mutex);
  return p;
}

// allocates a block of memory with enough space for the block header, and overwrites memory with 0
// size_t nmemb   -   the number of elements to be allocated
// size_t s       -   the total size of the elements to be allocated
void *mycalloc(size_t nmemb, size_t s)
{
  void *p = (void *)mymalloc(nmemb * s); // allocate the block of memory

  if (p == NULL)
  {
    return NULL;
  }
  debug_printf("calloc %zu bytes\n", s);
  memset(p, 0, nmemb * s); // overwrite with 0

  return p;
}

// frees an allocated block of memory
// void *ptr   -   pointer to the allocated memory
void myfree(void *ptr)
{
  pthread_mutex_lock(&mutex);
  block_t *bptr = (void *)(ptr - BLOCK_SIZE); // point to the block header rather than the memory
  assert(bptr->key == KEY);
  size_t size = bptr->size + BLOCK_SIZE;

  if (size < PAGE_SIZE)
  {
    bptr->free = 1; // free it
    coalesce();
  }
  else if (size >= PAGE_SIZE)
  {
    remove_from_blocks(bptr);
    assert(munmap((void *)bptr, bptr->num_pages * PAGE_SIZE) == 0);
  }

  pthread_mutex_unlock(&mutex);
  debug_printf("Freed some memory\n");
}
