(This is a template. Delete this line and fill in the sections below)
# Threaded Merge Sort Experiments


## Host 1: XOA VM

- CPU: Intel (R) Xeon(R) CPU E5-2690 v3 @ 2.60GHz
- Cores: 2 cores
- Cache size (if known): 2.4 Gi
- RAM: 4 GiB
- Storage (if known): 40 GiB
- OS: Ubuntu 22.04.1 LTS

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*
- The data set will contain 100,000,000 elements. We created the data set using the shuf command. Specifically shuf -il-100000000 > hundred-million.txt generates 100,000,000 random numbers and writes them to a text file. Msort took 22.704184 seconds to sort it using a single thread.
### Experiments

*Replace X, Y, Z with the number of threads used in each experiment set.*

#### 1 Threads

Command used to run experiment: `MSORT_THREADS=1 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 26.886883 seconds, 110 processes were running
2. 26.954828 seconds, 108 processes were running
3. 26.870472 seconds, 111 processes were running
4. 26.788935 seconds, 113 processes were running

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 14.919330 seconds, 116 processes were running
2. 14.868444 seconds, 115 processes were running
3. 14.837129 seconds, 116 processes were running
4. 14.891147 seconds, 112 processes were running

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=4 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 18.072780 seconds, 107 processes were running
2. 18.076823 seconds, 109 processes were running
3. 18.012932 seconds, 111 processes were running
4. 18.069415 seconds, 110 processes were running

*repeat sections as needed*

## Host 2: Khoury Login


- CPU: Intel (R) Xeon(R) Silver 4214R CPU @ 2.40GHz
- Cores: 48 cores
- Cache size (if known): 56532 kB
- RAM: 394637612 kB
- Storage (if known): 2 T
- OS: CentOS Linux 7 (Core)

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*
- The data set will contain 100,000,000 elements. We created the data set using the shuf command. Specifically shuf -il-100000000 > hundred-million.txt generates 100,000,000 random numbers and writes them to a text file. Msort took 25.055488 seconds to sort it using a single thread.
### Experiments

*Replace X, Y, Z with the number of threads used in each experiment set.*


#### 1 Threads

Command used to run experiment: `MSORT_THREADS=1 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 30.186184 seconds, 3040 proceses were running
2. 30.352539 seconds, 3041 proceses were running
3. 30.148278 seconds, 3023 processes were running
4. 30.191974 seconds, 3022 processes were running

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1.  20.310181 seconds, 3015 processes were running
2.  20.447532 seconds, 3014 processes were running
3.  20.446851 seconds, 2985 processes were running
4.  21.322212 seconds, 2986 processes were running

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=4 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1.  20.171901 seconds, 2990 processes were running
2.  19.561890 seconds, 3006 processes were running
3.  19.567573 seconds, 3006 processes were running
4.  19.434410 seconds, 3007 processes were running

#### 48 Threads

Command used to run experiment: `MSORT_THREADS=48 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1.  10.667374 seconds, 3021 processes were running
2.  5.612724 seconds,  3020 processes were running
3.  6.259759 seconds, 3020 processes were running
4.  5.419255 seconds, 3023 processes were running

#### 96 Threads

Command used to run experiment: `MSORT_THREADS=96 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1.  4.986077 seconds, 3029 processes were running
2.  4.675342 seconds, 3029 processes were running
3.  5.394646 seconds, 3031 processes were running
4.  4.870897 seconds, 3030 processes were running

## Observations and Conclusions

*Reflect on the experiment results and the optimal number of threads for your concurrent merge sort implementation on different hosts or platforms. Try to explain why the performance stops improving or even starts deteriorating at certain thread counts.*
The optimal number of threads is equal to the thread count of the machine, which is also double the core count. The performance stops improving past the thread count of the machine as there are no available threads to run merge sort. Therefore, it has to wait for another thread to finish running its iteration of merge sort to run the next merge sort. Generating a new thread and waiting for another thread to finish executing merge sort could take more time that just running merge sort sequentially in the same thread. 
