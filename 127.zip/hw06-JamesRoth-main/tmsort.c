/**
 * Threaded Merge Sort
 *
 * Modify this file to implement your multi-threaded version of merge sort. 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#include <unistd.h>

#include <assert.h>
#include <pthread.h>

#define tty_printf(...) (isatty(1) && isatty(0) ? printf(__VA_ARGS__) : 0)

#ifndef SHUSH
#define log(...) (fprintf(stderr, __VA_ARGS__))
#else
#define log(...)
#endif

/** The number of threads to be used for sorting. Default: 1 */
int thread_count = 10;

/* Struct to pass info to threads */
typedef struct {
  long low; //the low index for sorting
  long high; //the high index for sorting
  long *merge_arr; //the array to be sorted
  long *res_arr; //the array in which the result is written
} merge_data_t;

/**
 * Compute the delta between the given timevals in seconds.
 */
double time_in_secs(const struct timeval *begin, const struct timeval *end) {
  long s = end->tv_sec - begin->tv_sec;
  long ms = end->tv_usec - begin->tv_usec;
  return s + ms * 1e-6;
}

/**
 * Print the given array of longs, an element per line.
 */
void print_long_array(const long *array, int count) {
  for (int i = 0; i < count; ++i) {
    printf("%ld\n", array[i]);
  }
}

/**
 * Merge two slices of nums into the corresponding portion of target.
 */
void merge(long nums[], int from, int mid, int to, long target[]) {
  int left = from;
  int right = mid;

  int i = from;
  for (; i < to && left < mid && right < to; i++) {
    if (nums[left] <= nums[right]) {
      target[i] = nums[left];
      left++;
    }
    else {
      target[i] = nums[right];
      right++;
    }
  }
  if (left < mid) {
    memmove(&target[i], &nums[left], (mid - left) * sizeof(long));
  }
  else if (right < to) {
    memmove(&target[i], &nums[right], (to - right) * sizeof(long));
  }

}


/**
 * Sort the given slice of nums into target.
 *
 * Warning: nums gets overwritten.
 */
void merge_sort_aux(long nums[], int from, int to, long target[]) {
  if (to - from <= 1) {
    return;
  }

  int mid = (from + to) / 2;
  merge_sort_aux(target, from, mid, nums);
  merge_sort_aux(target, mid, to, nums);
  merge(nums, from, mid, to, target);
}


/* Runs the mergesort operations within this thread. */
void *run_merge(void *args) {
  merge_data_t *mi = args;

  //printf("low: %d, high: %d\n", mi->low, mi->high);

  //this array is made by every thread, and will be freed (in calling func) once used to merge
  long *result = calloc(mi->high - mi->low, sizeof(long));
  assert(result != NULL);

  mi->res_arr = result;

  //move the nums to be sorted into the correct slice of result; like msort.c
  memmove(result, mi->merge_arr, (mi->high - mi->low) * sizeof(long));

  //sort and write answer into result
  merge_sort_aux(mi->merge_arr, 0, mi->high, result);
}

/**
 * Sort the given array and return the sorted version.
 *
 * The result is malloc'd so it is the caller's responsibility to free it.
 *
 * Warning: The source array gets overwritten.
 */
long *merge_sort(long nums[], int count) {

  long *result = calloc(count, sizeof(long));
  assert(result != NULL);
  memmove(result, nums, count * sizeof(long));
  //check edge case: more threads than items
  if (thread_count > count) {
    //just do it normally; should only be for very small lists
    merge_sort_aux(nums, 0, count, result);
    return result;
  }
  //otherwise, the threaded implementation
  else {
    //for our thread numbers, structs
    pthread_t threads[thread_count];
    merge_data_t struct_list[thread_count];
    //splitting index; for splitting the list between threads
    int si = 0;
    merge_data_t *cur = struct_list;
    int ti = 0;

    //create each thread and assign it an even chunk of the work
    for (; ti + 1 < thread_count; ti++) {
      cur->low = 0;
      cur->high = (count / thread_count);
      cur->merge_arr = nums + si;
      //create the thread
      assert(pthread_create(&threads[ti], NULL, run_merge, cur) == 0);
      //advance to the next struct, next split index
      si += cur->high;
      cur++;
    }
    //create the last thread, give it the extra elements (if any)
    cur->low= 0;
    cur->high = (count / thread_count) + (count % thread_count);
    cur->merge_arr = nums + si;
    assert(pthread_create(&threads[ti], NULL, run_merge, cur) == 0);

    // wait for all threads to finish
    for (int i = 0; i < thread_count; i++) {
      assert(pthread_join(threads[i], NULL) == 0);
    }

    //take each sorted sublist and merge them
    merge_data_t *merge_l = struct_list;
    merge_data_t *merge_r = struct_list;
    merge_r++;

    long *ml = merge_l->res_arr;
    int old_size = (merge_l->high - merge_l->low);
    //basically foldL merge on our set of result lists, thread_count - 1 times
    for (int k = 0; k < thread_count - 1; k++) {
      //get the next array to merge with
      long *mr = merge_r->res_arr;
      //get the size of our list, malloc it, copy data in, and merge
      int size = old_size + (merge_r->high - merge_r->low);
      long *m_arr = malloc(size*sizeof(long));
      memmove(m_arr, ml, old_size*sizeof(long));
      memmove(m_arr + old_size, mr, (merge_r->high - merge_r->low)*sizeof(long));
      merge(m_arr, merge_l->low, old_size, size, result);
      //get the result of merge from result, free m_arr
      free(m_arr);
      ml = result;
      //update old_size with the new size of ml
      old_size = size;

      //free whatever result array we use as they were malloced in their respective threads
      if (k == 0) {
        free(merge_l->res_arr);
      }
      free(merge_r->res_arr);

      //advance left and right
      merge_l++;
      merge_r++;
    }

    //copy the final ml into result
    memmove(result, ml, count*sizeof(long));

    return result;
  }
}

/**
 * Based on command line arguments, allocate and populate an input and a
 * helper array.
 *
 * Returns the number of elements in the array.
 */
int allocate_load_array(int argc, char **argv, long **array) {
  assert(argc > 1);
  int count = atoi(argv[1]);

  *array = calloc(count, sizeof(long));
  assert(*array != NULL);

  long element;
  tty_printf("Enter %d elements, separated by whitespace\n", count);
  int i = 0;
  while (i < count && scanf("%ld", &element) != EOF)  {
    (*array)[i++] = element;
  }

  return count;
}

int main(int argc, char **argv) {

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <n>\n", argv[0]);
    return 1;
  }

  struct timeval begin, end;

  // get the number of threads from the environment variable SORT_THREADS
  if (getenv("MSORT_THREADS") != NULL)
    thread_count = atoi(getenv("MSORT_THREADS"));

  log("Running with %d thread(s). Reading input.\n", thread_count);

  // Read the input
  gettimeofday(&begin, 0);
  long *array = NULL;
  int count = allocate_load_array(argc, argv, &array);
  gettimeofday(&end, 0);

  log("Array read in %f seconds, beginning sort.\n", 
      time_in_secs(&begin, &end));
 
  // Sort the array
  gettimeofday(&begin, 0);
  long *result = merge_sort(array, count);
  gettimeofday(&end, 0);
  
  log("Sorting completed in %f seconds.\n", time_in_secs(&begin, &end));

  // Print the result
  gettimeofday(&begin, 0);
  print_long_array(result, count);
  gettimeofday(&end, 0);
  
  log("Array printed in %f seconds.\n", time_in_secs(&begin, &end));

  free(array);
  free(result);

  return 0;
}
