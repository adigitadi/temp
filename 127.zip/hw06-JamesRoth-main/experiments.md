# Threaded Merge Sort Experiments


## Host 1: XOA VM
 
- CPU: Intel Xeon E5-2690 v3
- Cores: 12 cores, but we can only use 2
- Cache size (if known): 30MB
- RAM: 4 GB
- Storage (if known): 40 GB 
- OS: Ubuntu 22.04.1 LTS 

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*

Our input data is of size 100,000,000. Msort took 23.22 seconds to sort it. It was created using
shuf -i1-100000000 > 100mil.txt. 

### Experiments

*Replace X, Y, Z with the number of threads used in each experiment set.*

#### 1 Threads

Command used to run experiment: MSORT_THREADS=1 ./tmsort 10000000 < 10mil.txt > /dev/null

Approximately 110 processes running. 

Sorting portion timings:

1. 23.844 seconds
2. 23.637 seconds
3. 24.766 seconds
4. 24.523 seconds

#### 2 Threads

Command used to run experiment:MOSRT_THREADS=2 ./tmsort 10000000 < 10mil.txt > /dev/null

Approximately 108 processes running. 

Sorting portion timings:

1. 13.319 seconds
2. 13.278 seconds
3. 13.395 seconds
4. 13.692 seconds

#### 10 Threads

Command used to run experiment: ./tmsort 10000000 < 10mil.txt > /dev/null

Approximately 109 processes running. 

Sorting portion timings:

1. 16.496 seconds
2. 16.901 seconds
3. 16.619 seconds
4. 16.706 seconds


## Host 2: [NAME]

- CPU: Intel(R) Xeon(R) Silver 4214R CPU @ 2.40GHz
- Cores: 48 cores
- RAM: 376 GB
- OS: CentOs Linux 7  

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*

Our input data is of size 100,000,000. Msort took 25.29 seconds to sort it. It was created using
shuf -i1-100000000 > 100mil.txt. 

### Experiments

*Replace X, Y, Z with the number of threads used in each experiment set.*

#### 1 Threads

Command used to run experiment: MSORT_THREADS=1 ./tmsort 10000000 < 10mil.txt > /dev/null

Approximately 3067 processes running. 

Sorting portion timings:

1. 26.024 seconds
2. 26.174 seconds
3. 26.796 seconds
4. 26.008 seconds

#### 2 Threads

Command used to run experiment:MOSRT_THREADS=2 ./tmsort 10000000 < 10mil.txt > /dev/null

Approximately 3050 processes running. 

Sorting portion timings:

1. 14.034 seconds
2. 14.227 seconds
3. 14.317 seconds
4. 14.313 seconds

#### 10 Threads

Command used to run experiment: ./tmsort 10000000 < 10mil.txt > /dev/null

Approximately 3039 processes running

Sorting portion timings:

1. 7.529 seconds
2. 7.571 seconds
3. 7.562 seconds
4. 7.582 seconds


## Observations and Conclusions

For experiment 1, we had 2 cores, and after increasing our threads beyond our number of cores (2) to 10, we stopped seeing significant performance increases.
For experiment 2, we had 48  cores, and after increasing our threads beyond our number of cores (48) to 55, we stopped seeing significant performance increases.
In fact, after increasing the thread count beyond our number of cores, we actually saw a decrease in performance, as the cost of creating the threads becomes
more expensive than the gain from each new thread created.


