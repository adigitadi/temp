# Threaded Merge Sort Experiments


## Host 1: [Ubuntu in Virtual Box]

- CPU: 	Intel
- Cores: 2
- Cache size (if known):
- RAM: 4096 MB
- Storage (if known): 
- OS: Ubuntu

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*
 Dataset has 100000000 elements
 Created using the command "shuf -i1-100000000 > hundred_million.txt"
 It took roughly 29 seconds in msort to sort

### Experiments

#### 1 Threads

Command used to run experiment: `MSORT_THREADS=1 ./tmsort 100000000 < hundred_million.txt >/dev/null `

Sorting portion timings:

1. 28.16 seconds
2. 28.22 seconds
3. 27.98 seconds
4. 27.89 seconds

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 100000000 < hundred_million.txt >/dev/null `

Sorting portion timings:

1. 16.26 seconds
2. 16.01 seconds
3. 16.71 seconds
4. 15.89 seconds

#### 3 Threads

Command used to run experiment: `MSORT_THREADS=3 ./tmsort 100000000 < hundred_million.txt >/dev/null `

Sorting portion timings:

1. 15.10 seconds
2. 15.45 seconds
3. 16.42 seconds
4. 15.46 seconds

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=4 ./tmsort 100000000 < hundred_million.txt >/dev/null `

Sorting portion timings:

1. 16.03 seconds
2. 16.46 seconds
3. 15.69 seconds
4. 15.47 seconds


## Host 2: [WSL in windows]

- CPU: 	Intel
- Cores: 2
- Cache size (if known):
- RAM: 8192 MB
- Storage (if known): 
- OS: Ubuntu

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*
 Dataset has 100000000 elements
 Created using the command "shuf -i1-100000000 > hundred_million.txt"
 It took roughly 42 seconds in msort in this machine

### Experiments

#### 1 Threads

Command used to run experiment: `MSORT_THREADS=1 ./tmsort 100000000 < hundred_million.txt >/dev/null `

Sorting portion timings:

1. 41.95 seconds
2. 39.60 seconds
3. 40.27 seconds
4. 40.96 seconds

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 100000000 < hundred_million.txt >/dev/null `

Sorting portion timings:

1. 23.04 seconds
2. 21.94 seconds
3. 22.45 seconds
4. 21.67 seconds

#### 3 Threads

Command used to run experiment: `MSORT_THREADS=3 ./tmsort 100000000 < hundred_million.txt >/dev/null `

Sorting portion timings:

1. 18.14 seconds
2. 18.69 seconds
3. 19.55 seconds
4. 18.98 seconds

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=4 ./tmsort 100000000 < hundred_million.txt >/dev/null `

Sorting portion timings:

1. 17.23 seconds
2. 17.08 seconds
3. 17.16 seconds
4. 17.54 seconds


## Observations and Conclusions

*Reflect on the experiment results and the optimal number of threads for your concurrent merge sort implementation on different hosts or platforms. Try to explain why the performance stops improving or even starts deteriorating at certain thread counts.*

 After running on different machines I came to the conclusion that the optimal thread count would be twice the core count of the CPU. As the thread count increases the performance increases till the thread count reaches the CPU count. Then performance somewhat increased till the thread reaches the twice the CPU cores. This performance lacks in virtual box, I believe it's due to virtual environment the OS is installed in. So I believe optimal thread count would be twice the core count. 

 After which the performance stays same as there is no extra cores available for thread to execute and even deteriorated a little , I believe this is due to excessive context switching happening between the threads.


