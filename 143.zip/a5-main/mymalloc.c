#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <sys/mman.h>
#include <math.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf

// constant to keep track how big is block_t
#define BLOCK_SIZE sizeof(block_t)

// global lock - initialize it here

pthread_mutex_t mutex;

typedef struct block {
  size_t size;        // How many bytes beyond this block have been allocated in the heap
  struct block *next; // Where is the next block in your linked list
  int free;           // Is this memory free, i.e., available to give away?
  int debug;          // (optional) Perhaps you can embed other information--remember,
                      // you are the boss!
} block_t;

// “head” or “first block of memory”
// keep track of the head of the linked list
block_t *BASE_ADDR = NULL;
size_t PAGE_SIZE = 4096;
int fd;
/**
 * To allocate a memory address that is big enough to hold s
 *
 * s		The given size to be allocated
 *
 * Return the void pointer to the allocated memory address
 */
void *mymalloc(size_t s) {
  assert(s >= 0);
  void *p;
  size_t num_pages;
  block_t *next_block;


  // lock it here
  pthread_mutex_lock(&mutex);
  // if our linkedlist is free
  if (BASE_ADDR == NULL) {
    // makes the first block (this will be the head of our linked list of managed memory blocks)
    // need to fix ceiling
    
    // if the requested size + block size is not multiple of 4096
    if (s + BLOCK_SIZE % PAGE_SIZE != 0) {
      num_pages = (s + BLOCK_SIZE) / PAGE_SIZE + 1;
    } else {
      num_pages = (s + BLOCK_SIZE) / PAGE_SIZE;
    }

    // open a temporary file to map to the memory location
    fd = open("/dev/zero", O_RDWR);
    // map a block of memory equals to the amount of memory we need rounded up to the nearest number of pages
    BASE_ADDR = mmap(0, num_pages * PAGE_SIZE, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    
    // debug_printf("request %zu bytes\n", s + BLOCK_SIZE);
    block_t first_block = {num_pages * PAGE_SIZE - BLOCK_SIZE, NULL, 0, 0};
    // pointer to be returned to user will be the pointer of the block plus the size of the block itself (not size of the requested memory)
    p = BASE_ADDR + BLOCK_SIZE;
    next_block = &first_block;
  } else {
    // go through the linked list and check if there is any block that is free and has size of greater than or equal to the request memory size.
    block_t *temp = BASE_ADDR;
    block_t *prev = NULL;

    while (temp != NULL) {
        // if we find a block that has enough free space
        if (temp->free == 1 && temp->size >= s) {
            // mark it as used
            temp->free = 0;
            // if we have enough space to split up the string
            if (BLOCK_SIZE + s <= temp->size - 1) {
              // the new block will be right after the used space
              block_t *second_block = (block_t *) ((void*) temp + s + BLOCK_SIZE);
              // the new size will be the remaining of used space - header size
              second_block->size = temp->size - BLOCK_SIZE - s;
              // to update the next node
              block_t *temp_next = temp->next;
              // update the stats for our new block
              second_block->free = 1;
              second_block->debug = 0;
              second_block->next = temp_next;
              temp->next = second_block;
              temp->size = s;
            }
            pthread_mutex_unlock(&mutex);
            return ((void *) temp) + BLOCK_SIZE;
        }
        prev = temp;
        temp = temp->next;
    }
    
    // to caluculate the number of pages
    if (s + BLOCK_SIZE % PAGE_SIZE != 0) {
      num_pages = (s + BLOCK_SIZE) / PAGE_SIZE + 1;
    } else {
      num_pages = (s + BLOCK_SIZE) / PAGE_SIZE;
    }

    // open a file to map to a memory location
    fd = open("/dev/zero", O_RDWR);
    next_block = (block_t *) mmap(0, num_pages * PAGE_SIZE, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);

    // update the stats for next block
    next_block->next = NULL;
    next_block->free = 0;
    next_block->size = num_pages * PAGE_SIZE - BLOCK_SIZE;
    prev->next = next_block;
    p = ((void *) next_block) + BLOCK_SIZE; // block_size
  }

  // if we have enough space to split the block
  if (BLOCK_SIZE + s <= PAGE_SIZE - BLOCK_SIZE - 1) {
    // the new block will start right after the space data
    block_t *second_block = (block_t *) ((void*)next_block + s + BLOCK_SIZE);
    // update the stats for second block
    second_block->size = PAGE_SIZE - (2*BLOCK_SIZE) - s;
    second_block->free = 1;
    second_block->debug = 0;
    second_block->next = NULL;
    next_block->next = second_block;
    // update the size of old block
    next_block->size = s;
  }
  pthread_mutex_unlock(&mutex);
  if (!p) {
    // We are out of memory
    // if we get NULL back from malloc
    debug_printf("failed to allocated %zu bytes", s);
    return NULL;
  }
  return p;
}

/**
 * To allocate and initialize memory that is big enough to hold (nmemb * s)
 *
 * nememb	the number of elements
 * s		how big is each of the element
 *
 * Return the void pointer to the beginning of the allocated and initialized memory block 
 */
void *mycalloc(size_t nmemb, size_t s) {
  // initialize the data size given size of nmemb and s.
  size_t data_size = nmemb * s;
  assert(data_size >= 0);
  // check if the memory size is negative
  void *p = mymalloc(data_size);
  
  if (!p) {
    // We are out of memory
    // if we get NULL back from malloc
    debug_printf("failed to allocated %zu bytes", s);
    return NULL;
  }

  memset(p, 0, data_size);
  //pthread_mutex_unlock(&mutex);

  // debug_printf("calloc %zu bytes\n", s);

  return p;
}


/**
 * To free (recycle) the given memory location
 * *ptr      the pointer to memory to be deleted
 *
 * Do not return anything
 */
void myfree(void *ptr) {
  // debug_printf("Freed bytes\n");

  // if the pointer point to NULL
  if (ptr == NULL) {
	  return;
  }
  // iterate through the free blocks from the head block. check if head + block_size is the pointer.
  // If it is then set the free flag to 1 (true)
  block_t *temp = BASE_ADDR;
  block_t *prev = NULL;
  // loop through each of the nodes in the linkedlist to find the given memory address to free
  
  // lock 
  pthread_mutex_lock(&mutex);
  while (temp != NULL) {
    // if we find the block we want to delete
    if ((void*) temp + BLOCK_SIZE == ptr) {
      // if size is greater than 4096 then we want to use munmap
      if (temp->size >= PAGE_SIZE - BLOCK_SIZE) {
        // the previous node is not null
        if (prev != NULL) {
          // we skip the current node
          prev->next = temp->next;
        }
        // delete the content
        munmap(temp, temp->size + BLOCK_SIZE);
        // unlock
        pthread_mutex_unlock(&mutex);
        return;
      }
      temp->free = 1;
      // do coalese here - Observation: the reason that we do not do an iterative coalese here is because we believe there would be under no circumstances where there are 
      // more than 2 contiguous free blocks in our linkedlist. Everytime we free a block, we always check and coalese the contiguous blocks, and so we only need to care about 
      // the block that is immediately before and after the current block when coalesing. 
      // if previous is not null and previous is free
      if (prev != NULL && prev->free == 1) {
        // we merge all the data and rewire
        prev->size += temp->size + BLOCK_SIZE;
        prev->next = temp->next;
        temp = prev;
      } 
      // if next node is not null and it is also free, we will coalesce it
      if (temp->next!= NULL && temp->next->free == 1) {
        // we merge all the data and rewire
        temp->next = temp->next->next;
        temp->size += temp->next->size + BLOCK_SIZE;
      }

      pthread_mutex_unlock(&mutex);
      return;
    }
    prev = temp;
    temp = temp->next;
  }
  pthread_mutex_unlock(&mutex);

  debug_printf("not freed %p \n", ptr);
}
