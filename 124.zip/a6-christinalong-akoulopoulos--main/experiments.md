# Threaded Merge Sort Experiments

## Host 1: Khoury Login

- CPU: Intel(R) Xeon(R) Silver 4214R CPU @ 2.40GHz
- Cores: 12
- Cache size (if known): 16896 KB
- RAM: 394637612 kB
- Storage (if known): Unknown
- OS: Linux

### Input data

Data set is every integer in range [1, 50,000,000] shuffled. It was generated with `shuf -i1-50000000 > fifty-million.txt`

`msort` took 12.552438 seconds to sort.

### Experiments

#### 1 Thread

Command used to run experiment: `MSORT_THREADS=1 ./tmsort 50000000 < fifty-million.txt > /dev/null`

Sorting portion timings:

1. **10.296283** seconds
2. **10.452411** seconds
3. **10.252435** seconds
4. **10.278187** seconds

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 50000000 < fifty-million.txt > /dev/null`

Sorting portion timings:

1. **10.465475** seconds
2. **11.750177** seconds
3. **11.738885** seconds
4. **11.190849** seconds

#### 12 Threads

Command used to run experiment: `MSORT_THREADS=12 ./tmsort 50000000 < fifty-million.txt > /dev/null`

Sorting portion timings:

1. **7.685825** seconds
2. **7.792674** seconds
3. **6.850442** seconds
4. **6.513052** seconds

## Host 2: [MAC M1]

- CPU: M1
- Cores: 8
- Cache size (if known):
- RAM: 16 GB
- Storage (if known): 1 TB
- OS: MACOS
​
### Input data
​
Generated 50 million unsorted number sequence with `shuf -i1-50000000 > fifty-million.txt`
​
### Experiments

#### 1 Thread
​
Command used to run experiment: `MSORT_THREADS=1 ./msort 50000000 < fifty-million.txt > /dev/null`
​
Sorting portion timings:
​
1. **10.140793** seconds
2. **9.268495** seconds
3. **9.732047** seconds
4. **10.015646** seconds
​
#### 2 Threads
​
Command used to run experiment: `MSORT_THREADS=2 ./tmsort 50000000 < fifty-million.txt > /dev/null`
​
Sorting portion timings:
​
1. **9.229572** seconds
2. **8.848714** seconds
3. **8.838755** seconds
4. **9.190603** seconds
​
#### 8 Threads
​
Command used to run experiment: `MSORT_THREADS=8 ./tmsort 50000000 < fifty-million.txt > /dev/null`
​
Sorting portion timings:
​
1. **5.757077** seconds
2. **6.385232** seconds
3. **6.646990** seconds
4. **6.725992** seconds
​
#### 16 Threads
​
Command used to run experiment: `MSORT_THREADS=16 ./tmsort 50000000 < fifty-million.txt > /dev/null`
​
Sorting portion timings:
​
1. **7.731399** seconds
2. **7.471246** seconds
3. **7.523663** seconds
4. **6.842601** seconds

## Observations and Conclusions

On the Khoury Linux machine, there was no clear improvement from 1 to 2 threads. This is likely because a single thread increase is not enough to make a signficiant difference in performance, as the amount of work is not cut down noticably. However, the jump to 12 threads caused a significant improvement over the previous trials. This number of threads corresponds to the VM's number of cores, which allows for optimal efficiency. Moreover, the 12 threads significantly split the work required to sort the input data.

On the M1 Mac, there was an increase in performance from 1, to 2, to 8 threads. However, once 16 threads was reached, performance degraded. This is likely due to the fact that the computer has 8 cores, which means it is optimally threaded at 8. However, running 16 threads does not improve, and slightly degrades performance, as it attempts to reach beyond the capabilities of the machine.