# Threaded Merge Sort Experiments

## Host 1: VDI host 054

- CPU: Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz
- Cores: 4
- Cache size (if known): 35840 KB
- RAM: 8 GB
- Storage (if known): 228 GB 
- OS: CentOS Linux

### Input data

I used the makefile's diff operation to run with a data set of size 100,000,000. This generates numbers up to 100,000,000 and then shuffles them before feeding them into the program. This took on average around 26 seconds for msort to sort.

### Experiments

#### 1 Threads

Processes: 228

Command used to run experiment: `make diff-100000000`

Sorting portion timings:

1. 13.763740 seconds
2. 13.710449 seconds
3. 13.889992 seconds
4. 13.736054 seconds

#### 2 Threads

Processes: 227

Command used to run experiment: `make diff-100000000`

Sorting portion timings:

1. 13.773217 seconds
2. 13.837365 seconds
3. 13.737809 seconds
4. 13.760617 seconds

#### 4 Threads

Processes: 227

Command used to run experiment: `make diff-100000000`

Sorting portion timings:

1. 11.418750 seconds
2. 11.100858 seconds
3. 11.027284 seconds
4. 11.280660 seconds

## Host 2: personal macOS machine

- CPU: Apple M1 Pro
- Cores: 8
- Cache size (if known): 131072 KB
- RAM: 16 GB
- Storage (if known): 494.38 GB
- OS: macOS Ventura 13.0

### Input data

I used the makefile's diff operation to run with a data set of size 100,000,000. This generates numbers up to 100,000,000 and then shuffles them before feeding them into the program. This took on average around 16 seconds for msort to sort.

### Experiments

#### 1 Threads

Processes: 627

Command used to run experiment: `make diff-100000000`

Sorting portion timings:

1. 8.462053 seconds
2. 8.474236 seconds
3. 8.453017 seconds
4. 8.460397 seconds

#### 2 Threads

Processes: 633

Command used to run experiment: `make diff-100000000`

Sorting portion timings:

1. 8.491033 seconds
2. 8.463933 seconds
3. 8.465411 seconds
4. 8.492657 seconds

#### 8 Threads

Processes: 631

Command used to run experiment: `make diff-100000000`

Sorting portion timings:

1. 6.678660 seconds
2. 6.684584 seconds
3. 6.719555 seconds
4. 6.662572 seconds

## Observations and Conclusions

Though there is an increase in efficiency when more threads were used, I was surprised at how slight the change was. There is almost no difference between using 1 thread versus 2 threads (in fact, it seems worse). When I tried running it with 16 threads, the sort time was 6.459213. This is only marginally better than 8 threads. When I tried with 80 threads, it was 6.394879. Looks like the benefit to adding threads drops as you increase the threads. This could be because there is a limitation in the algorithm I've used, since it doesn't do k-way merging. If this were the case, then we could make use of having many more parallel threads.


