(This is a template. Delete this line and fill in the sections below)
# Threaded Merge Sort Experiments


## Host 1: Khoury Linux Server

- CPU: Intel(R) Xeon(R) Silver 4214R CPU @ 2.40GHz
- Cores: 2
- Cache size (if known): N/A
- RAM: 395637.612
- Storage (if known): 1440 MB
- OS: CentOS

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*

The dataset we are using is 50,000,000 numbers long. We created it by using shuf -i1-50000000 > fiftymil.txt
so this made 50 million different numbers seperated by whitespace that outputted to a text file.
it took msort 12.05 seconds to sort it.

### Experiments

*Replace 2, 3, 4 with the number of threads used in each experiment set.*

Before running we ran ps aux | wc -l and the output was 2945

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 50000000 < fiftymil.txt > fifout.txt`

Sorting portion timings:

1. 6.24 seconds
2. 6.22 seconds
3. 6.10 seconds
4. 6.22 seconds

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=4 ./tmsort 50000000 < fiftymil.txt > fifout.txt`

Sorting portion timings:

1. 3.47 seconds
2. 3.44 seconds
3. 3.26 seconds
4. 4.17 seconds

#### 10 Threads

Command used to run experiment: `MSORT_THREADS=10 ./tmsort 50000000 < fiftymil.txt > fifout.txt`

Sorting portion timings:

1. 2.04 seconds
2. 2.01 seconds
3. 2.06 seconds
4. 1.91 seconds

#### 15 Threads

Command used to run experiment: `MSORT_THREADS=15 ./tmsort 50000000 < fiftymil.txt > fifout.txt`

Sorting portion timings:

1. 1.71 seconds
2. 1.76 seconds
3. 1.77 seconds
4. 1.70 seconds

#### 30 Threads

Command used to run experiment: `MSORT_THREADS=30 ./tmsort 50000000 < fiftymil.txt > fifout.txt`

Sorting portion timings:

1. 2.1 seconds
1. 2.12 seconds
2. 2.21 seconds
4. 2.23seconds

*repeat sections as needed*


## Host 2: Ubuntu UTM VM Running on Mac


- CPU: arm64
- Cores: 6
- Cache size (if known): n/a
- RAM: 4096mb
- Storage (if known): n/a
- OS: Ubuntu

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*

(The dataset is the same as the first experiment)
The dataset we are using is 50,000,000 numbers long. We created it by using shuf -i1-50000000 > fiftymil.txt 
so this made 50 million different numbers seperated by whitespace that outputted to a text file. 
it took msort 12.05 seconds to sort it.


### Experiments

Before running we ran ps aux | wc -l and the output was 219

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 50000000 < fiftymil.txt > fifout.txt`

Sorting portion timings:

1. 6.23 seconds
2. 6.21 seconds
3. 6.14 seconds
4. 6.10 seconds

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 50000000 < fiftymil.txt > fifout.txt`

Sorting portion timings:

1. 3.47 seconds
2. 3.44 seconds
3. 3.26 seconds
4. 4.17 seconds

#### 10 Threads

Command used to run experiment: `MSORT_THREADS=10 ./tmsort 50000000 < fiftymil.txt > fifout.txt`

Sorting portion timings:

1. 2.04 seconds
2. 2.01 seconds
3. 2.06 seconds
4. 1.91 seconds

#### 15 Threads

Command used to run experiment: `MSORT_THREADS=15 ./tmsort 50000000 < fiftymil.txt > fifout.txt`

Sorting portion timings:

1. 1.11 seconds 
2. 1.46 seconds
3. 1.37 seconds
4. 1.20 seconds

#### 30 Threads

Command used to run experiment: `MSORT_THREADS=30 ./tmsort 50000000 < fiftymil.txt > fifout.txt`

Sorting portion timings:

1. 0.01 seconds
1. 0.12 seconds 
2. 0.21 seconds
4. 0.23seconds

*repeat sections as needed*


## Observations and Conclusions

We observed that there was a point where the Khoury server had less improvements once we started using more threads
this was because the khoury server only gives us 2 cores to work with. Which means that there are less threads to work with

When we tried using a different system with more cores to work with, adding threads made it more efficient.

our conclusion is that thread count corresponds to the number of cores the system has
so at some point there will be deminishing returns