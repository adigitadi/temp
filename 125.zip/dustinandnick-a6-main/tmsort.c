/**
 * Threaded Merge Sort
 *
 * Modify this file to implement your multi-threaded version of merge sort.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>

#include <unistd.h>

#include <assert.h>

#define tty_printf(...) (isatty(1) && isatty(0) ? printf(__VA_ARGS__) : 0)

#ifndef SHUSH
#define log(...) (fprintf(stderr, __VA_ARGS__))
#else
#define log(...)
#endif

/** The number of threads to be used for sorting. Default: 1 */
int thread_count = 1;

/** Struct representing the thread_data */
struct thread_data{
    pthread_t thread_id; // thread_id
    int from;
    int to;
    long int * arr;
    long int * res;
    int count; // # of elements in arr
} ;

/**
 * Compute the delta between the given timevals in seconds.
 */
double time_in_secs(const struct timeval *begin, const struct timeval *end) {
    long s = end->tv_sec - begin->tv_sec;
    long ms = end->tv_usec - begin->tv_usec;
    return s + ms * 1e-6;
}

/**
 * Print the given array of longs, an element per line.
 */
void print_long_array(const long *array, int count) {
    for (int i = 0; i < count; ++i) {
        printf("%ld\n", array[i]);
    }
}

/**
 * Merge two slices of nums into the corresponding portion of target.
 */
void merge(long nums[], int from, int mid, int to, long target[], int count) {
    int left = from;
    int right = mid;


    int i = from;
    for (; i < to && left < mid && right < to; i++) {
        if (nums[left] <= nums[right]) {
            target[i] = nums[left];
            left++;
        }
        else {
            target[i] = nums[right];
            right++;
        }
    }
    if (left < mid) {
        memmove(&target[i], &nums[left], (mid - left) * sizeof(long));
    }
    else if (right < to) {
        memmove(&target[i], &nums[right], (to - right) * sizeof(long));
    }

}


/**
 * Sort the given slice of nums into target.
 *
 * Warning: nums gets overwritten.
 */
void merge_sort_aux(long nums[], int from, int to, long target[], int count) {
    if (to - from <= 1) {
        return;
    }

    int mid = (from + to) / 2;

    merge_sort_aux(target, from, mid, nums, count);
    merge_sort_aux(target, mid, to, nums, count);

    merge(nums, from, mid, to, target, count);
}


/**
 * Sort the given array and return the sorted version.
 *
 * The result is malloc'd so it is the caller's responsibility to free it.
 *
 * Warning: The source array gets overwritten.
 */
long *merge_sort(long nums[], int count) {
    long *result = calloc(count, sizeof(long));
    assert(result != NULL);

    memmove(result, nums, count * sizeof(long));

    merge_sort_aux(nums, 0, count, result, count);

    return result;
}

/**
 * Based on command line arguments, allocate and populate an input and a
 * helper array.
 *
 * Returns the number of elements in the array.
 */
int allocate_load_array(int argc, char **argv, long **array) {
    assert(argc > 1);
    int count;
    count = atoi(argv[1]);

    *array = calloc(count, sizeof(long));
    assert(*array != NULL);

    long element;
    tty_printf("Enter %d elements, separated by whitespace\n", count);
    int i = 0;
    while (i < count && scanf("%ld", &element) != EOF)  {
        (*array)[i++] = element;
    }

    return count;
}

/**
 * This is the initial call that creates the result
 * and then passes the work of the thread to the
 * helper.
 *
 * Modifies both arrays and exits when finished.
 */
void* merge_sort_thread(void* args) {
    struct thread_data* work;
    work = (struct thread_data*) args;

    // creates result array
    long * result = calloc(work->count, sizeof(long));
    assert(result != NULL);
    memmove(result, work->arr,work->count * sizeof(long));

    work->res = result;

    int to;
    int from;

    to = work->to;
    from = work->from;

    /** Passes it to the helper */
    merge_sort_aux(work->arr, from, to, work->res, work->count);

    // waits till exit
    return NULL;
}


int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <n>\n", argv[0]);
        return 1;
    }


    struct timeval begin, end;

    // get the number of threads from the environment variable SORT_THREADS
    if (getenv("MSORT_THREADS") != NULL)
        thread_count = atoi(getenv("MSORT_THREADS"));

    log("Running with %d thread(s). Reading input.\n", thread_count);

    // Read the input
    gettimeofday(&begin, 0);
    long *array = NULL;
    int count = allocate_load_array(argc, argv, &array);
    gettimeofday(&end, 0);

    // get the thread id
    pthread_t thread_id[thread_count];
    // creates an array of data for each thread
    struct thread_data thread_data_array[thread_count];

    int from = 0; // get the lowest index of array for each thread
    int thread_work_load = count / thread_count; // get the highest index of array for each thread

    log("Array read in %f seconds, beginning sort.\n",
        time_in_secs(&begin, &end));

    gettimeofday(&begin, 0);

    int useArr = 0;

    // Thread count is larger than number of elements
    // make thread_count equal to count
    if (thread_count > count) {
        thread_count = count;
        useArr = 1;
    }

    // 7 elements and 3 threads
    // to :   2  4  7
    // from : 0  2  4
    /** Creates the data for each thread, dividing up the work between sections of arr */
    for (int i = 0; i < thread_count; i++, from += thread_work_load){
        thread_data_array[i].from = from;
        thread_data_array[i].to = from + thread_work_load;
        if (i == (thread_count) - 1) {
            thread_data_array[i].to = count;
        }
    }

    /** this creates the threads and allocates the thread_data_array to keep track of each thread's data */
    for(int i = 0; i < thread_count; i++) {
        thread_id[i] = i;
        thread_data_array[i].arr = array;
        thread_data_array[i].thread_id = thread_id[i];
        thread_data_array[i].count = count;
        assert(pthread_create(&thread_id[i], NULL, merge_sort_thread, (void*)&thread_data_array[i]) == 0);
    }


    /** Joins the threads together */
    for(int i = 0; i < thread_count; i++) {
        assert(pthread_join(thread_id[i], NULL)== 0);
    }

    /**
     *  Merges all the threads separate work together
     */
    struct thread_data* init_work = &thread_data_array[0];
    for (int i = 1; i < thread_count; i++) {
        struct thread_data* work = &thread_data_array[i];
        merge(init_work->arr, init_work->from, work->from - 1, work->to, work->res, work->count);
    }
    gettimeofday(&end, 0);

    log("Sorting completed in %f seconds.\n", time_in_secs(&begin, &end));

    // Print the result
    gettimeofday(&begin, 0);
    if (useArr) {
        print_long_array(init_work->arr, count);
        gettimeofday(&end, 0);
    } else {
        print_long_array(init_work->res, count);
        gettimeofday(&end, 0);
    }
    log("Array printed in %f seconds.\n", time_in_secs(&begin, &end));

    free(array);

    return 0;
}
