#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h> 
#include <stdio.h> 
#include <unistd.h>
#include <string.h>

// Include any other headers we need here


// will need a struct ("block") with size of data, whether it is
//  free or not, and a pointer to the next block
//  linked list is interlaced with data, so freeing data will release gaps sort of

// I got help from TAs, friends, and the internet for this part as I was stuck for several hours
//    struggling to figure out how to align the block headers.
typedef char ALIGN[16];

union block {
  struct {
    size_t size;
    unsigned free;
    union block *next;
  } s;
  ALIGN stub;

};
typedef union block block_t;

// NOTE: You should NOT include <stdlib.h> in your final implementation


#include <debug.h> // definition of debug_printf
#define BLOCK_SIZE sizeof(block_t)

// the head of our list of blocks 
block_t *head = NULL;


// returns a pointer to the next free block with correct size, or NULL if a block isn't found.
block_t *next_free_block(size_t size) {

  block_t *toReturn = head;
  
  while(toReturn != NULL) {
  
    if (toReturn->s.free == 1 && size <= toReturn->s.size) {
      return toReturn;
    }
    toReturn = toReturn->s.next;
  }
  
  return NULL;

}

// returns the last block in the lsit, or NULL if there are 0 blocks in the list.
block_t *get_last_block() {

  if (head == NULL) {
    return NULL;
  }

  block_t *toReturn = head;

  while (toReturn->s.next != NULL) {
    toReturn = toReturn->s.next;

  }

  return toReturn;
}

void *mymalloc(size_t s) {

  //void *p = (void *) malloc(s); // In your solution no calls to malloc should be
                               // made! Determine how you will request memory :)

  // search through linked list one block at a time
  // find first block where free = true and size >= s
  // if can't find one, then allocate more memory at the end
  // point prev block to this block
  // initialize size

  block_t *new_block = next_free_block(s);

  // need to create a new block, as no existing ones will work.
  if (new_block == NULL) {
    
    size_t new_size = sizeof(block_t) + s;
    new_block = sbrk(new_size);
    new_block->s.size = s;
    new_block->s.free = 0;
    new_block->s.next = NULL;

    // if list of blocks is currently empty, make this one the head of the list
    if (head == NULL) {

      head = new_block;

    }
    else {
      // link our new block to the list
      block_t *last = get_last_block();
      last->s.next = new_block;
    }

    // ready to print debug and return

  }
  else {
    // we found a block, so just use that one!

    new_block->s.free = 0;

  }

  debug_printf("malloc %zu bytes\n", s);

  return (void*)(new_block + 1);
}

// calloc implementation using mymalloc
void *mycalloc(size_t nmemb, size_t s) {

  void *new_block = malloc(nmemb * s);

  memset(new_block, 0, nmemb * s);

  debug_printf("calloc %zu bytes\n", s);
  
  return new_block;

}

// implementation of free
void myfree(void *ptr) {
  debug_printf("Freed some memory\n");

  block_t *toFree;

  toFree = (block_t*)ptr - 1;
  toFree->s.free = 1;
}

