#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h> 
#include <stdio.h> 

// Include any other headers we need here
#include <unistd.h>
#include <string.h>
#include <assert.h>
// NOTE: You should NOT include <stdlib.h> in your final implementation

#include "debug.h" // definition of debug_printf

#define BLOCK_SIZE sizeof(block_t)

typedef struct block {
  struct block *next;
  size_t size;
  int free;
} block_t;

void *malloc_first_fit(size_t s);

static block_t *head = NULL; // Head of linked list of blocks

// DEBUG
// Total bytes requested, based on malloc calls
size_t debug_total_bytes = 0;
//#define DEBUG_INFO_AT_EXIT

void *mymalloc(size_t s) {
  void *p = malloc_first_fit(s);
  if (!p) {
    // We are out of memory
    // if we get NULL back from malloc
    debug_printf("malloc for %zu bytes failed\n", s);
    return NULL;
  }

  debug_printf("Malloc %zu bytes\n", s);
  debug_total_bytes += s;

  return p;
}

void *mycalloc(size_t nmemb, size_t s) {
  void *p = mymalloc(nmemb * s);
  if (!p) {
    // We are out of memory
    // if we get NULL back from malloc
    debug_printf("calloc for %zu bytes failed (malloc failed)\n", s);
    return NULL;
  }

  // Set entire memory region to 0s
  memset(p, '\0', nmemb * s);
  debug_printf("Calloc %zu bytes\n", nmemb * s);

  return p;
}

/*
 * Marks a block of memory as free (available for allocation again)
 * All free calls assumed to be valid
 * (ptr points to an unfreed region returned by m/calloc OR NULL)
 * Double free behavior is undefined
 */
void myfree(void *ptr) {
  // Freeing NULL has no effect as with std free
  if (!ptr) {
    debug_printf("Freed NULL (no effect)\n");
    return;
  }

  block_t *block = (block_t *)ptr - 1;
  //assert(!block->free); // Only when user passes valid unfreed address
  block->free = 1;
  debug_printf("Freed %zu bytes\n", block->size);
}

/*
 * Finds the first block from head with at least the requested space s,
 * and returns a pointer to the start of the usable space.
 * No splitting or coalescing is performed.
 * If no block is available, the heap is grown as needed.
 * If growing fails, returns NULL.
 */
 void *malloc_first_fit(size_t s) {
  // Linked list traversal
  block_t *curr = head;
  block_t *prev = NULL;
  while (curr) {
    // Block is free and is large enough
    if (curr->free && curr->size >= s) {
      // Mark as allocated and return pointer to memory
      // (All blocks remain in the list, distinguished by the free flag)
      curr->free = 0;

      //debug_printf("malloc_first_fit: requested %zu, reused block at %p with size %zu\n", s, curr + 1, curr->size);

      return curr + 1;
    }
    // Otherwise, move on to next block
    prev = curr;
    curr = curr->next;
  }

  // No usable block
  // Grow heap by exact amount needed for new block for size s
  void *prev_brk = sbrk(BLOCK_SIZE + s);
  if (prev_brk == (void *) -1) {
    return NULL;
  }
  //debug_printf("Heap grown by %zu\n", (char *)sbrk(0) - (char *)prev_brk);  

  // Emplace new block at start of new heap area
  block_t *new_block = prev_brk;
  *new_block = (block_t){NULL, s, 0};
  // Add block to end of linked list, possibly as head
  if (prev) {
    prev->next = new_block;
  } else {
    head = new_block;
  }
  //debug_printf("malloc_first_fit: requested %zu, allocated new block at %p with size %zu\n", s, new_block + 1, new_block->size);

  //assert(sbrk(0) == (char *)new_block + BLOCK_SIZE + s);

  return new_block + 1; // Return address of memory space
}

#ifdef DEBUG_INFO_AT_EXIT
#ifndef DEMO_TEST
// Called at program exit to print debug info
void __attribute__((destructor)) debug_dtor() {
  debug_printf("===============AT EXIT===============\n");
  debug_printf("Size of block header - %ld\n", BLOCK_SIZE);
  debug_printf("Total requested bytes - %zu\n", debug_total_bytes);

  debug_printf("Final state of blocks (according to linked list):\n");

  // Traverse block list and tally
  int blocks_free = 0, blocks_unfree = 0;
  size_t bytes_free = 0, bytes_unfree = 0;
  block_t *curr = head;
  while (curr) {
    fprintf(stderr, "(%p %s | [%zu]) -> ", curr, curr->free ? "FREE" : "UNFREE", curr->size);
    if (curr->free) {
      ++blocks_free;
      bytes_free += curr->size;
    } else {
      ++blocks_unfree;
      bytes_unfree += curr->size;
    }

    curr = curr->next;
  }
  fprintf(stderr, "END\n");

  debug_printf("Blocks free - %d\n", blocks_free);
  debug_printf("Blocks not freed - %d\n", blocks_unfree);
  debug_printf("Bytes of memory free - %zu\n", bytes_free);
  debug_printf("Bytes of memory not freed - %zu\n", bytes_unfree);
  debug_printf("Total bytes of memory space - %zu\n", bytes_free + bytes_unfree);
  
  // Total space tracked by block list, including headers
  size_t total_bytes_managed = bytes_free + bytes_unfree + BLOCK_SIZE * (blocks_free + blocks_unfree);
  debug_printf("Total bytes tracked (including headers) - %zu\n", total_bytes_managed);
}
#endif
#endif
