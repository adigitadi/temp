#ifndef DEMO_TEST
#include <malloc.h>
#else
#include <stdlib.h>
#endif

#include <stdio.h>
#include <assert.h>

int main() {

  // calloc with varying parameters and check that block is fully zeroed
  for (size_t n = 0; n <= 16; ++n) {
    for (size_t s = 0; s <= 16; ++s) {
      void *data = calloc(n, s);
      for (char *byte = data; byte < (char *)data + n * s; ++byte) {
        assert(*byte == '\0');
      }
      free(data);
    }
  }

  return 0;
}
