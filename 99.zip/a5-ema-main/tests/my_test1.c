#ifndef DEMO_TEST
#include <malloc.h>
#else
#include <stdlib.h>
#endif

#include <stdio.h>

int main() {

  // Constantly allocate and free 0 bytes.
  for (int i = 0; i < 30; i++) {
    void *data = malloc(0);
    free(data);
  }

  return 0;
}
