#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <sys/mman.h>
#include <malloc.h> 
#include <stdio.h> 
#include <stdbool.h> 
#include <unistd.h>
#include <string.h>
#include <pthread.h>

// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

typedef struct block {
  size_t size;        // How many bytes beyond this block have been allocated in the heap
  struct block *next; // Where is the next block in your linked list
  int free;           // Is this memory free, i.e., available to give away?
  //int debug;          // (optional) Perhaps you can embed other information--remember,
                      // you are the boss!
} block_t;

pthread_mutex_t mal_lock = PTHREAD_MUTEX_INITIALIZER;

#define BLOCK_SIZE sizeof(block_t)

#define PAGE_SIZE sysconf(_SC_PAGE_SIZE)

#include <debug.h> // definition of debug_printf

//Global head block (no size and pretty much just a placeholder for now)
block_t head = {0, NULL, false};
block_t *head_ptr = &head; 

//Global Heap (linked list) to store all allocated blocks

void *mymalloc(size_t s) {
  
  bool foundBlock = false;  //boolean that will determine whether we need to make a new block or found an available one to use
  
  block_t *return_address_of_mem = NULL;    //ptr containing address where memory starts that we will return at the end.
                               
  //Idea: Start by looking through our heap (which is just all of the "next" blocks) for the first block that is both free and has a size >= s
  //When we find a block that works, simply return the pointer to this block's memory (should be address+1 when cast to block_t)
  
  block_t *newBlock; // the new memory block from splitting memory if it is big enough to split or initiating new memory
  
  block_t *traverser = head_ptr->next;
  block_t *tail = head_ptr;                 //convenience variable for finding the tail as assigning it to NewBlock 
  
  //debug_printf("Beginning Traverse");
  
  //If the requested size is less than a page
  pthread_mutex_lock(&mal_lock);
  if (s < PAGE_SIZE - BLOCK_SIZE) {
    while(traverser != NULL)
    {
      if(traverser->size >= s && traverser->free >= true) {
        foundBlock = true;
        //debug_printf("Found Block");
        debug_printf("Malloc %zu bytes\n", s);

	// If its possible to split memory
	if (traverser->size > s+BLOCK_SIZE+1) {
	  newBlock = (void*)((char*)traverser + BLOCK_SIZE + s);
	  newBlock->size = (traverser->size - s) - BLOCK_SIZE;
	  traverser->size = s;
	  newBlock->next = traverser->next;
	  traverser->next = newBlock;
	  traverser->free = false;
	  newBlock->free = true;
	}
	// If block size is equal to requested size or bigger but just not enough to split it
	else {
	  traverser->free = false;
	}
	pthread_mutex_unlock(&mal_lock);
        return traverser + 1;  //since we are trying to return the memory adress right after block, we return traverser+1; 
      }
    
      if (traverser->next == NULL) {  //if we are about to reach the end, we know traverser is currently at tail so we can assign it here
        tail = traverser;
      }
    
      traverser = traverser->next;                 // Move to next node
    
    }
  }
  
  //debug_printf("Traverse complete, now creating block");
  
  //If we don't find available block, we need to make a new block by 1. calling sbrk 2. Creating a newBlock 3. assigning it as the new tail
  
  //rethink variable since should only reach when block is not found but w/e
  //Here is where we make a new block when none are available
  if (!foundBlock) {
    int numPages;
    if (s < PAGE_SIZE - BLOCK_SIZE) {
      newBlock = (block_t*)mmap(NULL, PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
      newBlock->size = s;
      newBlock->next = NULL;
      newBlock->free = false;
      tail->next = newBlock;
      pthread_mutex_unlock(&mal_lock);
    }
    // If requested size greater than or equal to a page minus a block size
    else {
      if ((s + BLOCK_SIZE) % PAGE_SIZE == 0) {
	numPages = (s+BLOCK_SIZE)/PAGE_SIZE;
      }
      else {
	numPages = ((s+BLOCK_SIZE)/PAGE_SIZE)+1;
      }
      newBlock = (block_t*)mmap(NULL, numPages * PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
      newBlock->size = numPages * PAGE_SIZE;
      newBlock->next = NULL;
      newBlock->free = false;
      pthread_mutex_unlock(&mal_lock);
    }
    return_address_of_mem = newBlock + 1;
  }
  return return_address_of_mem;
}

//write 0 to all of the actual memory addresses incrementing by nmemb
void *mycalloc(size_t nmemb, size_t s) {
  
  //essentially use mymalloc to try and get a block of data size s,  Then with the pointer that it returns,  initialize data to 0.

  void *block_memory = (void *) mymalloc(s);

  if (block_memory == NULL) {
    // We are out of memory if we get NULL back from mymalloc
     //debug_printf("Not enough memory available, sorry\n");
  }
  else {
    //fills data with zeros
    memset(block_memory, 0, s);
  }
  debug_printf("Calloc %zu bytes\n", s);

  return block_memory;
}

void coalesceFreeMemory() {
  
  // Start at Beginning of global list, on first ,free block encounteres begin counting up blocks to combine
  block_t *traverser = head_ptr->next;
	
  int concurrentFree = false;  //tracks whether we are searching for first free or looking for a concurrent free to combine
	
  size_t bytesToCombine = 0;
  block_t* firstFreeFound;	
  
  while(traverser != NULL)
  {
    if (traverser->free == true && concurrentFree == false) {
      //First free, now look to combine
      bytesToCombine = 0;
      firstFreeFound = traverser;
      concurrentFree = true;
    }
    else if (traverser->free == true && concurrentFree == true){
      //concurrent free
      bytesToCombine += traverser->size + BLOCK_SIZE;
      
    }
    else if (traverser->free == false && concurrentFree == true) {
      //First false fonud after the free
      firstFreeFound->size += bytesToCombine;
      firstFreeFound->next = traverser;
      concurrentFree = false;
    }
	  
    traverser = traverser->next;  
  } 
}

void myfree(void *ptr) {

  //Cast to a block ptr and decrement to get address of block  
  block_t* new_ptr = (block_t*) ptr - 1;
	
  size_t s = new_ptr->size;
  
  if(new_ptr->size < PAGE_SIZE) 
  {
    //Logic for ByteSized Blocks
    
    if (new_ptr->free == false) 
    {
      pthread_mutex_lock(&mal_lock);
      new_ptr->free = true;
      
      coalesceFreeMemory();
    
      pthread_mutex_unlock(&mal_lock);
    }
    
  }
  else if (new_ptr->size >= PAGE_SIZE) 
  {
     //Logic for PageSized Blocks
    pthread_mutex_lock(&mal_lock);
    munmap(new_ptr, new_ptr->size);
    pthread_mutex_unlock(&mal_lock);
  }
  debug_printf("Freed %zu bytes\n", s);
}
