#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#include <malloc.h>
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf

typedef struct block {
          size_t size;        // How many bytes beyond this block have been allocated in the heap
          struct block *next; // Where is the next block in your linked list
          int free;           // Is this memory free, i.e., available to give away?
                              // you are the boss!
} block_t;

#define BLOCK_SIZE sizeof(block_t) //for readability

block_t *first = NULL;//this will be the head of our linked list of memory blocks

//my malloc - allocate memory of size s bytes for use, return a void * to this memory. Re-use 'freed' memory if able in a 'first fit' style.
void *mymalloc(size_t s) {
  assert(s >= 0);

  if (first == NULL){ //instantiate first when malloc is first called
    first = (block_t *) sbrk(BLOCK_SIZE);
    first->size = 0;
    first->next = NULL;
    first->free = 0; // 0 means not free, 1 means free
  }

  block_t *toCheck = first;

  int noMemReady = 0;
  while (toCheck != NULL && noMemReady == 0){  // iterate through list and get first matching memory

    if(toCheck->size >= s && toCheck->free == 1){ //we found a matching memory block

      void *start = (toCheck + 1);
      debug_printf("malloc %zu bytes\n", s);
      return start; //give the caller the pointer to the memory
   
    } else {// we didn't find a matching block

      if (toCheck->next == NULL){ // let the program know if there are no free blocks
        noMemReady = 1;
      } else {
        toCheck = toCheck->next;
      }

    }
  }

  //If we get here, we need to create a new block of memory because the list didn't have any available

  block_t *theBlock = sbrk(BLOCK_SIZE + s);//this is the block of meory

  if (theBlock == (void *) -1){//error, out of memory, sbrk returned an issue
    perror("OUT OF MEMORY");
    return (void *) -1;
  } else {      //we've got memory, make the block struct
    theBlock->size = s;
    theBlock->next = NULL;
    theBlock->free = 0;
    toCheck->next = theBlock; //add it to the list

    debug_printf("malloc %zu bytes\n", s);
    return (theBlock + 1); //return a pointer to just after the struct
  }

  return (void *) -1;//make C happy so there's always a return, should never get executed
}

//my calloc - allocate nmemb elements of size s each (in one big chunk) in memory, use mymalloc to get them and then set the memory to 0.
void *mycalloc(size_t nmemb, size_t s) {
  size_t size = nmemb * s;
  assert(size > 0); //check for overflow, if we overflow range size will be < 0

  void *ptr = mymalloc(size);
  memset(ptr, 0, size);//piazza said we can use memset :)

  debug_printf("calloc %zu bytes\n", s);
  return ptr;
}


//my Free - set the provided memory as 'freed' so it can be resued with another call of mymalloc
void myfree(void *ptr) {
  debug_printf("Freed some memory\n");
  block_t *toCheck = first;

  while(toCheck != NULL) { //loop through linked list

    if (toCheck + 1 == ptr) { //if pointers match
      toCheck->free = 1; //free that memory
      return;
    }
    toCheck = toCheck->next;
  }

}



