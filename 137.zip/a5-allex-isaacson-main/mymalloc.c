#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h> 
#include <stdio.h>
#include <string.h>
#include <pthread.h>

// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf

#include "linkedlist.c" // linkedlist helper functions


// Global variables
block_t* list = NULL; // linkedlist representing our memory blocks
pthread_mutex_t mallocmtx = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t listmtx = PTHREAD_MUTEX_INITIALIZER;

/* coalesce for the entire list (to be done after freeing an element in the list) */
void combineAll();

void *mymalloc(size_t s) {
  pthread_mutex_lock(&mallocmtx);
  // lock threads to prevent them finding and trying to allocate to the same block
  // first, search to see if there are any free blocks available to use
  block_t* bl = firstfit_search(s, list);
  // if there is no block, create a new one and add it to the list
  if (bl == NULL) {
    bl = newblock(s);
    // we only add to the list if the request size + block is less than page size, we don't add it to the list
    if (s + BLOCK_SIZE <= PAGE_SIZE) {
      // if the list is null, set it to the first block -- and see if we can split it
      if (list == NULL) {
        pthread_mutex_lock(&listmtx);
        list = bl;
        split(bl,s,NULL);
        pthread_mutex_unlock(&listmtx);
      }
      else {
        // otherwise, append it to the list
        appendblock(bl,list,s);
      } 
    }
  }
  else {
    // if a block was found, try to split it
    split(bl, s, bl->next);
  }
  // if there is still no block, we have an error
  if (bl == NULL) {
    return NULL;
  }  

  // allocate the space
  assert(bl->free == 1);
  void *ptr = allocate(bl);
  assert(ptr != NULL);
  bl->free = 0;
  debug_printf("malloc %zu bytes\n", s);

  pthread_mutex_unlock(&mallocmtx);
 
  // once the block is allocated, unlock threads
  // return the new pointer
  return ptr;
}

void *mycalloc(size_t nmemb, size_t s) {
  
  // no threading issue because mycalloc calls mymalloc which will lock and unlock the threads
  void *ptr = mymalloc(nmemb * s);  

  if (!ptr) {
    return NULL;
  }
  
  // set memory equal to 0
   memset(ptr, 0, nmemb * s);

  debug_printf("calloc %zu bytes\n", s);
  return ptr;
}

void myfree(void *ptr) {
  debug_printf("Freed some memory\n"); 
  pthread_mutex_lock(&mallocmtx);
  // find the header for the given pointer
  block_t* header = (block_t*) (ptr - BLOCK_SIZE);
  
  if (contains(list,header) == 1) {
    // deallocate (free) the space from this header
    deallocate(header);
    // coalesce the entire list
    combineAll();
  }
  else {
    // if not part of the free list, unmap the block
    // i.e. allocated size was more than page size
    int err = munmap(header, header->size + BLOCK_SIZE);
    assert(err == 0);
  }
  pthread_mutex_unlock(&mallocmtx);
}

// coalesce for the entire list
void combineAll() {
  pthread_mutex_lock(&listmtx);
  if (list == NULL) {
    return;
  }

  // COALESCING code:
  // check if the next block in the list is free, and right next to it
  // if it is, combine them together
  // we keep doing this until the next block is null, not free, or not right next to it
  block_t *block = list;
  block_t *next_block = block->next;
  while(next_block != NULL) {
    if (block->free == 1 && next_block->free == 1 && next_block == (block_t*) ((void*)block + block->size + BLOCK_SIZE)) {
      printf("COMBINING %p AND %p\n", block, next_block);
      combine(block);
    }
    else {
      // move forward a block and continue
      block = next_block;
    }
    next_block = block->next;
  }
  pthread_mutex_unlock(&listmtx);
}
