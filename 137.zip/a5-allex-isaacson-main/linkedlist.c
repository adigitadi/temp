#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <sys/mman.h>

#include "linkedlist.h"

#define BLOCK_SIZE sizeof(block_t)
#define PAGE_SIZE 4096

// given a size, create a new memory block of that size
// return a pointer to the new header
block_t *newblock(size_t newsize) {
  // allocate the space for the new block using sbrk
  // the total size of the block will be newsize + BLOCK_SIZE
  size_t totalsize = newsize + BLOCK_SIZE;
  // this will calculate how many pages we need to allocate the space 
  size_t mmapsize = (PAGE_SIZE - totalsize%PAGE_SIZE) + totalsize;
  //int numpages = (int) mmapsize/PAGE_SIZE;
  
  // use mmap to allocate our space
  block_t *newblock = mmap(0, mmapsize, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
  assert(newblock != NULL);
  assert(newblock != MAP_FAILED);

  // set its values
  newblock->size = mmapsize - BLOCK_SIZE;
  newblock->free = 1;
  newblock->next = NULL;

  return newblock;
}

// append the block to the given list
// pass in the amount we want to allocate as newsize, to check for splitting
// invariant: list is not null
void appendblock(block_t *block, block_t *list, size_t newsize) {
  assert(list != NULL);
  assert(block != NULL);

  // traverse to the end of the list
  // to keep the list in sorted order, we traverse until we find the right spot when comparing addresses
  block_t *end = list;
  while (end->next != NULL && block > end->next) {
    end = end->next;
  }
  
  // store the old next 
  block_t* tempb = end->next;
  // update the old end block's next to the new block
  end->next = block;
  // update the new block's next to the old next if it exists (otherwise it's null)
  block->next = tempb;

  // split the block if possible
  split(block, newsize, tempb);
}

// split the block if there is enough empty space
void split(block_t *block, size_t newsize, block_t *next_block) {
  // SPLITTING:
  // if the request is less than pagesize, we consider splitting the block
  // we split the block if we can fit a block and at least one byte into the free space
  if (block->size + BLOCK_SIZE <= PAGE_SIZE) {
    // use the difference between the block size and requested size
    if (block->size - newsize >= BLOCK_SIZE + 1) {
      // create a new block using the rest of the space
      // the pointer to the newblock starts at the end of the requested space (BLOCK_SIZE + newsize bytes ahead)
      block_t *splitblock = (block_t*) ((void*)block + BLOCK_SIZE + newsize);
      // set its values
      size_t splitsize = block->size - BLOCK_SIZE - newsize;
      splitblock->size = splitsize;
      splitblock->free = 1;
      // if a old next exists, we set it to that (otherwise it's null)
      splitblock->next = next_block;
      // change values of old block
      block->size = newsize;
      block->next = splitblock; 
    }
  }
}

// find and return the first free block that has enough space to fit the given demand
block_t *firstfit_search(size_t demand, block_t *list) {
  if (list == NULL) {
    // we have reached the end of the list, so there is no possible block to use
    return NULL;
  }
  
  // check if the current block is free, and has enough space
  if (list->free == 1 && list->size >= demand) {
    // we have enough space, return this header
    return list;
  }
  // otherwise, recursively call for the next element of the list
  return firstfit_search(demand, list->next);
}

// returns 1 if the list contains the given block, 0 otherwise
int contains(block_t *list, block_t *block) {
  block_t *end = list;
  while (end != NULL) {
    if (end == block) {
      return 1;
    }
    end = end->next;
  }
  return 0;
}

// allocate this block and return the pointer to the first accessible cell
void *allocate(block_t *block) {
  // we need to make sure block is pointing to a header, and is free
  assert(block != NULL);
  assert(block->free == 1);
  
  // set the free value to 0
  block->free = 0;
  // return the pointer plus the size of the header
  // this will give the first accessible cell
  return (void*) block + BLOCK_SIZE;
}

// deallocate this block, given the HEADER of the block
void deallocate(block_t *block) {
  // we need to make sure block is pointing to a header, and is not free
  assert(block != NULL);
  assert(block->free == 0);
  
  // set the free value to 1
  block->free = 1;
}

// combine the current block and the block that is next to it
// this is assuming they are right next to each other and are both free
void combine(block_t *block) {
  assert(block != NULL);
  assert(block->next != NULL);
  assert(block->free == 1);
  assert(block->next->free == 1);

  block_t* next_block = block->next;

  // add the next block's total size (including the header's size) to this block's total size
  block->size = block->size + next_block->size + BLOCK_SIZE;

  // set the current block's next to the next block's next
  block->next = next_block->next;

  // goodbye next_block
  memset((void*) next_block, 0, next_block->size + BLOCK_SIZE);
}
