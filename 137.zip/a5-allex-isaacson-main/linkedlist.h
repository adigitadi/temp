#ifndef _LINKEDLIST_H
#define _LINKEDLIST_H

typedef struct block {
  size_t size; // how many bytes beyond this block have been allocated
  struct block *next;  // where is the next block in the linked list
  int free; // 1 if the memory is free, 0 if it isn't
  int debug;
} block_t;

/* given a size, create a new memory block of that size */
block_t *newblock(size_t newsize);

/* append the given block to the given list */
void appendblock(block_t *block, block_t *list, size_t newsize);

/* split the block if there is enough empty space */
void split(block_t *block, size_t newsize, block_t *next_block);

/* find and return the first free block that has enough space to fit the given demand*/
block_t *firstfit_search(size_t demand, block_t *list);

/* returns 1 if the list contains the given element, 0 otherwise */
int contains(block_t *list, block_t *block);

/* allocate this block and return the pointer to the first accessible cell */
void *allocate(block_t *block);

/* deallocate this block, given the header of the block */
void deallocate(block_t *block);

/* combine this block with the next block in the list */
void combine(block_t *block);
#endif /* _LINKEDLIST_H */
