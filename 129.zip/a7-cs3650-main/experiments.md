(This is a template. Delete this line and fill in the sections below)
# Threaded Merge Sort Experiments


## Host 1: [WSL2]

- CPU: Intel(R) Core(TM) i7-10750H CPU @ 2.60GHz
- Cores: 6
- Cache size (if known): idk
- RAM: 16.3 GB
- Storage (if known): 255 GB
- OS: Ubuntu 20.04.5 LTS

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*

Input: Hundred million using the shuf command

### Experiments


#### 1 Threads

Command used to run experiment: `MSORT_THREADS=1 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 20.70 seconds
2. 21.47 seconds
3. 21.14 seconds
4. 20.89 seconds

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 21.69 seconds
2. 21.67 seconds
3. 21.63 seconds
4. 22.35 seconds

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=4 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 14.46 seconds
2. 13.23 seconds
3. 13.56 seconds
4. 13.49 seconds


#### 8 Threads

Command used to run experiment: `MSORT_THREADS=8 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 11.25 seconds
2. 11.46 seconds
3. 10.79 seconds
4. 10.54 seconds


#### 10 Threads

Command used to run experiment: `MSORT_THREADS=8 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 10.34 seconds
2. 10.65 seconds
3. 10.22 seconds
4. 10.64 seconds

## Host 2: [XOA]

- CPU: Intel(R) Xeon(R) CPU E5-2690 v3 @ 2.60GHz
- Cores: 2
- Cache size (if known): idk
- RAM: 3.9 GB
- Storage (if known): 40 GB
- OS: Ubuntu 20.04.1 LTS

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*

Input: Hundred million using the shuf command

### Experiments


#### 1 Threads

Command used to run experiment: `MSORT_THREADS=1 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 22.87 seconds
2. 22.77 seconds
3. 22.85 seconds
4. 22.75 seconds

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 24.67 seconds
2. 24.99 seconds
3. 25.30 seconds
4. 24.86 seconds

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=4 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 17.61 seconds
2. 18.11 seconds
3. 18.56 seconds
4. 18.24 seconds


#### 8 Threads

Command used to run experiment: `MSORT_THREADS=8 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 18.42 seconds
2. 18.26 seconds
3. 18.30 seconds
4. 18.20 seconds


#### 10 Threads

Command used to run experiment: `MSORT_THREADS=8 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 18.86 seconds
2. 18.82 seconds
3. 18.51 seconds
4. 18.85 seconds


## Observations and Conclusions

*Reflect on the experiment results and the optimal number of threads for your concurrent merge sort implementation on different hosts or platforms. Try to explain why the performance stops improving or even starts deteriorating at certain thread counts.*

Our XOA VM experiment indicates an decrease in performance (longer sorting times) with 2 threads as compared to 1 thread, however a significant increase in performance (lower sorting times) with 4 threads. This performance however did not further scale with increasing thread counts. 8 and 10-thread performance is not significantly different. Looking at the system specifications of our VM, this finding makes sense. The VM instance is configured with 2 vCPUs, each of which have 2 threads. So, with 4 threads total, our VM can only make use of 4 threads at most, explaining why there is no benefit in running 8 or 10 threads with the program. 

Our host (WSL2) performance showed consistently lower sorting times as thread count increased. Namely, there was not a "cap" on performance gains after 4 threads. This fact is consistent with the system specifications of the host machine, which contains a 6-core (12 thread) CPU. This means that the system can properly make use of 8 and 10 thread performance, whereas the VM cannot. 

