// Inode manipulation routines.
//
// Feel free to use as inspiration.

// based on cs3650 starter code

#ifndef INODE_H
#define INODE_H

#include "blocks.h"

typedef struct inode {
  int refs;  // reference count
  int mode;  // permission & type
  int size;  // bytes
  int entries; // number of entries in the inode
  int block; // single block pointer (if max file size <= 4K)
  time_t creation_time; // creation time of file
  time_t accessed_time;  // last time the file was accessed
  time_t modified_time;  // last time the file was modified
} inode_t;

void print_inode(inode_t *node);
inode_t *get_inode(int inum);
int alloc_inode();
void free_inode();
int grow_inode(inode_t *node, int size);
int shrink_inode(inode_t *node, int size);
int inode_get_bnum(inode_t *node, int fbnum);

#endif
