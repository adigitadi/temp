#define _GNU_SOURCE
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <assert.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>

#include "directory.h"
#include "inode.h"

// directory_init: void
// initializes our system's directories.
void directory_init() {
    int inum = alloc_inode();
    inode_t *i = get_inode(inum);
    i->mode = 040755;
    i->refs = 0; // not yet made

    char *self = ".";
    char *parent = "..";

    directory_put(i, self, inum);
    directory_put(i, parent, inum);

    i->refs = 0;
    i->entries = 2;
}

// directory_lookup : inode_t *, const char * -> int
// Returns the inum of the given entry in a directory
int directory_lookup(inode_t *dd, const char *name) {

    int inode_bnum = inode_get_bnum(dd, 0);
    dirent_t *subdirs = blocks_get_block(inode_bnum);

    int counter = 0;
    for (counter = 0; counter < dd->entries; ++counter) {
        dirent_t subdir = subdirs[counter];
        if(strcmp(name, subdir.name) == 0) {
            return subdir.inum;
        }
    }

    // we couldn't find a match.
    return -1;
}

// tree_lookup : const char * -> int
// Determines where exactly in a tree a given file/directory is.
int tree_lookup(const char *path) {

    slist_t *path_list = s_explode(path, '/');
    slist_t *current_directory = path_list;

    int currentnode = 0;

    while (current_directory != NULL) {
        currentnode = directory_lookup(get_inode(currentnode),
                                           current_directory->data);

        if(currentnode == -1) {
            // couldn't find the file/dir in the tree :(
            return -1;
        }

        current_directory = current_directory->next;
    }

    return currentnode;
}

// directory_put : inode_t *, const char *, int -> int
// Adds a new directory entry into the given directory.
int directory_put(inode_t *dd, const char *name, int inum) {

    int num_entries = dd->size / sizeof(dirent_t);
    dirent_t *entries = blocks_get_block(dd->block);
    int num_allocated = 0;

    // Creating new entry
    dirent_t newDir;
    strcpy(newDir.name, name);
    newDir.inum = inum;

    // Updating other data
    dd->entries += 1;
    dd->size += sizeof(inum);

    inode_t *subdir = get_inode(inum);
    subdir->refs += 1;

    return 0;

}

// directory_delete : inode_t *, const char * -> int
// Delete a given entry from a directory.
int directory_delete(inode_t *dd, const char *name) {
    dirent_t *entries = blocks_get_block(dd->block);

    int counter = 0;
    for(counter; counter < dd->size / sizeof(dirent_t); ++counter) {
        if(strcmp(entries[counter].name, name) == 0) {
            // found matching entry
            dd->refs = dd->refs - 1;
            dd->entries = dd->entries - 1;
            dd->size = dd->size - sizeof(dirent_t);

            //free_inode(inum);
        }

        counter++;
    }

    // no file found to delete
    return -ENOENT;
}

// directory_list : const char * -> slist_t *
// Lists all the contents of a given directory ("ls").
slist_t *directory_list(const char *path) {

    int inum = tree_lookup(path);
    inode_t *i = get_inode(inum);

    int num_dirs = i->size / sizeof(dirent_t);
    dirent_t *data = blocks_get_block(i->block);
    slist_t *names = NULL;

    int counter = 0;
    for(counter; counter < num_dirs; ++counter) {
        // adds current entry name to the list of names
        names = s_cons(data->name, names);
    }

    return names;
}

// print_directory : inode_t * -> void
// Prints the info of a given directory.
void print_directory(inode_t *dd) {

    int num_dirs = dd->size / sizeof(dirent_t);
    dirent_t *directories = blocks_get_block(dd->block);

    int counter = 0;
    for (counter; counter < num_dirs; ++counter) {
        printf("%s\n", directories[counter].name);
    }
}
