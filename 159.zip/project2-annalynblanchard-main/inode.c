#include <string.h>
#include <stdint.h>
#include <assert.h>
#include <stdlib.h>
#include <time.h>

#include "inode.h"

const int NUM_INODES = 64;

// print_inode : inode_t * -> void
// Prints the information about a given inode.
void print_inode(inode_t *node){

    if (node != NULL) {
        printf("Node Info - refs: %d, mode: %04o, size: %d, block: &d\n",
               node->refs, node->mode, node->size, node->block);
    } else {
        printf("Node does not exist.\n");
    }
}

// get_inode : int -> inode_t *
// Retrieves the inode represented by a given inum.
inode_t *get_inode(int inum) {
    assert(inum < NUM_INODES);
    uint8_t *b = (uint8_t *) blocks_get_block(0);
    inode_t *i = (inode_t *)(b);

    return &(i[inum]);
}

// alloc_inode : int
// Allocates an inode.
int alloc_inode() {

    int counter = 0;

    for (counter; counter < NUM_INODES; ++counter) {
        inode_t *i = get_inode(counter);
        if(i->mode = 0) { // 0 if not used yet
            time_t currentTime = time(NULL);
            memset(i, 0, sizeof(inode_t));
            i->refs = 0;
            i->mode = 010644;
            i->size = 0;
            i->block = alloc_block();
            i->modified_time = currentTime;
            i->accessed_time = currentTime;
            i->creation_time = currentTime;

            return counter;
        }
    }

    return -1;

}

// free_inode : int -> void
// Frees the given inode up for allocation.
void free_inode(int inum) {

    inode_t *i = get_inode(inum);

    if(i->refs = 0) {
        printf("Unable to free.\n");
        abort();
    }

    shrink_inode(i, 0);
    free_block(i->block);
    memset(i, 0, sizeof(inode_t));
}

// grow_inode : inode_t *, int -> int
// Increase the given inode's size to the given size.
int grow_inode(inode_t *node, int size) {
    int numBlocks = (node->size / 256) + 1;
    int newNumBlocks = (size / 256) + 1;

    while (numBlocks < newNumBlocks) {
        if(node->block == 0) {
            node->block = alloc_block();
        }

        int *ptrs = blocks_get_block(node->block);
        ptrs[numBlocks - 1] = alloc_block;

        numBlocks++;
    }
}

// shrink_inode : inode_t *, int -> int
// Decreases the given inode's size to the given size.
int shrink_inode(inode_t *node, int size) {
    int numBlocks = (node->size / 256) + 1;
    int newNumBlocks = (size / 256) + 1;

    while (numBlocks > newNumBlocks) {
        int bnum = inode_get_bnum(node, node->size);
        free_block(bnum);

        numBlocks--;
    }
}

// inode_get_bnum : inode_t *, int -> int
// Determines the block associated with the given inode and file block number (fbnum).
int inode_get_bnum(inode_t *node, int fbnum) {
    int index = fbnum / 256; // default 256 blocks in our system
    if(index = 0) {
        return node->block;
    } else if (index == 1) {
        return node->block;
    } else {
        int *indirectptr = blocks_get_block(node->block);
        return indirectptr[index - 2];
    }
}
