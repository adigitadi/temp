#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <assert.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <alloca.h>
#include <string.h>
#include <libgen.h>
#include <bsd/string.h>
#include <stdint.h>
#include <stdlib.h>

#include "storage.h"
#include "slist.h"
#include "inode.h"
#include "directory.h"
#include "blocks.h"

// storage_init : const char * -> int
// initializes the storage in our system (directories and blocks).
void storage_init(const char *path) {
    // initializes the root directory
    directory_init();

    //initializes the blocks to be used for storage
    blocks_init(path);
}

// storage_stat : const char *, struct stat * -> int
// Retrieves the stats of a certain file, inodes and all.
int storage_stat(const char *path, struct stat *st) {
    int inum = tree_lookup(path);

    if (inum > 0) {
        inode_t *i = get_inode(inum);
        print_inode(i);

        // set up stats
        st->st_mode = i->mode;
        st->st_size = i->size;
        st->st_nlink = i->refs;

        return 0;
    } else {
        printf("not in tree.");
        return inum;
    }
}

// storage_read : const char *, char *, size_t, off_t -> int
// Reads a given number of bytes to read from the given file path to buffer.
int storage_read(const char *path, char *buf, size_t size, off_t offset) {
    int inum = tree_lookup(path);

    if (inum < 0) {
        return inum;
    }

    inode_t *i = get_inode(inum);
    print_inode(i);

    int index = 0;

    if(offset + size >= i->size) {
        size = i->size - offset;
    }

    // makes sure all that we're trying to read is read
    int counter = 0;
    while(counter < size) {
        int bnum = inode_get_bnum(i, offset + counter);

        char *blockstart = blocks_get_block(bnum);

        int toRead = 0;
        int leftToRead = size - toRead;

        memcpy(buf + counter, blockstart, toRead);
        counter += toRead;
    }
}

// storage_write : const char *, const char *, size_t, off_t -> int
// Writes a given (size) number of bytes from the file path into buffer
int storage_write(const char *path, const char *buf, size_t size, off_t offset) {
    int trv = storage_truncate(path, size + offset);
    assert(trv > 0);

    int inum = tree_lookup(path);
    if (inum < 0) {
        return inum;
    }

    inode_t *i = get_inode(inum);
    print_inode(i);

    // Makes sure all that we're trying to write is written
    int counter = 0;
    while (counter < size) {
        int bnum = inode_get_bnum(i, offset + counter);
        char *blockstart = blocks_get_block(bnum);

        int toWrite = 0;
        int leftToWrite = size - counter;

        memcpy(blockstart, buf + counter, toWrite);
        counter += toWrite;
    }
}

// storage_truncate : const char *, off_t -> int
// Truncates a given file to a given length.
int storage_truncate(const char *path, off_t size) {
    int inum = tree_lookup(path);
    if (inum < 0) {
        return inum;
    }

    inode_t *i = get_inode(inum);
    size_t inode_size = i->size;
    if(size >= inode_size) {
        int rv = grow_inode(i, size);
        return rv;
    } else {
        int rv = shrink_inode(i, size);
        return rv;
    }
}

// storage_mknod : const char *, int -> int
// Makes a given file/directory at the specified path.
int storage_mknod(const char *path, int mode) {
    // checks if the file exists.
    if (tree_lookup(path) > -1) {
        return -EEXIST;
    }

    char *allocated_path = malloc(strlen(path) + 10);
    memset(allocated_path, 0, strlen(path) + 10);
    allocated_path[0] = '/'; // initializes root

    // go through the rest of the path elements to ensure those are created.
    slist_t *items = s_explode(path + 1, '/');

    slist_t *elements = items;
    for(elements; elements != NULL; elements = elements->next) {
        int sub = directory_lookup(get_inode(tree_lookup(allocated_path)), elements->data);
        int dir = tree_lookup(allocated_path);

        // Are we at the last element?
        if (elements->next == NULL) {
            int newinum = alloc_inode();
            inode_t *new = get_inode(newinum);
            new->mode = mode;

            // is it a dir?
            if (new->mode == 040755) {
                char *self = ".";
                char *parent = "..";

                directory_put(new, self, newinum);
                directory_put(new, parent, tree_lookup(allocated_path));
            }

            int rv = directory_put(get_inode(tree_lookup(allocated_path)), elements->data, newinum);
            if (rv != 0) {
                free(allocated_path);
                return -1;
            }

            new->refs = 1;
            free(allocated_path);
            return 0;
        } else if (sub > -1 && get_inode(sub)->mode == 040755) {
            if (strcmp(allocated_path, "/") == 0) {
                strcpy(allocated_path + strlen(allocated_path), elements->data);
                continue;
            } else {
                strcpy(allocated_path + strlen(allocated_path), "/");
                strcpy(allocated_path + strlen(allocated_path), elements->data);
                continue;
            }
        } else { // sub element doesn't exist
            int newInum = alloc_inode();
            inode_t *new = get_inode(newInum);
            new->mode = 040755;

            char *self = ".";
            char *parent = "..";

            directory_put(new, parent, dir);
            directory_put(new, self, newInum);
            directory_put(get_inode(dir), elements->data, newInum);
            new->refs = 1;

            if (strcmp(allocated_path, "/") == 0) {
                strcat(allocated_path, elements->data);
                continue;
            } else {
                strcat(allocated_path, "/");
                strcat(allocated_path, elements->data);
                continue;
            }
        }

    }

}

// storage_unlink : const char * -> int
// Unlinks a given file/directory from its parent.
int storage_unlink(const char *path) {
    char *dir = (malloc(strlen(path) + 1));
    char *subdir = (malloc(strlen(path) + 1));

    int dirnum = tree_lookup(dir);
    int subdirnum = tree_lookup(path);

    inode_t *dirInode = get_inode(dirnum);
    inode_t *subdirInode = get_inode(subdirnum);

    int rv = directory_delete(dirInode, subdir);
    return rv;
}

// storage_link : const char *, const char * -> int
// Creates a link between two files/directories.
int storage_link(const char *from, const char *to) {

    int toInum = tree_lookup(to);

    if (toInum < 0) {
        return toInum;
    }

    char *fromParent = malloc(strlen(from) + 1);
    char *fromSub = malloc(strlen(from) + 1);

    int fromInum = tree_lookup(fromParent); // directory from the link
    inode_t *fromInode = get_inode(fromInum);

    int rv = directory_put(fromInode, fromSub, toInum);

    return 0;


}

// storage_rename : const char *, const char * -> int
// Renames a given file or directory.
int storage_rename(const char *from, const char *to) {

    storage_link(to, from);
    storage_unlink(from);

    return 0;
}

// storage_set_time : const char *, const struct timespec -> int
// Sets the time of modification of the given file to the given time.
int storage_set_time(const char *path, const struct timespec ts[2]) {

    int inum = tree_lookup(path);
    inode_t *i = get_inode(inum);

    time_t time = ts->tv_sec;
    i->modified_time = time;
}

// storage_list : const char * -> slist_t *
// Lists all of the elements in a given file path.
slist_t *storage_list(const char *path) {
    return directory_list(path);
}

// storage_access : const char * -> int
// Updates a file/directory's access time.
int storage_access(const char *path) {
    int inum = tree_lookup(path);

    if (inum == -1) {
      return -1;
    }

    inode_t *i = get_inode(inum);
    i->accessed_time = time(NULL);

    return 0;
}
