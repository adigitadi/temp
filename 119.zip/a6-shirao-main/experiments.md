(This is a template. Delete this line and fill in the sections below)
# Threaded Merge Sort Experiments


## Host 1: [Laptop-WSL]

- CPU: i5-1135G7
- Cores:4
- Cache size (if known):8192KB
- RAM:16GB
- Storage (if known):512GB
- OS:Linux

### Input data

1000000 data

### Experiments

#### 1 Threads

Command used to run experiment: `make diff-1000000`

Sorting portion timings:

1. 0.177 seconds
2. 0.183 seconds
3. 0.177 seconds
4. 0.185 seconds

#### 5 Threads

Command used to run experiment: ``

Sorting portion timings:

1. 0.061 seconds
2. 0.067 seconds
3. 0.058 seconds
4. 0.059 seconds

#### 10 Threads

Command used to run experiment: ``

Sorting portion timings:

1. 0.063 seconds
2. 0.068 seconds
3. 0.062 seconds
4. 0.065 seconds

## Host 2: [PC-WSL]

- CPU: i7-12700
- Cores:12
- Cache size (if known):25600KB
- RAM:32GB
- Storage (if known):2TB
- OS:Linux

### Input data

1000000 data

### Experiments

#### 1 Threads

Command used to run experiment: `make diff-1000000`

Sorting portion timings:

1. 0.120 seconds
2. 0.120 seconds
3. 0.119 seconds
4. 0.125 seconds

#### 5 Threads

Command used to run experiment: ``

Sorting portion timings:

1. 0.038 seconds
2. 0.036 seconds
3. 0.040 seconds
4. 0.041 seconds

#### 10 Threads

Command used to run experiment: ``

Sorting portion timings:

1. 0.036 seconds
2. 0.036 seconds
3. 0.034 seconds
4. 0.034 seconds

## Observations and Conclusions

*Reflect on the experiment results and the optimal number of threads for your concurrent merge sort implementation on different hosts or platforms. Try to explain why the performance stops improving or even starts deteriorating at certain thread counts.*

After the number of threads is larger than the actual CPU cores, more threads won't be executed in parallel.
The optimal would be between 8 to 10 threads.
