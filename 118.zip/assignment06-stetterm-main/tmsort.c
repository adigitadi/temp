/**
 * Threaded Merge Sort
 *
 * Modify this file to implement your multi-threaded version of merge sort.
 */

#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

#define tty_printf(...) (isatty(1) && isatty(0) ? printf(__VA_ARGS__) : 0)

#ifndef SHUSH
#define log(...) (fprintf(stderr, __VA_ARGS__))
#else
#define log(...)
#endif

/** The number of threads to be used for sorting. Default: 1 */
int thread_count = 1;

/**
 * Compute the delta between the given timevals in seconds.
 */
double time_in_secs(const struct timeval *begin, const struct timeval *end) {
  long s = end->tv_sec - begin->tv_sec;
  long ms = end->tv_usec - begin->tv_usec;
  return s + ms * 1e-6;
}

/**
 * Print the given array of longs, an element per line.
 */
void print_long_array(const long *array, int count) {
  for (int i = 0; i < count; ++i) {
    printf("%ld\n", array[i]);
  }
}

/**
 * Merge two slices of nums into the corresponding portion of target.
 */
void merge(long nums[], int from, int mid, int to, long target[]) {
  int left = from;
  int right = mid;

  int i = from;
  for (; i < to && left < mid && right < to; i++) {
    if (nums[left] <= nums[right]) {
      target[i] = nums[left];
      left++;
    }
    else {
      target[i] = nums[right];
      right++;
    }
  }
  if (left < mid) {
    memmove(&target[i], &nums[left], (mid - left) * sizeof(long));
  }
  else if (right < to) {
    memmove(&target[i], &nums[right], (to - right) * sizeof(long));
  }

}


/**
 * Sort the given slice of nums into target.
 *
 * Warning: nums gets overwritten.
 */
void merge_sort_aux(long nums[], int from, int to, long target[]) {
  if (to - from <= 1) {
    return;
  }

  int mid = (from + to) / 2;
  merge_sort_aux(target, from, mid, nums);
  merge_sort_aux(target, mid, to, nums);
  merge(nums, from, mid, to, target);
}

/**
 * Struct passed to the pthread target
 * used to define the bounds of the
 * list being sorted by a particular thread.
 */
typedef struct slice {
  long *data;
  long *target;
  int length;
} slice_t;

/**
 * The target for each thread to complete
 * during the first phase of the merge sort.
 * The array is split into equal portions
 * for each thread, and merge sort is performed
 * on each of them using a slice struct passed
 * as a void pointer to this function.
 *
 * @param s slice struct containing data pointer,
 * 	  target array pointer, and the length
 * @return NULL
 */
void *merge_target(void *s) {

  // An array with only one element
  // is already sorted.
  slice_t *section = (slice_t *)s;
  if (section->length <= 1) {
    return NULL;
  }

  // Split the array in half and merge
  // sort each half. Finally, merge the
  // two halves into the target array.
  merge_sort_aux(section->data, 0, section->length, section->target);

  return NULL;
}

/**
 * Struct used during the final
 * merges of the array one
 * the slices have been individually
 * sorted.
 */
typedef struct merge_slice {
  long *data;
  long *target;
  int start;
  int mid;
  int end;
} merge_slice_t;

/**
 * Target for the threads to perform the
 * final merges of the list into the
 * target array.
 *
 * @param s slice struct containing pointer
 * 	  to start of slice and length of slice.
 * @return NULL
 */
void *final_merge_target(void *s) {
  merge_slice_t *mslice = (merge_slice_t *)s;
  merge(mslice->data, mslice->start, mslice->mid, mslice->end, mslice->target);
  return NULL;
}

int min(int a, int b) { return a < b ? a : b; }

/**
 * After the array was split and sorted,
 * the sorted slices must be merged together
 * into the target array.
 *
 * @param nums the original array of numbers
 * @param count the size of the array
 * @param target the array to store the sorted version of nums
 */
void final_merges(long nums[], int count, long target[]) {

  // Create enough thread and slice structs to
  // merge the slices together sorted.
  pthread_t threads[thread_count/2];
  merge_slice_t mslices[thread_count/2];
  int num_slices = thread_count;
  int start = 0;
  int mid, end;
  int num_iter = 0;
  int block_size = count / thread_count;
  memmove(nums, target, count * sizeof(long));

  // Reduce the number of slices in half
  // each iteration.
  while (num_slices > 1) {

    // Generate a new thread for every two
    // slices in the array and merge two
    // slices together on the thread.
    int cur_num_blocks = num_slices;
    int i;
    for (i = 0; i < cur_num_blocks/2; i++) {

      // Each pass through the array switches back
      // and forth between the input array and the target
      // array to sort the array without needing
      // to memmove every pass.
      mslices[i].data = num_iter % 2 == 0 ? target : nums;
      mslices[i].target = num_iter % 2 == 0 ? nums : target;
      
      // Mid is the index that separate the first and
      // second block that are being merged in this
      // iteration of the for loop. End is the end
      // of the second block.
      mid = i * 2 * block_size + block_size;
      end = min((i + 1) * 2 * block_size, count);

      // This information is passed to a struct so that
      // the thread can access the necessary data for
      // sorting a section of the array.
      mslices[i].start = start;
      mslices[i].mid = mid;
      mslices[i].end = end;

      // If the last block is being merged, extend
      // the block size to the end of the array.
      if (i == (cur_num_blocks/2)-1 && cur_num_blocks % 2 == 0) {
        mslices[i].end = count;
	end = count;
      }

      // Spawn the thread for this merge.
      if (pthread_create(&threads[i], NULL, &final_merge_target, &mslices[i]) != 0) {
        log("Thread %d failed to start", i);
	exit(1);
      }
      num_slices -= 1;
      start = end;
    }

    // This is a memmove of a part of the array, if
    // the last pass did not merge blocks all the
    // way to the end of the array.
    if (end != count) {
      if (num_iter % 2 == 0) {
        memmove(&nums[end], &target[end], (count - end) * sizeof(long));
      } else {
        memmove(&target[end], &nums[end], (count - end) * sizeof(long));
      }
    }

    // Join on all currently executing threads.
    for (int i = 0; i < cur_num_blocks/2; i++) {
      pthread_join(threads[i], NULL);
    }
    block_size *= 2;
    start = 0;
    num_iter++; 
  }

  // If the loop ended on the nums array
  // being merged, copy nums into the
  // final sorted array in target.
  if (num_iter % 2 == 1) {
    memmove(target, nums, count * sizeof(long));
  }
}

/**
 * Function called to split the list into
 * equal portions and merge sort each
 * portion each on a different thread.
 *
 * @param nums the original array of numbers
 * @param count the size of the array
 * @param target the array to save the sorted array into
 */
void start_threads(long nums[], int count, long target[]) {

  // Create a list of thread structs and
  // slice structs to sort the list
  // in parallel.
  pthread_t threads[thread_count];
  slice_t slices[thread_count];
  int start = 0;
  int end;
  int block_size = count / thread_count;
  for (int i = 0; i < thread_count; i++) {

    // Give each thread an equal portion of
    // the array, except the final thread
    // that gets the leftover elements.
    if (i == thread_count - 1) end = count;
    else end = (i + 1) * block_size;
    slices[i].data = &nums[start];
    slices[i].target = &target[start];
    slices[i].length = end - start;
    if (pthread_create(&threads[i], NULL, &merge_target, &slices[i]) != 0) {
      log("Thread %d failed to start", i);
      exit(1);
    }
    start = end;
  }

  // Join on all the spawned threads.
  for (int i = 0; i < thread_count; i++) {
    pthread_join(threads[i], NULL);
  }
}

/**
 * Sort the given array and return the sorted version.
 *
 * The result is malloc'd so it is the caller's responsibility to free it.
 *
 * Warning: The source array gets overwritten.
 */
long *merge_sort(long nums[], int count) {
  long *result = calloc(count, sizeof(long));
  assert(result != NULL);

  memmove(result, nums, count * sizeof(long));

  start_threads(nums, count, result);
  final_merges(nums, count, result);

  return result;
}

/**
 * Based on command line arguments, allocate and populate an input and a
 * helper array.
 *
 * Returns the number of elements in the array.
 */
int allocate_load_array(int argc, char **argv, long **array) {
  assert(argc > 1);
  int count = atoi(argv[1]);

  *array = calloc(count, sizeof(long));
  assert(*array != NULL);

  long element;
  tty_printf("Enter %d elements, separated by whitespace\n", count);
  int i = 0;
  while (i < count && scanf("%ld", &element) != EOF)  {
    (*array)[i++] = element;
  }

  return count;
}

int is_sorted(long target[], int count) {
  for (int i = 0; i < count - 1; i++) {
    if (target[i] > target[i+1]) return 0;
  }
  return 1;
}

int main(int argc, char **argv) {
  if (argc != 2) {
    fprintf(stderr, "Usage: %s <n>\n", argv[0]);
    return 1;
  }

  struct timeval begin, end;

  // get the number of threads from the environment variable SORT_THREADS
  if (getenv("MSORT_THREADS") != NULL)
    thread_count = atoi(getenv("MSORT_THREADS"));

  log("Running with %d thread(s). Reading input.\n", thread_count);

  // Read the input
  gettimeofday(&begin, 0);
  long *array = NULL;
  int count = allocate_load_array(argc, argv, &array);
  gettimeofday(&end, 0);

  log("Array read in %f seconds, beginning sort.\n",
      time_in_secs(&begin, &end));

  // Sort the array
  gettimeofday(&begin, 0);
  long *result = merge_sort(array, count);
  gettimeofday(&end, 0);

  log("Sorting completed in %f seconds.\n", time_in_secs(&begin, &end));

  // Print the result
  gettimeofday(&begin, 0);
  print_long_array(result, count);
  gettimeofday(&end, 0);

  log("Array printed in %f seconds.\n", time_in_secs(&begin, &end));

  log("Sorted: %s\n", is_sorted(result, count) ? "true" : "false");

  free(array);
  free(result);

  return 0;
}
