# Threaded Merge Sort Experiments


## Host 1: Home Linux Machine

- CPU: Intel i5 7600k @ 4.200GHz
- Cores: 4 cores / 8 threads
- Cache size (if known): 6MB
- RAM: 16GB DDR4 @ 3000MHz
- Storage (if known): SanDisk SSD Plus 240GB
- OS: Ubuntu 22.04.1 LTS x86_64

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*

My data set is a file called large_data.txt that contains 5,000,000 numbers with one on each line. This was generated using the command: `shuf-i1-5000000 > large_data.txt`.
Runinng the msort program on the data and redirecting the output to /dev/null so the program does not need to print 5,000,000 numbers to standard out, it achieves the following numbers:

240 processes running before starting.

1. 0.823024 seconds
2. 0.828746 seconds
3. 0.821466 seconds
4. 0.803007 seconds
Average time: 0.81906075 seconds or ~819ms

### Experiments

*Replace X, Y, Z with the number of threads used in each experiment set.*

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 5000000 < large_data.txt > /dev/null`

Number of processes: 244

Sorting portion timings:

1. 0.452405 seconds
2. 0.468385 seconds
3. 0.456614 seconds
4. 0.449076 seconds
Average time: 0.45662 seconds or ~457ms

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=4 ./tmsort 5000000 < large_data.txt > /dev/null`

Number of processes: 236

Sorting portion timings:

1. 0.265924 seconds
2. 0.264825 seconds
3. 0.264096 seconds
4. 0.264786 seconds
Average time: 0.26490775 seconds or ~265ms

#### 6 Threads

Command used to run experiment: `MSORT_THREADS=6 ./tmsort 5000000 < large_data.txt > /dev/null`

Number of processes: 244

Sorting portion timings:

1. 0.280335 seconds
2. 0.282779 seconds
3. 0.279419 seconds
4. 0.279577 seconds
Average time: 0.2805275 seconds or ~281ms

*repeat sections as needed*

## Host 2: Khoury Linux Server

- CPU: 2 x Intel Xeon Silver 4214R @ 2.40GHz
- Cores: 12 cores per cpu / 24 threads per cpu (24 cores / 48 threads total)
- Cache size (if known): 16.5MB
- RAM: 376GB @ 2400MHz
- Storage (if known): unknown
- OS: CentOS Linux 7 x86_64

### Input data

*Briefly describe how large your data set is and how you created it. Also include how long `msort` took to sort it.*

The input file was generated using the same command as on my own Linux machine (`shuf -i1-5000000 > large_data.txt`).
The Khoury Linux server achieved the following results on non-threaded msort:

2970 processes running before starting.

1. 1.157673 seconds
2. 1.096217 seconds
3. 1.056391 seconds
4. 1.147538 seconds
Average time: 1.11445475 seconds or 1,114ms

### Experiments

*Replace X, Y, Z with the number of threads used in each experiment set.*

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 5000000 < large_data.txt > /dev/null`

Number of processes: 2964

Sorting portion timings:

1. 0.667475 seconds
2. 0.810676 seconds
3. 0.672579 seconds
4. 0.683457 seconds
Average time: 0.70854675 seconds or ~709ms

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=4 ./tmsort 5000000 < large_data.txt > /dev/null`

Number of processes: 2967

Sorting portion timings:

1. 0.504748 seconds
2. 0.489258 seconds
3. 0.412904 seconds
4. 0.442204 seconds
Average time: 0.4622785 seconds or ~462ms

#### 8 Threads

Command used to run experiment: `MSORT_THREADS=8 ./tmsort 5000000 < large_data.txt > /dev/null`

Number of processes: 2963

Sorting portion timings:

1. 0.33525  seconds
2. 0.337588 seconds
3. 0.345626 seconds
4. 0.339953 seconds
Average time: 0.33960425 seconds or ~340ms

#### 16 Threads

Command used to run experiment: `MSORT_THREADS=16 ./tmsort 5000000 < large_data.txt > /dev/null`

Number of processes: 2959

Sorting portion timings:

1. 0.296    seconds
2. 0.246904 seconds
3. 0.25145  seconds
4. 0.246075 seconds
Average time: 0.26010725 seconds or ~260ms

## Observations and Conclusions

*Reflect on the experiment results and the optimal number of threads for your concurrent merge sort implementation on different hosts or platforms. Try to explain why the performance stops improving or even starts deteriorating at certain thread counts.*

In general, the threaded merge sort performs better that the standard, non-threaded merge sort. However, it is clear at a certain point that the threaded version gets diminishing returns as the thread count is continually increased. On my own computer, the performance seemed to peak around 4-6 threads. This makes sense because my CPU has 4 cores with 8 threads. In fact, the performance for 6 threads was slightly worse, which may be explained by the extra amount of time it takes to start up all the necessary threads and join on them.

There were very similar results on the Khoury Linux machine, however this machine seemed to continually improve with added threads, albeit slightly. The performance gained from 8 threads to 16 threads is about half the performance gain between 4 and 8 threads. It makes sense that the performance gains diminish with additional threads for the same reason that my computer's performance did not gain performance exponentially. However, the Khoury Linux machine has a higher core and thread count available. Therefore, the computer was able to keep getting benefit from additional multithreading. Running with 32 threads achieved around the same performance as 16 threads, meaning the peak for the Khoury Linux machine seems to be around 16-24 threads. Given that the machine has 12 cores and 24 threads per CPU with two CPUs, this threshold conforms to expectations.
