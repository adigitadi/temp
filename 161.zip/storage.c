#define STORAGE_C

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <sys/stat.h>

#include "inode.h"
#include "bitmap.h"
#include "blocks.h"
#include "storage.h"

#define INODE_COUNT 128

// struct Superblock
// {
//   uint32_t s_inodes_count;      // 128;
//   uint32_t s_blocks_count;      // 32;
//   uint32_t s_free_blocks_count; // 989;
//   uint32_t s_free_inodes_count; // 128;
//   uint32_t s_first_data_block;  // 35;
//   uint32_t s_log_block_size;    // 1024; 
// } Superblock_default = {128, 32, 989, 128, 35, 1024};

void storage_init(const char *path) {
  int fd;
  inode_t *inode;
  // struct Superblock superblock = Superblock_default;

  if (access(path, F_OK) == 0) {
      // file exists
      printf("Open disk image: %s\n", path);
      // Open the disk image file
      blocks_init(path);
  } else {
      // file doesn't exist
      printf("Create the new disk image: %s\n", path);
      // Create the new disk image file
      blocks_init(path);

      // block 0 stores the block bitmap and the inode bitmap
      void *bbm = get_blocks_bitmap();
      // Reserve the block 1 to 8 as inode block
      for (int i = 1; i < 9; i++)
        bitmap_put(bbm, i, 1);

      // inset the File hello.txt
      // allocate a new inode 
      int inode_num = alloc_inode();

      // get the allocated inode
      inode = get_inode(inode_num);
      
      // allocate a new block 
      int block_num = alloc_block();

      // set the inode info with the data block number use by the file
      inode->refs = (uint8_t)inode_num;
      inode->mode = 0100644;
      inode->uid = getuid();
      inode->size = 6;
      inode->time = time(NULL);
      inode->ctime = time(NULL);
      inode->mtime = time(NULL);
      inode->dtime = 0;
      inode->gid = getgid();
      inode->block = (uint8_t)block_num;
      bzero(inode->path, sizeof(inode->path));
      strcpy(inode->path, "/hello.txt");
     
      // Write data to the block
      void *newblock = blocks_get_block(block_num);
      strcpy(newblock, "Hello World!");

      // print_inode(inode);

      // to be move to void nufs_destroy(void *private_data) function
      // blocks_free();
  }  
}

int storage_stat(const char *path, struct stat *st) {
  inode_t *inode;
  void *ibm = get_inode_bitmap();

  for (int ii = 0; ii < INODE_COUNT; ii++) {
    if (bitmap_get(ibm, ii)) {
      inode = blocks_get_block(1 + ii);
      if (strcmp(path, (const char*)&inode->path) == 0) {
        st->st_ino = inode->refs;
        st->st_mode = inode->mode;
        st->st_nlink = 1;
        st->st_uid = inode->uid;
        st->st_gid = inode->gid;
        st->st_size = inode->size;
        st->st_atime = inode->time;
        st->st_mtime = inode->mtime;
        st->st_ctime = inode->ctime;
        return 0;
      }
    }
  }
  return -1;
}

int storage_read(const char *path, char *buf, size_t size, off_t offset) {
  inode_t *inode;
  void *ibm = get_inode_bitmap();

  for (int ii = 0; ii < INODE_COUNT; ii++) {
    if (bitmap_get(ibm, ii)) {
      inode = get_inode(ii);
      if (strcmp(path, inode->path) == 0) {
        if (size == 0)
          return 0;

        if (size > inode->size)
          size = inode->size;

        if ((size - offset) <= 0)
          return 0;

        if (inode->size <= BLOCK_SIZE) {
          memcpy(buf, blocks_get_block(inode->block) + offset, size);
          return size;
        }
        else {
          uint8_t *blocks = blocks_get_block(inode->block);
          uint8_t *block;

          for (int i = 0; i < size / BLOCK_SIZE; i++) {
            block = blocks_get_block(*blocks);
            memcpy(buf, block, BLOCK_SIZE);
            blocks++;
            buf += BLOCK_SIZE;
          }
          if (size % BLOCK_SIZE) {
            memcpy(buf, block, size % BLOCK_SIZE);
          }
          return size;
        }
      }
    }
  }
  return -1;
}

int storage_mknod(const char *path, int mode) {
    inode_t *inode;
    int inode_bnum;
    int block_num ;

    // Creat the new File
    // allocate a new inode 
    inode_bnum = alloc_inode();

    // get the allocated inode
    inode = get_inode(inode_bnum);
    
    // allocate a new block 
    block_num = alloc_block();

    // set the inode info with the data block number use by the file
    inode->refs = (uint8_t)inode_bnum;
    inode->mode = (uint16_t)mode;
    inode->uid = getuid();
    inode->size = 0;
    inode->time = 0;
    inode->ctime = time(NULL);
    inode->mtime = 0;
    inode->dtime = 0;
    inode->gid = getgid();
    inode->block = (uint8_t)block_num;
    bzero(inode->path, sizeof(inode->path));
    strncpy(inode->path, path, 223);
    // storage_list("/");
    return 0;
}

int storage_set_time(const char *path, const struct timespec ts[2]) {
  inode_t *inode;
  void *ibm = get_inode_bitmap();

  for (int ii = 0; ii < INODE_COUNT; ii++) {
    if (bitmap_get(ibm, ii)) {
      inode = get_inode(ii);
      if (strcmp(path, inode->path) == 0) {
        // Write the new time stamp 
        inode->time = ts[0].tv_sec;
        inode->mtime = ts[1].tv_sec;
        return 0;
      }
    }
  }
  return -1;
}

slist_t *storage_list(const char *path) {
  inode_t *inode;
  slist_t *filelist = NULL;
  size_t len = strlen(path);
  void *ibm = get_inode_bitmap();
  int i = 0;
  char fullPath[224];

  strcpy(fullPath, path);
  if (strlen(path) > 1) {
    strcat(fullPath, "/");
    len++;
  }

  for (int ii = 0; ii < INODE_COUNT; ii++) {
    if (bitmap_get(ibm, ii)) {
      inode = get_inode(ii);
      if ( (strncmp (fullPath, inode->path, len) == 0)
          && (strchr((char*)(inode->path + len), '/') == NULL)) {
        // add File to list
        filelist = s_cons((char*)(inode->path + len), filelist); 
      }
    }
  }
  return filelist;
}

int storage_write(const char *path, const char *buf, size_t size, off_t offset) {
  inode_t *inode;
  void *ibm = get_inode_bitmap();

  for (int ii = 0; ii < INODE_COUNT; ii++) {
    if (bitmap_get(ibm, ii)) {
      inode = get_inode(ii);
      if (strcmp(path, inode->path) == 0) {
        if (size == 0)
          return 0;

        if ((inode->size - offset + size) <= BLOCK_SIZE) {
          memcpy(blocks_get_block(inode->block) + offset, buf, size);
          inode->size -= offset;
          inode->size += size;
          return size;
        }
        else {
          if (inode->size <= BLOCK_SIZE) {
            // How many data blocks needed?
            int total_dblock = bytes_to_blocks(inode->size - offset + size);
            uint8_t *dataBlock;
            uint8_t dataBlockArray[total_dblock];
            
            // Save the old inode data block in the data block array
            dataBlockArray[0] = inode->block;
            // allocate the Data Block Table and inode->block refer to it
            inode->block = alloc_block();

            // Allocate the additional data block
            for (int j = 1; j < total_dblock - 1; j++)
              dataBlockArray[j] = alloc_block();

            // Fetch the Data block Table
            uint8_t *blockTable = blocks_get_block(inode->block);
            memcpy(blockTable, dataBlockArray, sizeof(dataBlockArray));

            // Fill the data block with the datas
            for (int j = 0; j < total_dblock; j++) {
              if (offset / BLOCK_SIZE == j)
                memcpy(blocks_get_block(dataBlockArray[j]), buf + BLOCK_SIZE * j + (offset % BLOCK_SIZE) , BLOCK_SIZE - (offset % BLOCK_SIZE));
              else
                memcpy(blocks_get_block(dataBlockArray[j]), buf + BLOCK_SIZE * j, BLOCK_SIZE);
            }

            // Update inode file size info
            inode->size = size;
            return size;
          }
          else {
            // How many data blocks needed?
            int total_dblock = bytes_to_blocks(size - inode->size - offset);
            int old_total_dblock = bytes_to_blocks(inode->size);
            uint8_t *dataBlock;
            uint8_t dataBlockArray[total_dblock];
            
            // Allocate the additional data block
            uint8_t *blockTable = blocks_get_block(inode->block);
            for (int j = old_total_dblock; j < old_total_dblock + total_dblock; j++)
              blockTable[j] = alloc_block();

            // Fill the data block with the datas
            for (int j = 0; j < total_dblock; j++) {
                memcpy(blocks_get_block(dataBlockArray[j+old_total_dblock]), buf + BLOCK_SIZE * j, BLOCK_SIZE);
            }

            // Update inode file size info
            inode->size -= offset;
            inode->size += size;
            return size;
          }
        }
      }
    }
  }
  return -1;
}

int storage_unlink(const char *path) {
  inode_t *inode;
  void *ibm = get_inode_bitmap();

  bitmap_print(ibm, INODE_SIZE);

  for (int ii = 0; ii < INODE_COUNT; ii++) {
    if (bitmap_get(ibm, ii)) {
      inode = get_inode(ii);
      if (strcmp(path, inode->path) == 0) {
        // printf("inode.refs: %d\n", inode->refs);
        print_inode(inode);
        free_inode(inode->refs);
        if (inode->size <= BLOCK_SIZE) {
          free_block(inode->block);
          bitmap_print(ibm, INODE_SIZE);
          return 0;
        }
        else {
          uint8_t *blocks = blocks_get_block(inode->block);
          while(*blocks) {
            free_block(*blocks);
            blocks++;
          }
          free_block(inode->block);
          return 0;
        }
      }
    }
  }
  return -1;
}