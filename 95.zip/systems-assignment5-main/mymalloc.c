#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h> 
#include <stdio.h>
#include <unistd.h>

// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf
#define BLOCK_SIZE sizeof(block_t)

typedef struct block {
  size_t size;        // How many bytes beyond this block have been allocated in the heap
  struct block *next; // Where is the next block in your linked list
  int free;           // Is this memory free, i.e., available to give away?
  int debug;          // (optional) Perhaps you can embed other information--remember,
                      // you are the boss!
} block_t;

static block_t *allocated_list = NULL;

// Allocate a new block capable of holding s bytes
block_t *allocate_new(size_t s) {
  void *res = sbrk(0);
  void *valid = sbrk(BLOCK_SIZE + s);
  if (valid == (void *) -1) {
    return NULL;
  }
  // set up block
  block_t *block = (block_t *) res;
  block->size = s;
  block->next = NULL;
  block->free = 0;
  block->debug = 0;
  return block;
}

// Find the first free memory block that fits, or allocate a new block
block_t *get_next_free(size_t s) {
  block_t *prev = NULL;
  block_t *current = allocated_list;
  while (current != NULL && (!current->free || current->size < s)) {
    prev = current;
    current = current->next;
  }
  if (current == NULL) {
    // didn't find one, make new block
    block_t *new_block = allocate_new(s);
    // check if sbrk failed
    if (new_block == NULL) {
      return NULL;
    }
    // check block chain
    if (prev != NULL) {
      // insert block in list
      prev->next = new_block;
    } else {
      // list was empty
      allocated_list = new_block;
    }
    return new_block;
  } else {
    // found free block of correct size, so set free false
    current->free = 0;
    return current;
  }
}

// allocate memory of size s, our way
void *mymalloc(size_t s) {
  // get block
  block_t *res = get_next_free(s);
  // check fail
  if (res == NULL) {
    return NULL;
  }
  // set debug
  res->debug = 1;
  // move past block
  char *p = ((char *) res) + BLOCK_SIZE;

  debug_printf("malloc %zu bytes\n", s);

  return (void *) p;
}

// allocate memory of size s * nmemb, all zeroed, our way
void *mycalloc(size_t nmemb, size_t s) {
  // get block
  block_t *res = get_next_free(s * nmemb);
  // check fail
  if (res == NULL) {
    return NULL;
  }
  // set debug
  res->debug = 2;
  // move past block
  char *p = ((char *) res) + BLOCK_SIZE;
  // zero rest of mem
  for (int i = 0; i < nmemb * s; i++) {
    p[i] = 0;
  }
  
  debug_printf("calloc %zu bytes\n", s);

  return (void *) p;
}

// free the given memory, our way
void myfree(void *ptr) {
  debug_printf("Freed some memory\n");

  // step back to start of block
  block_t *res = (block_t *) (ptr - BLOCK_SIZE);
  // set free
  res->free = 1;
  // reset debug
  res->debug = 0;
}
