# Threaded Merge Sort Experiments


## Host 1: [Aaron's Personal Windows Laptop]

- CPU: Intel(R) Core(TM) i7-9750H CPU @ 2.60GHz   2.59 GHz
- Cores: 6
- Cache size (if known):
- RAM: 16.0 GB (15.7 GB usable)
- Storage (if known): 1TB approx 100gb free
- OS: Windows 11 Home (with Linux Subsystem Ubuntu 20.04 LTS through WSL2)

### Input data

Out dataset is a text of numbers from 1 to 100000000. msort takes about 21.39 seconds to sort it on this machine.

### Number of Processes running before experiment
7 processes are running on this machine before starting.

### Experiments

*Replace X, Y, Z with the number of threads used in each experiment set.*

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=4 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

7.714671 seconds.
12.406261 seconds.
6.931677 seconds.
7.274756 seconds.

#### 6 Threads

Command used to run experiment: `MSORT_THREADS=6 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

7.020750 seconds.
7.247008 seconds.
7.131957 seconds.
7.423898 seconds.

#### 12 Threads

Command used to run experiment: `MSORT_THREADS=12 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

5.236088 seconds.
7.115121 seconds.
5.080749 seconds.
4.964789 seconds.

#### 24 Threads

Command used to run experiment: `MSORT_THREADS=24 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

5.182207 seconds.
5.126189 seconds.
5.268935 seconds.
5.228510 seconds.

#### 100 Threads

Command used to run experiment: `MSORT_THREADS=100 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

4.456909 seconds.
4.889044 seconds.
4.994609 seconds.
5.893119 seconds.

## Host 2: [XOA VM]

- CPU: Intel(R) Xeon(R) CPU E5-2690 v3
- Cores: 2
- Cache size (if known): 30mb
- RAM: 4gb
- Storage (if known): 40gb
- OS: Ubuntu 22.04.1 LTS

### Input data

Out dataset is a text of numbers from 1 to 100000000. msort takes about 22.9 seconds to sort it on this machine.

### Number of Processes running before experiment
113 processes are running on this machine before starting.

### Experiments

*Replace X, Y, Z with the number of threads used in each experiment set.*

#### 1 Thread

Command used to run experiment: `MSORT_THREADS=1 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 23.374538 seconds.
2. 23.352708 seconds.
3. 23.386960 seconds.
4. 23.321949 seconds.

#### 2 Threads

Command used to run experiment: `MSORT_THREADS=2 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 12.341457 seconds.
2. 12.315400 seconds.
3. 12.337230 seconds.
4. 12.327010 seconds.

#### 4 Threads

Command used to run experiment: `MSORT_THREADS=4 ./tmsort 100000000 < hundred-million.txt > /dev/null`

Sorting portion timings:

1. 14.973343 seconds.
2. 14.945031 seconds.
3. 15.018107 seconds.
4. 12.742012 seconds.


## Observations and Conclusions

*Reflect on the experiment results and the optimal number of threads for your concurrent merge sort implementation on different hosts or platforms. Try to explain why the performance stops improving or even starts deteriorating at certain thread counts.*

Our takeaway from our performance with the Windows computer running Linux was that with 12, 24, and 100 threads we get the highest performance, initially, we thought that with 6 cores we would peak in efficiency with a dropoff after 6, but as shows we get an increase up to 100 threads used. Only when we tried with 5000 threads did we receive a slight decrease, althought it was still faster than the 12 and 24 thread runtimes.
Our performance on the XOA VM decreases after going over 2 cores. Since the XOA VM only allows 2 cores at a time, this shows that we don't receive a significant increase by making more threads. It seems that the optimal amount of threads for this machine is 2.
