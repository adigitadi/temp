// Inode manipulation routines.
//
// Feel free to use as inspiration.

// based on cs3650 starter code

#ifndef INODE_H
#define INODE_H

#define num_of_pointers 2

#include "blocks.h"
#include <time.h>

// Struct to represent a node in our filesystem.
typedef struct inode {
    int refs;  // reference count
    int mode;  // permission & type
    int size;  // bytes
    int block; // single block pointer (if max file size <= 4K)
    
    // Our additions:
    int mblock[num_of_pointers]; // multiple block pointer (for larger file size)
    time_t creation_time; // time node was created
    time_t access_time; // time node was last accessed
    time_t modify_time; // time node was last modified

} inode_t;

void print_inode(inode_t *node);
inode_t *get_inode(int inum);
int alloc_inode();
// Modified signature of free_node() to modify the given node
void free_inode(int inum);
int grow_inode(inode_t *node, int size);
int shrink_inode(inode_t *node, int size);
int inode_get_bnum(inode_t *node, int fbnum);

// Our addtion:
// To decrease the number of references when needed
void inode_modify_refs(int inum);

#endif
