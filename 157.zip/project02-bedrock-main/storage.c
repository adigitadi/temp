#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

// Helper inclusions
#include "slist.h"
#include "blocks.h"
#include "bitmap.h"
// Hint inclusions
#include "directory.h"
#include "inode.h"

#define NODE_MAX_SIZE 4096

/**
 * Local helper function.
 * Gets neighbors this node's neighbors in the bitmap.
 *
 * @param above the directory before this path location
 * @param below the directory after this path location
 * @param path the location requested
 */
static void get_neighbors(char* above, char* below, const char* path) {
    // split the list into each unique location
    slist_t* split_list = s_explode(path, '/');
    // reassign list for manipulation
    slist_t* o = split_list;
    above[0] = 0;
    while (o->next != NULL) {
        strncat(above, "/", 1);
        strncat(above, o->data, 64);
        o = o->next;
    }
    int size = strlen(o->data);
    memcpy(below, o->data, size);
    below[size] = 0;
    s_free(split_list);
}

/**
 * Calculates the minimum between two ints.
 * 
 * @param x first number
 * @param y second number
 * @return the lower of the two ints
 */
static int min(int x, int y)
{ return (x < y) ? x : y;
}

// Initialize the file structure.
void storage_init(const char* path) {
    blocks_init(path);
    if (!bitmap_get(get_blocks_bitmap(), 1)) {
        for (int i = 0; i <= 2; i++) {
            int newblock = alloc_block();
        }
    }
    if (!bitmap_get(get_blocks_bitmap(), 4)) {
        directory_init();
    }
}

/**
 * // Assigns the stat values to the necessary node values.
 * 
 * @param path the location of the note being created
 * @param st the stat being referenced
 * @return 0 on success, -1 on fail
 */
int storage_stat(const char* path, struct stat* st) {
    int n = tree_lookup(path);
    if (n > 0) {
        inode_t* nd = get_inode(n);
        st->st_mode = nd->mode;
        st->st_size = nd->size;
        st->st_atime = nd->access_time;
        st->st_mtime = nd->modify_time;
        st->st_ctime = nd->creation_time;
        st->st_nlink = nd->refs;
        return 0;
    }
    return -1;
}

/**
 * Reads the data in storage from the path into the buffer.
 * 
 * @param path Location being read
 * @param buf the buffer for the information to go into
 * @param size the size of the buffer
 * @param offset the offset to ensure no data loss
 * @return the size of the buffer as an int
 */
int storage_read(const char* path, char* buf, size_t size, off_t offset) {
    inode_t* node = get_inode(tree_lookup(path));
    int i = 0; int j = offset; int k = size;
    while (k > 0) {
        int bnum = inode_get_bnum(node, j);
        char* src = blocks_get_block(bnum);
        src += j % NODE_MAX_SIZE;
        int size = min(k, NODE_MAX_SIZE - (j % NODE_MAX_SIZE));
        memcpy(buf + i, src, size);
        i += size;
        j += size;
        k -= size;
    }
    return size;
}

/**
 * Makes the storage smaller according to given size.
 * Or makes storage larger if requested node is smaller than requested size.
 * 
 * @param path the location to shrink/enlarge
 * @param size how much to shrink /enlargethe node by
 * @return 0 for success, error for fail
 */
int storage_truncate(const char *path, off_t size) {
    int n = tree_lookup(path);
    assert(n > 0);
    inode_t* nd = get_inode(n);
    if (nd->size < size) {
        grow_inode(nd, size);
    } else {
        shrink_inode(nd, size);
    }
    return 0;
}

/**
 *  Writes to the requested storage.
 * 
 * @param path location being written to
 * @param buf buffer of data being written
 * @param size size of buffer
 * @param offset offset to ensure no data loss
 * @return size of correctly written buffer
 */
int storage_write(const char* path, const char* buf, size_t size, off_t offset)
{   inode_t* target = get_inode(tree_lookup(path));
    if (target->size < size + offset) {
        storage_truncate(path, size + offset);
    }
    int i = 0; int j = offset; int k = size;
    while (k > 0) {
        int bnum = inode_get_bnum(target, j);
        char* location = blocks_get_block(bnum);
        location += j % NODE_MAX_SIZE;
        int size = min(k, NODE_MAX_SIZE - (j % NODE_MAX_SIZE));
        memcpy(location, buf + i, size);
        i += size;
        j += size;
        k -= size;
    }
    return size;
}

// Makes a file at given path.
int storage_mknod(const char* path, int mode) {
    if (tree_lookup(path) != -1) {
        return -EEXIST;
    }
    // Allocates memory for neighbors
    char* below = malloc(100);
    char* above = malloc(strlen(path));
    get_neighbors( above, below, path);
    int above_id = tree_lookup(above);
    if (above_id < 0) {
        free(below);
        free(above);
        return -ENOENT;
    }
    
    // Allocates memory for new node with correct permissions
    int new_nd = alloc_inode();
    inode_t* nd = get_inode(new_nd);
    nd->size = 0;
    nd->refs = 1;
    nd->mode = mode;
    inode_t* parent_dir = get_inode(above_id);
    // Puts new directory in the file structure
    directory_put(parent_dir, below, new_nd);
    free(below);
    free(above);
    return 0;
}

/**
 * Unlinks storage to delete data.
 *
 * @param path the path to be deleted
 * @return message from directory_delete as an int
 */
int storage_unlink(const char* path) {
    char* name = malloc(100);
    char* above = malloc(strlen(path));
    get_neighbors(above, name, path);

    int above_id = tree_lookup(above);
    inode_t* parent = get_inode(above_id);
    int rv = directory_delete(parent, name);
    free(above);
    free(name);
    return rv;
}

// Links storage from "from" location to "to" location.
int storage_link(const char *from, const char *to) {
    int t = tree_lookup(to);
    assert(t > 0);
    char* from_name = malloc(100);
    char* from_above = malloc(strlen(from));
    get_neighbors( from_above, from_name, from);

    int above_id = tree_lookup(from_above);
    inode_t* above_node = get_inode(above_id);
    directory_put(above_node, from_name, t);
    get_inode(t)->refs ++;

    free(from_name);
    free(from_above);
    return 0;
}

// Renames the storage by linking to and from, and unlinking the given from node.
int storage_rename(const char *from, const char *to) {
    storage_link(to, from);
    storage_unlink(from);
    return 0;
}

// Sets the given time for the storage.
int storage_set_time(const char* path, const struct timespec ts[2])
{
    int n = tree_lookup(path);
    if (n < 0) {
        return -ENOENT;
    }
    inode_t* nd = get_inode(n);
    // get the current time
    time_t t = ts->tv_sec;
    nd->modify_time = t;
    return 0;
}

// Returns a storage list of the current file
slist_t* storage_list(const char* path) {
    return directory_list(path);
}

// Accesses the storage to check its availability
int storage_accessed(const char* path) {
    int n = tree_lookup(path);
    if (n < 0) {
        return -ENOENT;
    }
    else {
        inode_t* nd = get_inode(n);
        time_t now = time(NULL);
        nd->access_time = now;
        return 0;
    }
}

// Changes permissions of the file to the requested mode
int storage_chmod(const char* path, mode_t mode) {
    // Traverse the tree until the given path
    int n = tree_lookup(path);
    // check that we are looking for a valid node
    if (n < 0) {
        return -ENOENT;
    }
    inode_t* nd = get_inode(n);
    // check that the current mode is different from desired mode
    assert(nd->mode != mode);
    nd->mode = nd->mode & ~07777 & mode;
    return 0;
}
