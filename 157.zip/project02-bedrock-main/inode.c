#include <stdio.h>
#include <time.h>
// Helper inclusions
#include "blocks.h"
#include "bitmap.h"
// Hint inclusions
#include "inode.h"

#define NODE_MAX_SIZE 4096

// Prints information about the given node. Also commented out because
// it doesn't seem to impact the performance of NUFS.
/*
void print_inode(inode_t * node) {
    printf("Location %p:\n", node);
    printf("References: %d\n", node->refs);
    printf("Node Mode: %d\n", node->mode);
    printf("Node Bytes: %d\n", node->size);
}
*/

// Retrieves the requested node.
inode_t* get_inode(int inum) {
    inode_t* n = get_inode_bitmap() + 31;
    return &n[inum];
}

// Allocates memory for the node.
int alloc_inode() {
    // Number n to be assigned to the new node.
    int n;
    for (int ii = 0; ii < 256; ++ii) {
        if (!bitmap_get(get_inode_bitmap(), ii)) {
            bitmap_put(get_inode_bitmap(), ii, 1);
            n = ii;
            break;
        }
    }
    // Construct new node
    inode_t* new_node = get_inode(n);
    new_node->refs = 1;
    new_node->size = 0;
    new_node->mode = 0;
    new_node->mblock[0] = alloc_block();

    // Set all node times to local time for the machine
    time_t now = time(NULL);
    new_node->creation_time = now;
    new_node->access_time = now;
    new_node->modify_time = now;

    return n;
}

// Dereferences this node from all of its neighbors in the node bitmap.
void free_inode(int inum) {
    // Retrieve the given node
    inode_t* n = get_inode(inum);
    // Store its bitmap
    void* bitmap = get_inode_bitmap();
    // Dereference it from its neighbors
    bitmap_put(bitmap, inum, 0);
    shrink_inode(n, 0);
    free_block(n->mblock[0]);
}

// Expands the given node, and if necessary allocates more memory to it.
int grow_inode(inode_t* node, int size) {
    for (int i = (node->size / NODE_MAX_SIZE) + 1; i <= size / NODE_MAX_SIZE; i ++) {
        // check if we can use multiblock
        if (num_of_pointers > i) {
            node->mblock[i] = alloc_block();
            // if not, use single block
        } else {
            if (node->block == 0) {
                node->block = alloc_block();
            }
            int* nodes = blocks_get_block(node->block);
            nodes[i - num_of_pointers] = alloc_block();
        }
    }
    node->size = size;
    return 0;
}

// Shrinks the given inode and deallocates memory when necessary.
int shrink_inode(inode_t* node, int size) {
    for (int i = (node->size / NODE_MAX_SIZE); i > size / NODE_MAX_SIZE; i --) {
        // Multiblock case
        if (i < num_of_pointers) {
            free_block(node->mblock[i]);
            node->mblock[i] = 0;
            // Single block case
        } else {
            int* nodes = blocks_get_block(node->block);
            free_block(nodes[i - num_of_pointers]);
            nodes[i-num_of_pointers] = 0;

            if (i == num_of_pointers) {
                free_block(node->block);
                node->block = 0;
            }
        }
    }
    node->size = size;
    return 0;
}

// Retrieves block number for the given node
int inode_get_bnum(inode_t* node, int fbnum) {
    int block_id = fbnum / NODE_MAX_SIZE;
    int out = 0;
    if (num_of_pointers > block_id) {
        out = node->mblock[block_id];
    } else {
        int* nodes = blocks_get_block(node->block);
        out = nodes[block_id - num_of_pointers];
    }
    return out;
}

// Reduces the ref values when freeing space.
void inode_modify_refs(int inum){
    inode_t* n = get_inode(inum);
    n->refs = n->refs - 1;
    if (n->refs < 1) {
        free_inode(inum);
    }
}
