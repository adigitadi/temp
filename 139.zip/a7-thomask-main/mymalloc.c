#define _DEFAULT_SOURCE
#define _BSD_SOURCE 
#include <malloc.h> 
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <sys/mman.h>
#include <stdint.h>
#include <pthread.h>

// Include any other headers we need here

// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf

//Our block of memory struct
typedef struct block {
  size_t size;        // How many bytes beyond this block have been allocated in the heap
  struct block *next; // Where is the next block in your linked list
  struct block *prev;
  int free;           // Is this memory free, i.e., available to give away?
} block_t;
 	

//The head of the linked memory list
block_t *first;
//Mutex lock for thread safety
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

//Helper method for mymalloc that adds memory
void *addMem(size_t s, block_t *block);
//Splits memory when the whole block isnt used
void split(size_t s, block_t *block);
//Uses mmap to malloc
void *useMMAP(size_t s, block_t *block);
//Combines 2 free blocks which are next to each other and on the same page
block_t *coalescing(block_t *x, block_t *y);


//Malloc implementation
void *mymalloc(size_t s) {
  pthread_mutex_lock(&lock);
  assert(s != 0);
  debug_printf("Malloc %zu bytes\n", s);
  //If the head of the list is NULL, we add memory there
  if(first == NULL) {
	block_t *ptr = mmap(NULL, s+sizeof(block_t), PROT_READ|PROT_WRITE, MAP_ANON|MAP_PRIVATE, 0, 0);
	first = ptr;
	first->size = sysconf(_SC_PAGE_SIZE);
	first->free = 0;
	first->next = NULL;
	first->prev = NULL;
	if(s + 2*sizeof(block_t) < sysconf(_SC_PAGE_SIZE)) {
		split(s, first);
	}
	pthread_mutex_unlock(&lock);
	return ((void*)ptr) + sizeof(block_t);
  } else {
	//if the size will take up a whole page or more
	if(s + 2*sizeof(block_t) > sysconf(_SC_PAGE_SIZE)) {
		return useMMAP(s, first);
	}
	//if the size is small enough for multiple memory locations
	return addMem(s, first);
    }  
    return NULL;
}

void split(size_t s, block_t *block) {
	debug_printf("splitting\n");
	if(block->size > s + sizeof(block_t)) {
	  block_t *new = (void*)block + s + sizeof(block_t);
	  new->size = block->size - s - sizeof(block_t);
	  new->free = 1;
	  new->next = block->next;
	  new->prev = block;
	  block->next = new;
	  block->size = s;
	}
}

void *useMMAP(size_t s, block_t *block) {
	if(block->next == NULL) {
		block_t *ptr = mmap(NULL, s + sizeof(block_t), PROT_READ|PROT_WRITE, MAP_ANON|MAP_PRIVATE, 0, 0);
		block_t *new = ptr;
		new->size = s;
		new->free = 0;
		new->next = NULL;
		new->prev = block;
		block->next = new;
		pthread_mutex_unlock(&lock);
		return((void*)ptr) + sizeof(block_t);
	} 
	return useMMAP(s, block->next); 
}

//Malloc helper method implementation
void *addMem(size_t s, block_t *block) {
	//Check if given block is free and given size + struct size is less than block size
	if(block->free == 1 && s+sizeof(block_t) <= block->size) {
		debug_printf("Using freed memory\n");
		block->free = 0;
		split(s, block);
	        pthread_mutex_unlock(&lock);
		return ((void*)block) + sizeof(block_t);
	//Keep recursively calling helper method
	} else if(block->next != NULL) {
		return addMem(s, block->next);
	//return the pointer to the block
	} else {
		debug_printf("Adding more memory\n");
		void *ptr = useMMAP(sysconf(_SC_PAGE_SIZE), block);
		split(s, ptr);
		pthread_mutex_unlock(&lock);
		return ptr + sizeof(block_t);
	}
}

//Calloc implementation
void *mycalloc(size_t nmemb, size_t s) {

  assert(nmemb != 0);
  assert(s  != 0);

  debug_printf("Calloc %zu bytes\n", nmemb * s);

  void *block = mymalloc(nmemb * s);
  memset(block, 0, nmemb * s);

  return block;
}

//Free implementation
void myfree(void *ptr) {
  pthread_mutex_lock(&lock);
  debug_printf("Freed some memory\n");
  block_t *curr = ptr - sizeof(block_t);
  if(curr->size > sysconf(_SC_PAGE_SIZE) - 2*sizeof(block_t)) {
	  if(curr->prev != NULL) {
	    curr->prev->next = curr->next;
	  }
	  if(curr->next != NULL) {
	    curr->next->prev = curr->prev;
	  }
	  munmap((void*)curr, curr->size + sizeof(block_t));
  }
  else {
	if(curr->next != NULL && curr->next->free == 1 && (uintptr_t)curr/sysconf(_SC_PAGE_SIZE) == (uintptr_t)curr->next/sysconf(_SC_PAGE_SIZE)) {
		curr = coalescing(curr, curr->next);
	}
	if(curr->prev != NULL && curr->prev->free == 1 && (uintptr_t)curr/sysconf(_SC_PAGE_SIZE) == (uintptr_t)curr->prev/sysconf(_SC_PAGE_SIZE)) {
		curr = coalescing(curr->prev, curr);
	}
	curr->free = 1;
  }
  pthread_mutex_unlock(&lock);
}



block_t *coalescing(block_t *x, block_t *y){
	debug_printf("Coalescing\n");
	x->next = y->next;
	x->size = x->size + y->size + sizeof(block_t);
	y = NULL;
	return x;	
}

