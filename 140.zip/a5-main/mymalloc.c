#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <math.h>
#include <sys/mman.h>
#include <pthread.h>

// Include any other headers we need here
// NOTE: You should NOT include <stdlib.h> in your final implementation

#include <debug.h> // definition of debug_printf

// Header block for a chunk of memory
typedef struct block
{
    size_t size;        // How many bytes beyond this block have been allocated in the heap
    struct block *next; // Where is the next block in your linked list
    int free;           // Is this memory free, i.e., available to give away?
                        // (optional) Perhaps you can embed other information--remember,
                        // you are the boss!
} block_t;

// function headers
block_t *init_first(block_t *block, size_t s);
block_t *get_last(block_t *b);
void *request_space(int pages);
void *request_split(size_t s);
void *block_split(block_t *block, size_t s);
void *search_available(size_t s);
block_t *get_prev(block_t *block);

// global variables initialized to be referenced later
#define BLOCK_SIZE sizeof(block_t)       // size of a block header in bytes
#define PAGE_SIZE sysconf(_SC_PAGE_SIZE) // system virtual memory page size
static block_t top = {0, NULL, 0};       // Initial block for the free list. Never changed
block_t *GLOBAL_START = NULL;

// Initialize mutex
pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;

void *mymalloc(size_t s)
{
    pthread_mutex_lock(&mtx);
    // convert bytes to pages
    int pages = (s + BLOCK_SIZE) / PAGE_SIZE;
    // ups the size until it equals a whole page (since that what mmap uses)
    if ((s + BLOCK_SIZE) % PAGE_SIZE > 0)
    {
        pages++;
    }

    // Check if the request needs new pages
    if (s + BLOCK_SIZE >= PAGE_SIZE)
    {
        // Return pointer to start of free space
        return request_space(pages);
    }
    else
    {
        // fit the memory in the current page
        return search_available(s);
    }
}

// find the first open block with specified size in list
block_t *init_first(block_t *block, size_t s)
{
    if (block == GLOBAL_START)
    {
        return GLOBAL_START;
    }
    else if (block->size >= s && block->free == 1)
    {
        return block;
    }
    else
    {
        return init_first(block->next, s);
    }
}

// returns the last block in the list before NULL
block_t *get_last(block_t *b)
{
    if (b->next == NULL)
    {
        return b;
    }
    else
    {
        return get_last(b->next);
    }
}

// allocates more space in our malloc if requested/needed
void *request_space(int pages)
{
    int total = pages * PAGE_SIZE;
    void *newpage = mmap(NULL, total, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    // if mmap fails quit
    if (newpage == (void *)-1)
    {
        pthread_mutex_unlock(&mtx);
        return newpage;
    }

    // if it doesnt fail setup new block with the page
    block_t *end = get_last(&top);
    end->next = newpage;
    // not free as we used it
    end->next->free = 0;
    end->next->size = total - BLOCK_SIZE; // allowing for space of the struct
    // doesnt exists yet we haven't made it
    end->next->next = NULL;

    debug_printf("malloc %d bytes\n", total);
    pthread_mutex_unlock(&mtx);

    // updating pointer
    return (void *)newpage + BLOCK_SIZE;
}

// Splits a page into two blocks and adds both of them  blocks to the free list
void *request_split(size_t s)
{
    // create a whole new page to split
    void *newpage = mmap(NULL, PAGE_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    // if mmap fails quit
    if (newpage == (void *)-1)
    {
        pthread_mutex_unlock(&mtx);
        return newpage;
    }

    // create two blocks from page, one to fill, one to be empty
    block_t *end = get_last(&top);
    // these new blocks are being added to the end of our list
    end->next = newpage;
    // of our requested size
    end->next->size = s;
    // not free as we used it
    end->next->free = 0;

    // split off block that we are leaving empty
    block_t *mt = ((void *)newpage) + s + BLOCK_SIZE;
    end->next->next = mt;
    // end of our list so no next
    mt->next = NULL;
    // free as we do not have memory to fill it
    mt->free = 1;
    // subtracting the size of our other block from the totoal size of our page
    mt->size = PAGE_SIZE - BLOCK_SIZE - BLOCK_SIZE - s;

    pthread_mutex_unlock(&mtx);
    // update pointer
    return (void *)newpage + BLOCK_SIZE;
}

// Splits a block into two blocks. If block cannot be split, return block and mark used.
void *block_split(block_t *block, size_t s)
{
    // check if block cannot be split
    assert((int)block->size - s - BLOCK_SIZE >= 1);

    // our part of the block we are splitting off
    block_t *mt = ((void *)block) + BLOCK_SIZE + s;
    // free as we are splitting it off
    mt->free = 1;
    // subtracting all size thats been used
    mt->size = block->size - BLOCK_SIZE - s;
    // updating next
    mt->next = block->next;

    // this is filled before our unfilled part
    block->next = mt;
    // not free, we're using it
    block->free = 0;
    // assign the size requested
    block->size = s;

    // ensuring everything was done correctly
    assert(mt->size >= 1);

    pthread_mutex_unlock(&mtx);
    // updating pointer
    return ((void *)block) + BLOCK_SIZE;
}

// sees if the current list of blocks can handle our size request
void *search_available(size_t s)
{
    // Find an open block with at least s bytes
    block_t *first = init_first(&top, s);

    // If we could not find space in our list
    if (first == GLOBAL_START)
    {
        // Map new page memory and split
        if (PAGE_SIZE - BLOCK_SIZE - s <= BLOCK_SIZE)
        {
            // space is availible so we do not need to split
            return request_space(1);
        }
        else
        {
            // split page in hopes of storing memory;
            return request_split(s);
        }
        // if we could find space allocate and split it
    }
    else
    {
        // if we need to split
        if ((int)(first->size - s - BLOCK_SIZE) >= 1)
        {
            return block_split(first, s);
        }
        else
        {
            // we do not need to split
            first->free = 0;
            debug_printf("malloc %zu bytes\n", s);
            pthread_mutex_unlock(&mtx);
            // update pointer
            return ((void *)first) + BLOCK_SIZE;
        }
    }
}

// assigns all empty memoy to 0 instead of NULL
void *mycalloc(size_t nmemb, size_t s)
{
    size_t size = nmemb * s;

    void *p = mymalloc(nmemb * s);
    memset(p, 0, size);

    if (!p)
    {
        // We are out of memory
        // if we get NULL back from malloc
        debug_printf("could not calloc, out of mem\n");
    }

    debug_printf("calloc %zu bytes\n", nmemb * s);
    return p;
}

// Iteratively coalesces contiguous free blocks in the list
void coalesce()
{
    block_t *curr = &top;

    while (curr->next != NULL)
    {
        block_t *next = curr->next;
        // check both are free / we can combine them
        if (next->free == 1 && curr->next == (void *)curr + BLOCK_SIZE + curr->size && curr->free == 1)
        {
            // update our next, skipping our old next (since our first block absorbed the next)
            curr->next = next->next;
            // add our sizes together
            curr->size = curr->size + next->size + BLOCK_SIZE;

            // essentally erase next, just in case we didn't skip
            next->size = 0;
            next->next = NULL;
            next->free = 0;
        }
        else
        {
            curr = curr->next;
        }
    }
}

// Get the previous block in the free list
block_t *get_prev(block_t *block)
{
    block_t *curr = &top;
    while (curr->next != block)
    {
        curr = curr->next;
    }

    return curr;
}

void myfree(void *ptr)
{

    // acessing block failed / nothing to be freed
    if (!ptr)
    {
        return;
    }

    pthread_mutex_lock(&mtx);
    block_t *block_ptr = ptr - BLOCK_SIZE;

    if (block_ptr->size + BLOCK_SIZE >= PAGE_SIZE)
    {
        block_t *prev = get_prev(block_ptr);
        prev->next = block_ptr->next;
        // Make sure we always attempt to unmap whole page sizes
        assert((block_ptr->size + BLOCK_SIZE) % PAGE_SIZE == 0);
        block_ptr->free = 1;
        assert(block_ptr->free == 1);

        munmap((void *)block_ptr, block_ptr->size + BLOCK_SIZE);
    }
    else
    {
        // we have enough space
        block_ptr->free = 1;
        assert(block_ptr->free == 1);
        coalesce();
    }
    pthread_mutex_unlock(&mtx);
    debug_printf("Freed some memory\n");
}
